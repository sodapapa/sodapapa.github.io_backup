package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ljsnc.api.model.TnSportsCenter;

public interface TnSportsCenterMapper {

	@Select(""
			+ "SELECT SC_ID "
			+ "FROM tn_sports_center	"
			+ "WHERE SC_LOGIN_ID = #{scLoginId} AND SC_PW = #{scPw}")
	TnSportsCenter loginCheck(@Param("scLoginId")String scLoginId, @Param("scPw")String scPw);

	@Select("<script>"
			+ " SELECT  "
			+ "   SC_ID,  "
			+ "   SC_LOGIN_ID,  "
			+ "   SC_PW,  "
			+ "   SC_NM,  "
			+ "   SC_CN,  "
			+ "   SC_TEL,  "
			+ "   SC_OPER_TIME,  "
			+ "   SC_POST,  "
			+ "   SC_ADDR,  "
			+ "   SC_ADDR_DETAIL,  "
			+ "   SC_ADDR_LA,  "
			+ "   SC_ADDR_LO,  "
			+ "   SC_FRNCHS_TYPE,  "
			+ "   SC_AREA,  "
			+ "   SC_CTGRY,  "
			+ "   SC_REALM,  "
			+ "   SC_INDUT,  "
			+ "   SC_ITEM,  "
			+ "   SC_THEMA,  "
			+ "   SC_LOGO_IMG_URL,  "
			+ "   SC_MAIN_IMG_URL , "
			+ "   "
			+ "	(SELECT COUNT(SC_ID )  FROM tn_sports_center"
			+ " 			where "
			+ "				1=1   "
			+ "				<if test=\"searchText != null and searchText != '' \">"
			+ ""
			+ "					AND SC_NM LIKE CONCAT ('%',  #{searchText} ,'%')  "
			+ "				</if>"
			+ "		) AS SC_CNT"
			+ " FROM tn_sports_center  "
			+ " 		where "
			+ "		1=1   "
			+ "	<if test=\"searchText != null and searchText != '' \" >"
			+ "		AND SC_NM LIKE CONCAT ('%',  #{searchText} ,'%')  "
			+ "	</if>"
			+ "	Limit  ${pageNo * pageSize - 10}, ${pageNo * 10}"
			+ "</script> "
			)
	List<TnSportsCenter> getCenterList(@Param("searchText") String searchText, @Param("searchType") String searchType,
														@Param("pageNo") Integer pageNo,@Param("pageSize")  Integer pageSize);


	@Select("<script>"
			+ " SELECT  "
			+ "   SC_ID,  "
			+ "   SC_LOGIN_ID,  "
			+ "   SC_PW,  "
			+ "   SC_NM,  "
			+ "   SC_CN,  "
			+ "   SC_TEL,  "
			+ "   SC_OPER_TIME,  "
			+ "   SC_POST,  "
			+ "   SC_ADDR,  "
			+ "   SC_ADDR_DETAIL,  "
			+ "   SC_ADDR_LA,  "
			+ "   SC_ADDR_LO,  "
			+ "   SC_FRNCHS_TYPE,  "
			+ "   SC_AREA,  "
			+ "   SC_CTGRY,  "
			+ "   SC_REALM,  "
			+ "   SC_INDUT,  "
			+ "   SC_ITEM,  "
			+ "   SC_THEMA,  "
			+ "   SC_LOGO_IMG_URL,  "
			+ "   SC_MAIN_IMG_URL  "
			+ "   "
			+ " FROM tn_sports_center  "
			+ " <where> "
			+ "		1=1   "
			+ " 	AND SC_ID = #{scId}  "
			+ " </where>  "
			+ "</script> "
			)
	TnSportsCenter getCenterInfo(int scId);

	@Select("<script>"
			+ ""
			+ "  SELECT    "
			+ "    sc.SC_ID,   "
			+ "    sc.SC_LOGIN_ID,   "
			+ "    sc.SC_PW,   "
			+ "    sc.SC_NM,   "
			+ "    sc.SC_CN,   "
			+ "    sc.SC_TEL,   "
			+ "    sc.SC_OPER_TIME,   "
			+ "    sc.SC_POST,   "
			+ "    sc.SC_ADDR,   "
			+ "    sc.SC_ADDR_DETAIL,   "
			+ "    sc.SC_ADDR_LA,   "
			+ "    sc.SC_ADDR_LO,   "
			+ "    sc.SC_FRNCHS_TYPE,   "
			+ "    sc.SC_AREA,   "
			+ "    sc.SC_CTGRY,   "
			+ "    sc.SC_REALM,   "
			+ "    sc.SC_INDUT,   "
			+ "    sc.SC_ITEM,   "
			+ "    sc.SC_THEMA,   "
			+ "    sc.SC_LOGO_IMG_URL,   "
			+ "    sc.SC_MAIN_IMG_URL   "
			+ "  FROM   "
			+ "    tn_user u,   "
			+ "    tn_user_mapping um,   "
			+ "    tn_sports_center sc    "
			+ "  WHERE u.USER_ID = um.USER_ID    "
			+ "    AND um.SC_ID = sc.SC_ID    "
			+ "    AND u.USER_ID = #{userId}   "
			+ "     "
			+ "     "
			+ "</script>"
			)
	List<TnSportsCenter> getMyCenterList(Integer userId);


}
