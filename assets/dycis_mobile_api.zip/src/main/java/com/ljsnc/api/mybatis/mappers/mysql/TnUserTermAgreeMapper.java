package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ljsnc.api.model.TnTermInfo;
import com.ljsnc.api.model.TnUserTermAgree;

public interface TnUserTermAgreeMapper {

	@Insert(""
			+ "INSERT INTO tn_user_term_agree(USER_ID, TERM_ID, AGREE_YN, AGREE_DT) "
			+ "VALUES(#{userId}, #{termId}, #{agreeYn}, now()) "
			+ "")
	int createUserTermAgreeYn(TnUserTermAgree tnUserTermAgree);

	@Insert("<script>"
			+ "INSERT INTO tn_user_term_agree(USER_ID, TERM_ID, AGREE_YN, AGREE_DT) "
			+ "VALUES"
			+ "<foreach collection=\"list\" item=\"item\" index=\"index\" separator=\",\">"
			+ "		(#{item.userId}, #{item.termId}, #{item.agreeYn}, now()) "
			+ "</foreach>"
			+ "</script>")
	int createUserTermAgreeYnMulti(List<TnUserTermAgree> tnUserTermAgree);



	@Select(""
			+ "       "
			+ "   (SELECT     "
			+ "     A.TERM_ID,    "
			+ "     A.TERM_TYPE,    "
			+ "     A.TERM_NM,    "
			+ "     A.TERM_VERSION,    "
			+ "     A.TERM_URL,    "
			+ "     IFNULL(B.AGREE_YN, 'N')  AS AGREE_YN   "
			+ "   FROM    "
			+ "     (SELECT     "
			+ "       TERM_ID,    "
			+ "       TERM_TYPE,    "
			+ "       TERM_NM,    "
			+ "       TERM_VERSION,    "
			+ "       TERM_URL     "
			+ "     FROM    "
			+ "       tn_term_info     "
			+ "     WHERE term_type = '01'     "
			+ "     ORDER BY REG_DT DESC     "
			+ "     LIMIT 1) A     "
			+ "     LEFT OUTER JOIN tn_user_term_agree B     "
			+ "       ON A.TERM_ID = B.TERM_ID     "
			+ "       AND B.USER_ID = #{userId}     "
			+ "       OR B.USER_ID IS NULL)     "
			+ "   UNION    "
			+ "   (SELECT     "
			+ "     A.TERM_ID,    "
			+ "     A.TERM_TYPE,    "
			+ "     A.TERM_NM,    "
			+ "     A.TERM_VERSION,    "
			+ "     A.TERM_URL,    "
			+ "     IFNULL(B.AGREE_YN, 'N')   AS AGREE_YN  "
			+ "   FROM    "
			+ "     (SELECT     "
			+ "       TERM_ID,    "
			+ "       TERM_TYPE,    "
			+ "       TERM_NM,    "
			+ "       TERM_VERSION,    "
			+ "       TERM_URL     "
			+ "     FROM    "
			+ "       tn_term_info     "
			+ "     WHERE term_type = '02'     "
			+ "     ORDER BY REG_DT DESC     "
			+ "     LIMIT 1) A     "
			+ "     LEFT OUTER JOIN tn_user_term_agree B     "
			+ "       ON A.TERM_ID = B.TERM_ID     "
			+ "       AND B.USER_ID = #{userId}     "
			+ "       OR B.USER_ID IS NULL)     "
			+ "   UNION    "
			+ "   (SELECT     "
			+ "     A.TERM_ID,    "
			+ "     A.TERM_TYPE,    "
			+ "     A.TERM_NM,    "
			+ "     A.TERM_VERSION,    "
			+ "     A.TERM_URL,    "
			+ "     IFNULL(B.AGREE_YN, 'N')  AS AGREE_YN   "
			+ "   FROM    "
			+ "     (SELECT     "
			+ "       TERM_ID,    "
			+ "       TERM_TYPE,    "
			+ "       TERM_NM,    "
			+ "       TERM_VERSION,    "
			+ "       TERM_URL     "
			+ "     FROM    "
			+ "       tn_term_info     "
			+ "     WHERE term_type = '03'     "
			+ "     ORDER BY REG_DT DESC     "
			+ "     LIMIT 1) A     "
			+ "     LEFT OUTER JOIN tn_user_term_agree B     "
			+ "       ON A.TERM_ID = B.TERM_ID     "
			+ "       AND B.USER_ID = #{userId}     "
			+ "       OR B.USER_ID IS NULL)    "
			+ "       "
			+ "       "
			+ "       "
			+ "       "
			+ "")
	List<TnTermInfo> getUserTermAgreeInfo(@Param("userId")Integer userId);

	@Insert("<script>"
			+ "INSERT INTO tn_user_term_agree(USER_ID, TERM_ID, AGREE_YN, AGREE_DT) "
			+ "VALUES"
			+ "	<foreach collection=\"list\" item=\"item\" index=\"index\" separator=\",\">"
			+ "			(#{item.userId}, #{item.termId}, #{item.agreeYn}, now()) "
			+ "	</foreach>"
			+ "</script>")
	int createUserTermAgreeYnMultiByUrl(List<TnUserTermAgree> tnUserTermAgree);


	@Select(""
			+ ""
			+ "SELECT IFNULL (AGREE_YN, 'N')  FROM tn_user_term_agree WHERE user_id =#{userId} and term_id = #{termId}"
			+ "")
	String checkUserAgreeTerm(@Param("termId") int termId,@Param("userId") Integer userId);


	@Select("  "
			+ "   "
			+ "	SELECT      "
			+ "     COUNT(*)      "
			+ "   FROM     "
			+ "     tn_user_term_agree      "
			+ "   WHERE USER_ID = #{userId}      "
			+ "     AND TERM_ID =      "
			+ "     (SELECT      "
			+ "       TERM_ID      "
			+ "     FROM     "
			+ "       tn_term_info      "
			+ "     WHERE term_type = #{termType}      "
			+ "     ORDER BY REG_DT DESC      "
			+ "     LIMIT 1)     "
			+ "        "
			+ "        ")
	int termAgreeChk(@Param("userId") Integer userId, @Param("termType") String termType);


	@Select(""
			+ ""
			+ "     SELECT      "
			+ "       TERM_ID      "
			+ "     FROM     "
			+ "       tn_term_info      "
			+ "     WHERE term_type = #{termType}      "
			+ "     ORDER BY REG_DT DESC      "
			+ "     LIMIT 1     "
			+ ""
			+ "")
	int getLatestRermId(@Param("termType") String termTyp);


}
