package com.ljsnc.api.exception;

import java.util.Map;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ljsnc.api.biz.util.ApiResponse;
import com.ljsnc.api.manager.MessageManager;
import com.ljsnc.api.util.CommonConstants;


@Provider
public class JaxRsExceptionMapper implements ExceptionMapper<Throwable>
{
	private static final Logger logger = LoggerFactory.getLogger(JaxRsExceptionMapper.class);

	@Autowired MessageManager messageManager;

    //@Override
    public Response toResponse(Throwable e)
    {
    	ManagedException me;

    	if (e instanceof ManagedException)
        {
            me = (ManagedException) e;
        }
    	else
    	{
    		logger.error("Unmanaged Exception", e);
    		me = new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
    	}

    	// DB에서 메시지 가져와서 Response 생성
    	me.setMsg(messageManager.getErrMsg(me.getExceptionCode().getNoMsg(), me.getFgLang()));
    	Map<String, Object> response = ApiResponse.makeResponse(me);

        logger.info("ManagedException={}, Response={}", me, response.toString());

        return Response.ok().type("application/json").entity(response).build();
    }
}