package com.ljsnc.api.model.response;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class DtoQnaView implements Serializable{
	private static final long serialVersionUID = 1L;

    private String biTitle;
	private String biContents;
	private String pBiId;
	private String noticeYn;
	private String pwdValue;
	private String likeCnt;
	private String readCnt;
	private String regDate;
	private String writeId;
	private String writeNm;
	private String writeImg;

	private String qBiTitle;
	private String qBiContents;
	private String qPBiId;
	private String qNoticeYn;
	private String qPwdValue;
	private String qLikeCnt;
	private String qReadCnt;
	private String qRegDate;
	private String qWriteId;
	private String qWriteNm;
	private String qWriteImg;






	public String getBiTitle() {
		return biTitle;
	}






	public void setBiTitle(String biTitle) {
		this.biTitle = biTitle;
	}






	public String getBiContents() {
		return biContents;
	}






	public void setBiContents(String biContents) {
		this.biContents = biContents;
	}






	public String getpBiId() {
		return pBiId;
	}






	public void setpBiId(String pBiId) {
		this.pBiId = pBiId;
	}






	public String getNoticeYn() {
		return noticeYn;
	}






	public void setNoticeYn(String noticeYn) {
		this.noticeYn = noticeYn;
	}






	public String getPwdValue() {
		return pwdValue;
	}






	public void setPwdValue(String pwdValue) {
		this.pwdValue = pwdValue;
	}






	public String getLikeCnt() {
		return likeCnt;
	}






	public void setLikeCnt(String likeCnt) {
		this.likeCnt = likeCnt;
	}






	public String getReadCnt() {
		return readCnt;
	}






	public void setReadCnt(String readCnt) {
		this.readCnt = readCnt;
	}






	public String getRegDate() {
		return regDate;
	}






	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}






	public String getWriteId() {
		return writeId;
	}






	public void setWriteId(String writeId) {
		this.writeId = writeId;
	}






	public String getWriteNm() {
		return writeNm;
	}






	public void setWriteNm(String writeNm) {
		this.writeNm = writeNm;
	}






	public String getWriteImg() {
		return writeImg;
	}






	public void setWriteImg(String writeImg) {
		this.writeImg = writeImg;
	}









	public String getqBiTitle() {
		return qBiTitle;
	}






	public void setqBiTitle(String qBiTitle) {
		this.qBiTitle = qBiTitle;
	}






	public String getqBiContents() {
		return qBiContents;
	}






	public void setqBiContents(String qBiContents) {
		this.qBiContents = qBiContents;
	}






	public String getqPBiId() {
		return qPBiId;
	}






	public void setqPBiId(String qPBiId) {
		this.qPBiId = qPBiId;
	}






	public String getqNoticeYn() {
		return qNoticeYn;
	}






	public void setqNoticeYn(String qNoticeYn) {
		this.qNoticeYn = qNoticeYn;
	}






	public String getqPwdValue() {
		return qPwdValue;
	}






	public void setqPwdValue(String qPwdValue) {
		this.qPwdValue = qPwdValue;
	}






	public String getqLikeCnt() {
		return qLikeCnt;
	}






	public void setqLikeCnt(String qLikeCnt) {
		this.qLikeCnt = qLikeCnt;
	}






	public String getqReadCnt() {
		return qReadCnt;
	}






	public void setqReadCnt(String qReadCnt) {
		this.qReadCnt = qReadCnt;
	}






	public String getqRegDate() {
		return qRegDate;
	}






	public void setqRegDate(String qRegDate) {
		this.qRegDate = qRegDate;
	}






	public String getqWriteId() {
		return qWriteId;
	}






	public void setqWriteId(String qWriteId) {
		this.qWriteId = qWriteId;
	}






	public String getqWriteNm() {
		return qWriteNm;
	}






	public void setqWriteNm(String qWriteNm) {
		this.qWriteNm = qWriteNm;
	}






	public String getqWriteImg() {
		return qWriteImg;
	}






	public void setqWriteImg(String qWriteImg) {
		this.qWriteImg = qWriteImg;
	}






	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
