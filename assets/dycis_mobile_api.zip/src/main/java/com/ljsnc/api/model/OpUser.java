package com.ljsnc.api.model;

import java.io.Serializable;

public class OpUser implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private int userId;
	private String userType;
	private String loginId;
	private String password;
	private String userName;
	private String email;
	private int statusCode;
	private int loginCount;
	private String sleepMailSendDate;
	private String loginDate;
	private String denyDate;
	private String leaveDate;
	private String updatedDate;
	private String createdDate;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public int getLoginCount() {
		return loginCount;
	}
	public void setLoginCount(int loginCount) {
		this.loginCount = loginCount;
	}
	public String getSleepMailSendDate() {
		return sleepMailSendDate;
	}
	public void setSleepMailSendDate(String sleepMailSendDate) {
		this.sleepMailSendDate = sleepMailSendDate;
	}
	public String getLoginDate() {
		return loginDate;
	}
	public void setLoginDate(String loginDate) {
		this.loginDate = loginDate;
	}
	public String getDenyDate() {
		return denyDate;
	}
	public void setDenyDate(String denyDate) {
		this.denyDate = denyDate;
	}
	public String getLeaveDate() {
		return leaveDate;
	}
	public void setLeaveDate(String leaveDate) {
		this.leaveDate = leaveDate;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	@Override
	public String toString() {
		return "OpUser [userId=" + userId + ", userType=" + userType + ", loginId=" + loginId + ", password=" + password
				+ ", userName=" + userName + ", email=" + email + ", statusCode=" + statusCode + ", loginCount="
				+ loginCount + ", sleepMailSendDate=" + sleepMailSendDate + ", loginDate=" + loginDate + ", denyDate="
				+ denyDate + ", leaveDate=" + leaveDate + ", updatedDate=" + updatedDate + ", createdDate="
				+ createdDate + "]";
	}
}
