package com.ljsnc.api.exception;

import com.ljsnc.api.reference.FgLang;

public class ManagedException extends RuntimeException
{
    private static final long serialVersionUID = 4221873378575565153L;

    private ManagedExceptionCode exceptionCode;
    private FgLang fgLang;
    private String msg;

    public ManagedException(ManagedExceptionCode exceptionCode, FgLang fgLang)
    {
        super(exceptionCode.toString());
        this.exceptionCode = exceptionCode;
        this.fgLang = fgLang;
    }
    
    public ManagedExceptionCode getExceptionCode()
    {
    	return exceptionCode;
    }

	public FgLang getFgLang() {
		return fgLang;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}
