package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;

import com.ljsnc.api.model.TnBillboard;
import com.ljsnc.api.model.TnBillboardComment;
import com.ljsnc.api.model.TnBillboardInfo;

public interface TnBillboardReadMapper {

	@SelectKey(before = false,  keyProperty = "readCnt", resultType = int.class, statement = ""
			+ "SELECT COUNT(*) as readCnt From tn_billboard_read where BI_ID =#{biId}" )
	@Insert(""
			+ "  INSERT INTO tn_billboard_read    "
			+ "              (BI_ID,    "
			+ "               USER_ID,    "
			+ "               REG_DT)    "
			+ "  VALUES (#{biId},    "
			+ "          #{userId},    "
			+ "          now() )    "
			+ "      "
			+ "")
	int insertUserRead(HashMap<String,Object> param);
}
