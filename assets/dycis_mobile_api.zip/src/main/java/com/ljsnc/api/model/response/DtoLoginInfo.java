package com.ljsnc.api.model.response;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class DtoLoginInfo implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private int userId;
	private String authToken;
	private String userNm;
	private String userGender;
	private String userType;
	
	
	


	public int getUserId() {
		return userId;
	}






	public void setUserId(int userId) {
		this.userId = userId;
	}






	public String getAuthToken() {
		return authToken;
	}






	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}






	public String getUserNm() {
		return userNm;
	}






	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}






	public String getUserGender() {
		return userGender;
	}






	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}






	public String getUserType() {
		return userType;
	}






	public void setUserType(String userType) {
		this.userType = userType;
	}






	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
