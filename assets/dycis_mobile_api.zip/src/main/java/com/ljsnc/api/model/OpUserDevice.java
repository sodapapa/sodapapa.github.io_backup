package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.ljsnc.api.reference.DeviceKind;

public class OpUserDevice implements Serializable{
	private static final long serialVersionUID = 1L;
	

	private DeviceKind  deviceType;		// int(11) NOT NULL푸시발송순번
	private String  pushKey;		// NULL자동발송 : Y,N
	
	


	public DeviceKind getDeviceType() {
		return deviceType;
	}




	public void setDeviceType(DeviceKind deviceType) {
		this.deviceType = deviceType;
	}




	public String getPushKey() {
		return pushKey;
	}




	public void setPushKey(String pushKey) {
		this.pushKey = pushKey;
	}




	@Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this);
    }
	
}
