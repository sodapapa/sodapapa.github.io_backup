package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_DEFAULT)
public class TnBillboardPds implements Serializable{

	private static final long serialVersionUID = 1L;

	private int bpId;
	private int biId;
	private String filePath;
	private String fileName;
	private String fileFormat;
	private String deleteYn;
	private String regType;
	private String regId;
	private String regDt;
	private String modType;
	private String modId;
	private String modDt;






	public int getBpId() {
		return bpId;
	}








	public void setBpId(int bpId) {
		this.bpId = bpId;
	}








	public int getBiId() {
		return biId;
	}








	public void setBiId(int biId) {
		this.biId = biId;
	}








	public String getFilePath() {
		return filePath;
	}








	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}








	public String getFileName() {
		return fileName;
	}








	public void setFileName(String fileName) {
		this.fileName = fileName;
	}








	public String getFileFormat() {
		return fileFormat;
	}








	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}








	public String getDeleteYn() {
		return deleteYn;
	}








	public void setDeleteYn(String deleteYn) {
		this.deleteYn = deleteYn;
	}








	public String getRegType() {
		return regType;
	}








	public void setRegType(String regType) {
		this.regType = regType;
	}








	public String getRegId() {
		return regId;
	}








	public void setRegId(String regId) {
		this.regId = regId;
	}








	public String getRegDt() {
		return regDt;
	}








	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}








	public String getModType() {
		return modType;
	}








	public void setModType(String modType) {
		this.modType = modType;
	}








	public String getModId() {
		return modId;
	}








	public void setModId(String modId) {
		this.modId = modId;
	}








	public String getModDt() {
		return modDt;
	}








	public void setModDt(String modDt) {
		this.modDt = modDt;
	}








	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


}
