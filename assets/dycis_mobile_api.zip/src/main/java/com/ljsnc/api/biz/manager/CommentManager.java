package com.ljsnc.api.biz.manager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ljsnc.api.biz.util.ApiResponse;
import com.ljsnc.api.exception.ManagedException;
import com.ljsnc.api.exception.ManagedExceptionCode;
import com.ljsnc.api.model.TnBillboardComment;
import com.ljsnc.api.model.TnBillboardInfo;
import com.ljsnc.api.mybatis.mappers.mysql.TnBadWordMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnBillboardCommentMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnBillboardInfoMapper;
import com.ljsnc.api.util.BadWordCheckUtil;
import com.ljsnc.api.util.CommonConstants;

@Service
public class CommentManager {

	@Autowired TnBillboardCommentMapper tnBillboardCommentMapper;
	@Autowired TnBillboardInfoMapper tnBillboardInfoMapper;
	@Autowired TnBadWordMapper tnBadWordMapper;

	/*
	 * 19.10.22. 댓글 목록
	 *
	 * @	userId	사용자ID
	 * @	biId		게시물 ID
	 */
	public Map<String, Object> getCommentList(Integer userId, Integer biId) {

		List<TnBillboardComment> commentList = tnBillboardCommentMapper.getCommentList(userId, biId);

		if(commentList  == null)
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse(commentList);
	}

	/*
	 * 19.10.22. 댓글 목록
	 *
	 * @	userId	사용자ID
	 * @	biId		게시물 ID
	 */
	public Map<String, Object> commentWrite(Integer userId, Integer biId, String bcContents) {
		List<String> wordList = tnBadWordMapper.badWordList();
		String badWordList = String.join("|", wordList);

		bcContents = BadWordCheckUtil.filterText(bcContents, badWordList);

		int billboardCnt = tnBillboardInfoMapper.cntBillboardInfoByBiId(biId);

		if(billboardCnt <= 0 )
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		TnBillboardComment tnbillboardComment =new TnBillboardComment();

		tnbillboardComment.setBcContents(bcContents);
		tnbillboardComment.setBiId(biId);
		tnbillboardComment.setRegId(Integer.toString(userId));
		tnbillboardComment.setModId(Integer.toString(userId));

		tnBillboardCommentMapper.setComment(tnbillboardComment);

		HashMap<String,Object> result = new HashMap<String, Object>();
		result.put("bcId", tnbillboardComment.getBcId());

		return ApiResponse.makeResponse(result);
	}

	public Map<String, Object> commentDelete(Integer userId, Integer bcId) {
		int result = tnBillboardCommentMapper.commentDelete(userId, bcId);

		if(result <= 0 )
			throw new ManagedException(ManagedExceptionCode.FailDeleteBillboardInfo, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse();
	}

}
