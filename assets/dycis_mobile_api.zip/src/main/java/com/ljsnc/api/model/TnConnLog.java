package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TnConnLog implements Serializable  {
	private static final long serialVersionUID = 1L;
	
	private int clId;
	private String userLoginId;
	private String deviceKind;
	private String connDt;
	
	public int getClId() {
		return clId;
	}
	public void setClId(int clId) {
		this.clId = clId;
	}
	public String getUserLoginId() {
		return userLoginId;
	}
	public void setUserLoginId(String userLoginId) {
		this.userLoginId = userLoginId;
	}
	public String getDeviceKind() {
		return deviceKind;
	}
	public void setDeviceKind(String deviceKind) {
		this.deviceKind = deviceKind;
	}
	public String getConnDt() {
		return connDt;
	}
	public void setConnDt(String connDt) {
		this.connDt = connDt;
	}
	
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
