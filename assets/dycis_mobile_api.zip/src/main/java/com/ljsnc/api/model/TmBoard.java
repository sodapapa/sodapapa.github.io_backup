package com.ljsnc.api.model;

import java.io.Serializable;

public class TmBoard implements Serializable {
	private static final long serialVersionUID = -2534738590903544702L;
	
	private String idBoard;
	private String svcType;
	private String tpBoard;
	private String nmTitle;
	private String contents;
	private String idCom;
	private String idDept;
	private String cdJob;
	private String cntRead;
	private String ynDel;
	private String dtStart;
	private String dtEnd;
	private String idInsert;
	private String dtInsert;
	private String idUpdate;
	private String dtUpdate;
	
	public String getIdBoard() {
		return idBoard;
	}
	public void setIdBoard(String idBoard) {
		this.idBoard = idBoard;
	}
	public String getSvcType() {
		return svcType;
	}
	public void setSvcType(String svcType) {
		this.svcType = svcType;
	}
	public String getTpBoard() {
		return tpBoard;
	}
	public void setTpBoard(String tpBoard) {
		this.tpBoard = tpBoard;
	}
	public String getNmTitle() {
		return nmTitle;
	}
	public void setNmTitle(String nmTitle) {
		this.nmTitle = nmTitle;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getIdCom() {
		return idCom;
	}
	public void setIdCom(String idCom) {
		this.idCom = idCom;
	}
	public String getIdDept() {
		return idDept;
	}
	public void setIdDept(String idDept) {
		this.idDept = idDept;
	}
	public String getCdJob() {
		return cdJob;
	}
	public void setCdJob(String cdJob) {
		this.cdJob = cdJob;
	}
	public String getCntRead() {
		return cntRead;
	}
	public void setCntRead(String cntRead) {
		this.cntRead = cntRead;
	}
	public String getYnDel() {
		return ynDel;
	}
	public void setYnDel(String ynDel) {
		this.ynDel = ynDel;
	}
	public String getDtStart() {
		return dtStart;
	}
	public void setDtStart(String dtStart) {
		this.dtStart = dtStart;
	}
	public String getDtEnd() {
		return dtEnd;
	}
	public void setDtEnd(String dtEnd) {
		this.dtEnd = dtEnd;
	}
	public String getIdInsert() {
		return idInsert;
	}
	public void setIdInsert(String idInsert) {
		this.idInsert = idInsert;
	}
	public String getDtInsert() {
		return dtInsert;
	}
	public void setDtInsert(String dtInsert) {
		this.dtInsert = dtInsert;
	}
	public String getIdUpdate() {
		return idUpdate;
	}
	public void setIdUpdate(String idUpdate) {
		this.idUpdate = idUpdate;
	}
	public String getDtUpdate() {
		return dtUpdate;
	}
	public void setDtUpdate(String dtUpdate) {
		this.dtUpdate = dtUpdate;
	}
	
	@Override
	public String toString() {
		return "TmBoard [idBoard=" + idBoard + ", svcType=" + svcType + ", tpBoard=" + tpBoard + ", nmTitle=" + nmTitle
				+ ", contents=" + contents + ", idCom=" + idCom + ", idDept=" + idDept + ", cdJob=" + cdJob
				+ ", cntRead=" + cntRead + ", ynDel=" + ynDel + ", dtStart=" + dtStart + ", dtEnd=" + dtEnd
				+ ", idInsert=" + idInsert + ", dtInsert=" + dtInsert + ", idUpdate=" + idUpdate + ", dtUpdate="
				+ dtUpdate + "]";
	}
}
