package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

import com.ljsnc.api.model.TnPushSendLog;

public interface TnPushSendLogMapper {
	@SelectKey(before = false, keyProperty = "pslId", resultType = int.class, statement = ""
			+ "SELECT LAST_INSERT_ID() " )
	@Insert(""
			+ "INSERT INTO "
			+ "		tn_push_send_log(USER_ID"
			+ "						, PUSH_KEY "
			+ "						, PUSH_TYPE "
			+ "						, TITLE "
			+ "						, CONTENTS "
			+ "						, DEVICE_KIND "
			+ "						, SEND_SUCCESS_YN "
			+ "						, SEND_DT "
			+ "						, READ_YN) "
			+ "		VALUES(#{userId}	"
			+ "				,#{pushKey}	"
			+ "				,#{pushType}	"
			+ "				,#{title}	"
			+ "				,#{contents}	"
			+ "				,#{deviceKind}	"
			+ "				,#{sendSuccessYn}	"
			+ "				,now()	"
			+ "				,'N' )")
	public int insertPushLog(TnPushSendLog tnPushSendLog);
	
	@Select(""
			+ "SELECT "
			+ "		COUNT(*)	"
			+ "FROM	"
			+ "		tn_push_send_log	"
			+ "WHERE "
			+ "		USER_ID = #{userId}	")
	public int findPushLogListCnt(@Param("userId")int userId);
	
	@Select(""
			+ "SELECT "
			+ "		PSL_ID	"
			+ "		, USER_ID	"
			+ "		, PUSH_TYPE	"
			+ "		, TITLE	"
			+ "		, CONTENTS	"
			+ "		, DATE_FORMAT(SEND_DT, '%Y.%m.%d') as SEND_DT	"
			+ "		, READ_YN	"
			+ "FROM	"
			+ "		tn_push_send_log	"
			+ "WHERE "
			+ "		USER_ID = #{userId}	"
			+ "ORDER BY tn_push_send_log.SEND_DT DESC	"
			+ "LIMIT ${(pageNo*20)-20}, ${pageNo*20}	")
	public List<TnPushSendLog> findPushLogList(@Param("userId")int userId, @Param("pageNo")int pageNo);
	
	@Update(""
			+ "UPDATE	"
			+ "		tn_push_send_log	"
			+ "SET	"
			+ "		READ_YN = 'Y'	"
			+ "		, READ_DT = now() "
			+ "WHERE	"
			+ "		PSL_ID =  #{pslId}	"
			+ "		AND	USER_ID = #{userId}	")
	public int updatePushLog(@Param("pslId") int pslId, @Param("userId") int userId);

	@Select("SELECT "
			+ "		PSL_ID	"
			+ "		, USER_ID	"
			+ "		, PUSH_TYPE	"
			+ "		, TITLE	"
			+ "		, CONTENTS	"
			+ "		, DATE_FORMAT(SEND_DT, '%Y.%m.%d') as SEND_DT	"
			+ "FROM	"
			+ "		tn_push_send_log	"
			+ "WHERE	"
			+ "		PSL_ID = #{pslId}	"
			+ "		AND USER_ID = #{userId}")
	public TnPushSendLog findPushLogByPslId(@Param("pslId") int pslId, @Param("userId") int userId);
	
	@Update(""
			+ "UPDATE	"
			+ "		tn_push_send_log	"
			+ "SET	"
			+ "		SEND_SUCCESS_YN = #{sendSuccessYn}	"
			+ "		, READ_DT = now() "
			+ "WHERE	"
			+ "		PSL_ID =  #{pslId}	"
			+ "		AND	USER_ID = #{userId}	")
	public void updateSendSuccess(@Param("sendSuccessYn")String sendSuccessYn);
}
