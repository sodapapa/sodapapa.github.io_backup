package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

import com.ljsnc.api.model.TnUser;
import com.ljsnc.api.model.TnUserTokenMail;

public interface TnUserTokenMailMapper {


	@SelectKey(before = false, keyProperty="utmId", resultType = int.class, statement=""
			+ "SELECT LAST_INSERT_ID() ")
	@Insert(""
			+ "   INSERT INTO tn_user_token_mail   "
			+ "               (  "
			+ "                MAIL_TOKEN,   "
			+ "                MAIL_TYPE,   "
			+ "                USER_MAIL,   "
			+ "                CONFIRM_YN,   "
			+ "                REG_ID,   "
			+ "                REG_DT)   "
			+ "   VALUES (   "
			+ "           #{mailToken},   "
			+ "           #{mailType},   "
			+ "           #{userMail},   "
			+ "			  		'N',"
			+ "           #{regId},   "
			+ "           now() "
			+ "			)   "
			+ "      "
			+ "      "
			+ "")
	int insertUserTokenMail(TnUserTokenMail tnUserTokenMail);


	@Select(""
			+ "SELECT	"
			+ "		USER_LOGIN_ID	"
			+ "FROM	"
			+ "		tn_user	"
			+ "WHERE	"
			+ "		USER_EMAIL IN("
			+ "						SELECT "
			+ "							USER_EMAIL	"
			+ "						FROM"
			+ "							tn_user_token_mail	"
			+ "						WHERE "
			+ "							MAIL_TOKEN = #{token}"
			+ "					 )"
			+ "")
	List<TnUser> findId(@Param("token")String token);

	@Select(""
			+ "SELECT	"
			+ "		UTM_ID	"
			+ "		, USER_MAIL	"
			+ "		, MAIL_TYPE	"
			+ "		, CONFIRM_YN	"
			+ "		, REG_DT	"
			+ "FROM	"
			+ "		tn_user_token_mail	"
			+ "WHERE	"
			+ "		MAIL_TOKEN = #{token}"
			+ "")
	TnUserTokenMail findEmailByToken(@Param("token")String token);

	@Update(""
			+ "UPDATE	"
			+ "		tn_user_token_mail	"
			+ "SET	"
			+ "		CONFIRM_YN = 'Y'	"
			+ "WHERE	"
			+ "		UTM_ID = #{utmId}")
	int expiryTokenMail(@Param("utmId")int utmId);

}
