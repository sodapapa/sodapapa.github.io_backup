package com.ljsnc.api.mybatis.mappers.mysql;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ljsnc.api.model.TmConfigApi;

public interface TmConfigApiMapper {
	@Select("SELECT CONF_ID, CONF_NM, CONF_VAL, ID_INSERT, DT_INSERT, ID_UPDATE, DT_UPDATE FROM tm_config_api WHERE CONF_ID = #{confId}")
	TmConfigApi selectConfigApi(@Param("confId")String confId);
}
