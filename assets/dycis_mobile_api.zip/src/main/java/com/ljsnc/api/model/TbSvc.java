package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class TbSvc implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String svc_id;
	private String svc_nm;
	private String cust_id;
	private String cust_group_id;
	private String launcher_id;
	private String svc_state;
	private String memo;
	private String svc_start_dt;
	private String svc_stop_dt;
	private String svc_end_dt;                       
	private String stb_id;                                                     
	private String reg_dt;                                                 
	private String reg_id;
	private String mod_dt;
	private String mod_id;
	
	public String getSvc_id() {
		return svc_id;
	}
	public void setSvc_id(String svc_id) {
		this.svc_id = svc_id;
	}
	public String getSvc_nm() {
		return svc_nm;
	}
	public void setSvc_nm(String svc_nm) {
		this.svc_nm = svc_nm;
	}
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getCust_group_id() {
		return cust_group_id;
	}
	public void setCust_group_id(String cust_group_id) {
		this.cust_group_id = cust_group_id;
	}
	public String getLauncher_id() {
		return launcher_id;
	}
	public void setLauncher_id(String launcher_id) {
		this.launcher_id = launcher_id;
	}
	public String getSvc_state() {
		return svc_state;
	}
	public void setSvc_state(String svc_state) {
		this.svc_state = svc_state;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getSvc_start_dt() {
		return svc_start_dt;
	}
	public void setSvc_start_dt(String svc_start_dt) {
		this.svc_start_dt = svc_start_dt;
	}
	public String getSvc_stop_dt() {
		return svc_stop_dt;
	}
	public void setSvc_stop_dt(String svc_stop_dt) {
		this.svc_stop_dt = svc_stop_dt;
	}
	public String getSvc_end_dt() {
		return svc_end_dt;
	}
	public void setSvc_end_dt(String svc_end_dt) {
		this.svc_end_dt = svc_end_dt;
	}
	public String getStb_id() {
		return stb_id;
	}
	public void setStb_id(String stb_id) {
		this.stb_id = stb_id;
	}
	public String getReg_dt() {
		return reg_dt;
	}
	public void setReg_dt(String reg_dt) {
		this.reg_dt = reg_dt;
	}
	public String getReg_id() {
		return reg_id;
	}
	public void setReg_id(String reg_id) {
		this.reg_id = reg_id;
	}
	public String getMod_dt() {
		return mod_dt;
	}
	public void setMod_dt(String mod_dt) {
		this.mod_dt = mod_dt;
	}
	public String getMod_id() {
		return mod_id;
	}
	public void setMod_id(String mod_id) {
		this.mod_id = mod_id;
	}  
	
	@Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this);
    }
}
