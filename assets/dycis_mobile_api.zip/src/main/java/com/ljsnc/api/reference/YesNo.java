package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum YesNo {
	Yes("Y"),
	No("N")
	;
	
	private final String stringValue;

	private YesNo(final String newValue)
	{
	    stringValue = newValue;
	}
	
	@JsonValue
	public String toStr()
	{
	    return stringValue;
	}
	
	private static final Map<String, YesNo> lookup = new HashMap<String, YesNo>();
	
	static
	{
	    for (YesNo rt : YesNo.values())
	        lookup.put(rt.stringValue, rt);
	}
	
	public static YesNo get(String typeStr)
	{
	    return lookup.get(typeStr);
	}
}
