package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.springframework.transaction.annotation.Transactional;

import com.ljsnc.api.model.TnBillboard;
import com.ljsnc.api.model.TnBillboardComment;
import com.ljsnc.api.model.TnBillboardGallery;
import com.ljsnc.api.model.TnBillboardInfo;
import com.ljsnc.api.model.TnBillboardPds;

public interface TnBillboardCommentMapper {


	@Select(""
			+ "      "
			+ "  SELECT  "
			+ "    BC_ID,  "
			+ "    BI_ID,  "
			+ "    BC_CONTENTS,  "
			+ "    DELETE_YN,  "
			+ "    REG_TYPE,  "
			+ "    REG_ID AS WRITE_ID,  "
			+ "     DATE_FORMAT( REG_DT, '%Y%m%d%H%i%s') AS REG_DT,  "
			+ "    (SELECT user_nm FROM tn_user WHERE USER_ID = bc.REG_ID ) AS WRITE_NM  "
			+ "  FROM tn_billboard_comment bc  "
			+ "   WHERE bi_id = #{biId} and  DELETE_YN = 'N'  "
			+ "     ORDER BY REG_DT "
			+ "     "
			+ "")
	List<TnBillboardComment> getCommentList(@Param("userId")Integer userId, @Param("biId") Integer biId);

	@Transactional
	@SelectKey(before = false,  keyProperty = "bcId", resultType = int.class, statement = ""
			+ "SELECT LAST_INSERT_ID() as bcId" )
	@Insert( ""
			+ "  INSERT INTO tn_billboard_comment   "
			+ "              ("
			+ "               BI_ID,   "
			+ "               BC_CONTENTS,   "
			+ "               DELETE_YN,   "
			+ "               REG_TYPE,   "
			+ "               REG_ID,   "
			+ "               REG_DT,   "
			+ "               MOD_TYPE,   "
			+ "               MOD_ID,   "
			+ "               MOD_DT)   "
			+ "  VALUES (  "
			+ "          #{biId},   "
			+ "          #{bcContents},   "
			+ "          'N' ,   "
			+ "          'U',   "
			+ "          #{regId},   "
			+ "          now(),   "
			+ "          'U',   "
			+ "          #{modId},   "
			+ "          now()  )   "
			+ "")
	int setComment(TnBillboardComment tnbillboardComment);


	@Update(""
			+ "   "
			+ " update tn_billboard_comment set DELETE_YN = 'Y'  where BC_ID = #{bcId}"
			+ "   "
			+ "")
	int commentDelete(@Param("userId") Integer userId, @Param("bcId") Integer bcId);



}
