package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum UserType {
		//01 : 정회원 
		//02 : 준회원
	
		RegularMember("01"),
		AssociateMember("02")
		;
		
		private final String stringValue;

		private UserType(final String newValue)
		{
		    stringValue = newValue;
		}
		
		@JsonValue
		public String toStr()
		{
		    return stringValue;
		}
		
		private static final Map<String, UserType> lookup = new HashMap<String, UserType>();
		
		static
		{
		    for (UserType rt : UserType.values())
		        lookup.put(rt.stringValue, rt);
		}
		
		public static UserType get(String typeStr)
		{
		    return lookup.get(typeStr);
		}
}
