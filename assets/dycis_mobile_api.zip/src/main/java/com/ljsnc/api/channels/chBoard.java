package com.ljsnc.api.channels;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ljsnc.api.biz.manager.BillboardManager;
import com.ljsnc.api.biz.manager.CommentManager;
import com.ljsnc.api.exception.ManagedException;
import com.ljsnc.api.exception.ManagedExceptionCode;
import com.ljsnc.api.model.TnUserTokenInfo;
import com.ljsnc.api.mybatis.mappers.mysql.TnBadWordMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnBillboardInfoMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserTokenInfoMapper;
import com.ljsnc.api.reference.AuthKind;
import com.ljsnc.api.util.BadWordCheckUtil;
import com.ljsnc.api.util.CommonConstants;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;

@Path("bd")
@Produces({ MediaType.APPLICATION_JSON })
@Service
@Api(position = 700, value = "board", description = "board Info")
public class chBoard {

	@Autowired CommentManager commentManager;
	@Autowired BillboardManager billboardManager;
	@Autowired TnUserTokenInfoMapper tnUserTokenInfoMapper;
	@Autowired TnBadWordMapper tnBadWordMapper;
	@Autowired TnBillboardInfoMapper tnBillboardInfoMapper;


	private static final Logger logger = LoggerFactory.getLogger(chBoard.class);

	@Path("/billboard/info")
    @POST
    @ApiOperation(position = 701, value = "701. 게시판 정보", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br> { "
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
    		+ "<br> \"data\" : {  "
    		+ "<br>   \"billboardType\"  : \" 01\" ,  게시판타입  "
    		+ "<br>   \"billboardNm\"  : \"자유게시판\" ,  게시판이름  "
    		+ "<br>   \"writerType\"  : \"UCM\" ,  작성권한타입  "
    		+ "<br>   \"commentYn\"  : \"Y\" ,  댓글여부  "
    		+ "<br>   \"replyYn\"  : \"Y\" ,  답글여부  "
    		+ "<br>   \"useYn\"  : \"Y\" ,  사용여부  "
    		+ "<br>   \"biCnt\"  : \"5\" ,  게시물갯수  "
    		+ "<br>		}	"
    		+ "<br>}"
    		+ "<br>"
    		+ "</pre>"
    		)
    public Map<String, Object> billboardInfo(
    		@FormParam("authToken") 	@ApiParam(value="받는 사람의 메일주소", 	required = true) String authToken,
    		@FormParam("userId") 		@ApiParam(value="사용자ID (KEY)", 		required = true) Integer userId,
    		@FormParam("billboardId") 	@ApiParam(value="게시판 고유 아이디",		required = true) Integer billboardId
    		)
    {
		return this.billboardManager.getBillboardInfo(billboardId, userId);
    }



	@Path("/billboard/list")
	@POST
	@ApiOperation(position = 702, value = "702. 게시판 게시물 목록", notes = ""
			+ "<br><br><b>Response Sample</b>"
			+ "<pre>"
			+ "<br>{"
			+ "<br>	\"code\": 1000,					[코드]"
			+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
			+ "<br> 	\"data\" : {  "
			+ "<br>       	{"
			+ "<br>   			\"biId\"  : \"312\" ,   게시물고유ID "
			+ "<br>   			\"biTitle\"  : \"안녕하세요 관리자 입니다. 자료실 입니다.\" ,   게시물제목 "
			+ "<br>   			\"biContents\"  : \" 안녕하세요 관리자 입니다. 자료실 입니다.\" ,   게시물내용 "
			+ "<br>   			\"pBiId\"  : \"312\" ,   부모ID "
			+ "<br>   			\"rBiId\"  : \"312\" ,   이전ID "
			+ "<br>   			\"biDepth\"  : \"0\" ,   뎁스 (0,1,2) "
			+ "<br>   			\"noticeYn\"  : \"N\" ,   공지여부 "
			+ "<br>   			\"pwdYn\"  : \"\" ,   비밀번호 (없으면 '' )"
			+ "<br>   			\"likeCnt\"  : \"5\" ,   좋아요카운트 "
			+ "<br>   			\"readCnt\"  : \"5\" ,   읽은수 "
			+ "<br>   			\"regDate\"  : \"20191105103801\" ,   작성일자 "
			+ "<br>   			\"writeId\"  : \"1\" ,   작성자 아이디 "
			+ "<br>   			\"writeNm\"  : \"관리자\" ,   작성자명 "
			+ "<br>   			\"writeImg\"  : \"\" ,   작성자이미지 (현재 없음) "
			+ "<br>   			\"readYn\"  : \"Y\" ,   읽음여부 "
			+ "<br>   			\"likeYn\"  : \"N\" ,   좋아요여부 "
			+ "<br>   			\"galleryImg\"  : \"http://220.76.91.51:8051/pds/02/274/274_20191030181709.jpg\" ,   이미지 URL "
			+ "<br>   			\"\"  : \"\" ,    "
			+ "<br>       } , {} ,{} ....."
			+ "<br>		}	"
			+ "<br>}"
			+ "<br>"
			+ "</pre>"
			)
	public Map<String, Object> billboardList(
			@FormParam("authToken") 	@ApiParam(value="받는 사람의 메일주소", 	required = true) String authToken,
			@FormParam("userId") 		@ApiParam(value="사용자ID (KEY)", 		required = true) Integer userId,
			@FormParam("billboardId") 	@ApiParam(value="게시판 고유 아이디", 	required = true) Integer billboardId,
			@FormParam("pageNo") 		@ApiParam(value="페이지 번호", 				required = false) Integer pageNo,
			@FormParam("pageSize") 	@ApiParam(value="호출할 게시물 수", 		required = false) Integer pageSize,
			@FormParam("lastId") 			@ApiParam(value="마지막 게시물 번호", 	required = false) Integer lastId
			)
	{
		if(pageNo == null)  pageNo = 1;
		if(pageSize == null)  pageSize = 10;
		if(lastId == null)  lastId = 1;

		return this.billboardManager.getBillboardList(billboardId, pageNo, pageSize, lastId, userId);
	}

	@Path("/billboard/view")
    @POST
    @ApiOperation(position = 703, value = "703. 게시물 상세보기", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
    		+ "<br> \"data\" : {  "
			+ "<br>   			\"biTitle\"  : \"안녕하세요 관리자 입니다. 자료실 입니다.\" ,   게시물제목 "
			+ "<br>   			\"biContents\"  : \" 안녕하세요 관리자 입니다. 자료실 입니다.\" ,   게시물내용 "
			+ "<br>   			\"pBiId\"  : \"312\" ,   부모ID "
			+ "<br> 			 \"pwdValue\"  : \"\" ,  비밀번호"
			+ "<br>   			\"noticeYn\"  : \"N\" ,   공지여부 "
			+ "<br>   			\"likeCnt\"  : \"5\" ,   좋아요카운트 "
			+ "<br>   			\"readCnt\"  : \"5\" ,   읽은수 "
			+ "<br>   			\"regDate\"  : \"20191105103801\" ,   작성일자 "
			+ "<br>   			\"writeId\"  : \"1\" ,   작성자 아이디 "
			+ "<br>   			\"writeNm\"  : \"관리자\" ,   작성자명 "
			+ "<br>   			\"writeImg\"  : \"\" ,   작성자이미지 (현재 없음) "
			+ "<br>   			\"galleryImg\"  : \"http://220.76.91.51:8051/pds/02/274/274_20191030181709.jpg\" ,   이미지 URL "
    		+ "<br>		}	"
    		+ "<br>}"
    		+ "</pre>"
    		)
    public Map<String, Object> billboardView(
    		@FormParam("authToken") 	@ApiParam(value="받는 사람의 메일주소", 	required = true) String authToken,
    		@FormParam("userId")			@ApiParam(value="사용자ID (KEY)", 		required = true) Integer userId,
    		@FormParam("biId") 			@ApiParam(value="게시물 아이디", 			required = true) Integer biId,
    		@FormParam("pwdValue") 	@ApiParam(value="비밀번호", 					required = false) String pwdValue
    		)
    {
		return this.billboardManager.getBillboardView(userId, biId, pwdValue);
    }


	@Path("/billboard/write")
	@POST
	@ApiOperation(position = 704, value = "704. 게시물 작성 (수정)", notes = ""
			+ "<br><br><b>Response Sample</b>"
			+ "<pre>"
			+ "<br>{"
			+ "<br>	\"code\": 1000,					[코드]"
			+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
			+ "<br> \"data\" : {  "
			+ "<br>		\"biId\"  : \"\" , 게시물 아이디 "
			+ "<br>		}	"
			+ "<br>}"
			+ "<br>"
			+ "</pre>"
			)
	public Map<String, Object> billboardWrite(
			@ApiParam(value = "multipart로 파일정보를 보냄"	, required = false) MultipartBody body
			)
	{
		HashMap<String,String> paramMap = new HashMap<String,String>();
		String galleryDataNm = "";
		Attachment galleryData = null;

		if(body.getAttachment("galleryData") != null ){

			galleryDataNm = body.getAttachment("galleryData").getDataHandler().getName();
			galleryData = body.getAttachment("galleryData");
		}

		try {
			// Attachments 로 파라미터 setting
			for(Attachment att : body.getAllAttachments())	{

				String getHandlerNm = att.getDataHandler().getName();

				if (!att.getDataHandler().getName().equals(galleryDataNm)){
					// 이미지 파일 데이터는 따로 처리

					int avail = att.getDataHandler().getInputStream().available();
					byte[] buffer = new byte[avail];

					att.getDataHandler().getInputStream().read(buffer, 0, avail);
					String getHanderValue = new String(buffer);
					paramMap.put(getHandlerNm, getHanderValue);
				}
			}

			logger.debug("paramMap : " + paramMap.toString());

			int billboardId 	= (paramMap.get("billboardId") ==  null || "".equals(paramMap.get("billboardId")))  ? 0 : Integer.parseInt(paramMap.get("billboardId") );
			int pBiId 			= (paramMap.get("pBiId") ==  null || "".equals(paramMap.get("pBiId")))  ? 0 : Integer.parseInt(paramMap.get("pBiId"));
			int rBiId 			= (paramMap.get("rBiId") ==  null || "".equals(paramMap.get("rBiId")))  ? 0 : Integer.parseInt(paramMap.get("rBiId"));
			int biId 				= (paramMap.get("biId") ==  null || "".equals(paramMap.get("biId")))  ? 0 : Integer.parseInt(paramMap.get("biId"));
			int scId 			= (paramMap.get("scId") ==  null || "".equals(paramMap.get("scId")))  ? 0 : Integer.parseInt(paramMap.get("scId"));

			String authToken	= (paramMap.get("authToken") ==  null ||	paramMap.get("authToken") ==   "")  ? "" : paramMap.get("authToken") ;
			String userId			= (paramMap.get("userId") ==  null ||	paramMap.get("userId") ==   "")  ? "" : paramMap.get("userId") ;
			String biTitle 			= (paramMap.get("biTitle") ==  null ||			paramMap.get("biTitle") ==   "")  ? "" : paramMap.get("biTitle") ;
			String biContents	= (paramMap.get("biContents") ==  null ||	paramMap.get("biContents") ==   "")  ? "" : paramMap.get("biContents");
			String pwdValue 	= (paramMap.get("pwdValue") ==  null ||		paramMap.get("pwdValue") ==   "")  ? "" : paramMap.get("pwdValue");
			String galleryYn 		= (paramMap.get("galleryYn") ==  null ||		paramMap.get("galleryYn") ==   "")  ? "N" : paramMap.get("galleryYn");
			String galleryNm 		= (paramMap.get("galleryNm") ==  null ||		paramMap.get("galleryNm") ==   "")  ? "N" : paramMap.get("galleryNm");
			String biDepth 		= pBiId == 0 ? "0":"1";

			logger.debug("\n\r parameter Chek === > \n  billboardId :  {} , pBiId :  {} , rBiId :  {} , biTitle :  {} , biContents :  {} ,"
					+ " \n pwdValue :  {} , biId : {} , biDepth : {} ,scId :{} ,galleryYn :{}, galleryNm : {} \n\r" ,
					billboardId , pBiId , rBiId , biTitle , userId, biContents , pwdValue , biId, biDepth ,scId ,galleryYn, galleryNm);

			List<String> wordList = tnBadWordMapper.badWordList();

			String badWordList = String.join("|", wordList);

			biTitle = BadWordCheckUtil.filterText(biTitle, badWordList);
			biContents = BadWordCheckUtil.filterText(biContents, badWordList);

			// 인증 확인
			if(authToken.equals(""))
				throw new ManagedException(ManagedExceptionCode.AuthenticationError, CommonConstants.DEFAULT_FG_LANG);
			else
				this.authentication(paramMap.get("userId") , authToken );

			// 게시판 정보 확인
			if(billboardId <= 0 )
				throw new ManagedException(ManagedExceptionCode.NotExistBillboard, CommonConstants.DEFAULT_FG_LANG);

			// 게시판 쓰기 권한 확인
			int permitionCnt =  tnBillboardInfoMapper.getBillboardPermition(billboardId);

			if(permitionCnt <= 0 )
				throw new ManagedException(ManagedExceptionCode.NoAuthToWrite, CommonConstants.DEFAULT_FG_LANG);

			return this.billboardManager.setBilboardWrite(userId, billboardId , biId, biTitle ,  biContents , pBiId , rBiId , pwdValue ,
																					 biDepth ,scId ,galleryYn, galleryData ,galleryNm);

		} catch (ManagedException e1) {
			e1.printStackTrace();
			throw new ManagedException(e1.getExceptionCode(), CommonConstants.DEFAULT_FG_LANG);

		}catch (Exception e2) {

			e2.printStackTrace();
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}
	}

	@Path("/billboard/delete")
    @POST
    @ApiOperation(position = 705, value = "705. 게시물 삭제", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "<br>"
    		+ "</pre>"
    		)
    public Map<String, Object> billboardDelete(
			@FormParam("authToken") 	@ApiParam(value="받는 사람의 메일주소", 	required = true) String authToken,
			@FormParam("userId") 		@ApiParam(value="사용자ID (KEY)", 		required = true) Integer userId,
			@FormParam("biId") 			@ApiParam(value="게시물  아이디", 			required = true) Integer biId
    		)
    {

		return this.billboardManager.billboardDelete(userId,biId);

    }


	@Path("/comment/list")
	@POST
	@ApiOperation(position = 710, value = "710. 게시물 댓글 리스트", notes = ""
			+ "<br><br><b>Response Sample</b>"
			+ "<pre>"
			+ "<br>{"
			+ "<br>	\"code\": 1000,					[코드]"
			+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
			+ "<br> 	\"data\" : {  "
			+ "<br>       	{"
			+ "<br>   			\"bcId\"  : \"72\" ,  댓글ID"
			+ "<br>   			\"biId\"  : \"302\" ,  게시물ID  "
			+ "<br>   			\"bcContents\"  : \"등록합니다.\" ,  컨텐츠내용"
			+ "<br>   			\"regDt\"  : \"20191105103801\" ,  등록일자  "
			+ "<br>   			\"writeId\"  : \"2\" ,  댓글작성자이름"
			+ "<br>   			\"writeNm\"  : \"관리자\" ,  댓글작성자이름"
			+ "<br>   			\"writeImg\"  : \"\" ,  댓글작성자이미지 (현재 없음) "
			+ "<br>       } , {} ,{} ....."
			+ "<br>		}	"
			+ "<br>}"
			+ "<br>"
			+ "</pre>"
			)
	public Map<String, Object> commentList(
			@FormParam("authToken") 	@ApiParam(value="받는 사람의 메일주소", 	required = true) String authToken,
			@FormParam("userId") 		@ApiParam(value="사용자ID (KEY)", 		required = true) Integer userId,
			@FormParam("biId") 			@ApiParam(value="게시물  아이디", 			required = true) Integer biId
			)
	{
		return this.commentManager.getCommentList(userId, biId);
	}

	@Path("/comment/write")
	@POST
	@ApiOperation(position = 711, value = "711. 게시물 댓글 작성", notes = ""
			+ "<br><br><b>Response Sample</b>"
			+ "<pre>"
			+ "<br>{"
			+ "<br>	\"code\": 1000,					[코드]"
			+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
			+ "<br> \"data\" : {  "
			+ "<br>   			\"bcId\"  : \"\" ,  댓글ID"
			+ "<br>		}	"
			+ "<br>}"
			+ "<br>"
			+ "</pre>"
			)
	public Map<String, Object> commentWrite(
			@FormParam("authToken") 	@ApiParam(value="받는 사람의 메일주소", 	required = true) String authToken,
			@FormParam("userId") 		@ApiParam(value="사용자ID (KEY)", 		required = true) Integer userId,
			@FormParam("biId") 			@ApiParam(value="게시물  아이디", 			required = true) Integer biId,
			@FormParam("bcContents") 	@ApiParam(value="댓글 내용", 			required = false) String bcContents
			)
	{
		return this.commentManager.commentWrite(userId, biId, bcContents);
	}

	@Path("/comment/delete")
	@POST
	@ApiOperation(position = 712, value = "712. 게시물 댓글 작성", notes = ""
			+ "<br><br><b>Response Sample</b>"
			+ "<pre>"
			+ "<br>{"
			+ "<br>	\"code\": 1000,					[코드]"
			+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
			+ "<br> \"data\" : {  "
			+ "<br>   			\"bcId\"  : \"\" ,  댓글ID"
			+ "<br>		}	"
			+ "<br>}"
			+ "<br>"
			+ "</pre>"
			)
	public Map<String, Object> commentDelete(
			@FormParam("authToken") 	@ApiParam(value="받는 사람의 메일주소", 	required = true) String authToken,
			@FormParam("userId") 		@ApiParam(value="사용자ID (KEY)", 		required = true) Integer userId,
			@FormParam("bcId") 			@ApiParam(value="게시물  아이디", 			required = true) Integer bcId
			)
	{
		return this.commentManager.commentDelete(userId, bcId);
	}

	@Path("/best/list")
	@POST
	@ApiOperation(position = 720, value = "720. 베스트 글목록 ", notes = ""
			+ "<br><br><b>Response Sample</b>"
			+ "<pre>"
			+ "<br>{"
			+ "<br>	\"code\": 1000,					[코드]"
			+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
			+ "<br> \"data\" : {  "
			+ "<br>       	{"
			+ "<br>   			\"biId\"  : \"312\" ,   게시물고유ID "
			+ "<br>   			\"biTitle\"  : \"안녕하세요 관리자 입니다. 자료실 입니다.\" ,   게시물제목 "
			+ "<br>   			\"biContents\"  : \" 안녕하세요 관리자 입니다. 자료실 입니다.\" ,   게시물내용 "
			+ "<br>   			\"pBiId\"  : \"312\" ,   부모ID "
			+ "<br>   			\"rBiId\"  : \"312\" ,   이전ID "
			+ "<br>   			\"biDepth\"  : \"0\" ,   뎁스 (0,1,2) "
			+ "<br>   			\"noticeYn\"  : \"N\" ,   공지여부 "
			+ "<br>   			\"pwdYn\"  : \"\" ,   비밀번호 (없으면 '' )"
			+ "<br>   			\"likeCnt\"  : \"5\" ,   좋아요카운트 "
			+ "<br>   			\"readCnt\"  : \"5\" ,   읽은수 "
			+ "<br>   			\"regDate\"  : \"2019-11-01 13:52:39\" ,   작성일자 "
			+ "<br>   			\"writeId\"  : \"1\" ,   작성자 아이디 "
			+ "<br>   			\"writeNm\"  : \"관리자\" ,   작성자명 "
			+ "<br>   			\"writeImg\"  : \"\" ,   작성자이미지 (현재 없음) "
			+ "<br>   			\"readYn\"  : \"Y\" ,   읽음여부 "
			+ "<br>   			\"likeYn\"  : \"N\" ,   좋아요여부 "
			+ "<br>   			\"\"  : \"\" ,    "
			+ "<br>       } , {} ,{} ....."
			+ "<br>		}	"
			+ "<br>		}	"
			+ "<br>}"
			+ "<br>"
			+ "</pre>"
			)
	public Map<String, Object> bestList(
			@FormParam("authToken") 	@ApiParam(value="받는 사람의 메일주소", 	required = true) String authToken,
			@FormParam("userId") 		@ApiParam(value="사용자ID (KEY)", 		required = true) Integer userId,
			@FormParam("pageNo") 		@ApiParam(value="게시물  아이디", 			required = false) Integer pageNo
			)
	{
		if(pageNo == null) pageNo = 1;

		int pageSize = 10;

		return this.billboardManager.bestList(userId, pageNo,pageSize);
	}



	@Path("/billboard/like")
	@POST
	@ApiOperation(position = 730, value = "730. 게시물 좋아요", notes = ""
			+ "<br><br><b>Response Sample</b>"
			+ "<pre>"
			+ "<br>{"
			+ "<br>	\"code\": 1000,					[코드]"
			+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
			+ "<br> \"data\" : {  "
			+ "<br>   			\"biId\"  : \"302\" ,  게시물 아이디"
			+ "<br>		}	"
			+ "<br>}"
			+ "<br>"
			+ "</pre>"
			)
	public Map<String, Object> billboardLike(
			@FormParam("authToken") 	@ApiParam(value="받는 사람의 메일주소", 	required = true) String authToken,
			@FormParam("userId") 		@ApiParam(value="사용자ID (KEY)", 		required = true) Integer userId,
			@FormParam("biId") 			@ApiParam(value="게시물  아이디", 			required = true) Integer biId
			)
	{
		return this.billboardManager.billboardLike(userId, biId);
	}


	/*
	 * 19.10.16.
	 * 홍동희
	 * 파라미터를 멀티파트로 받을떄 authToken을 intercepter에서 처리하지 못하여 별도의 메소드로 처리
	 * authToken을 따로 받으면 이메서드를 사용하지 않아도 됨
	 */
	private void authentication(String userId, String authToken) {

		TnUserTokenInfo tnUserTokenInfo = null;
		try {
			tnUserTokenInfo = new TnUserTokenInfo();

			tnUserTokenInfo.setUserId(Integer.parseInt(userId));
			tnUserTokenInfo.setAuthToken(authToken);
			tnUserTokenInfo.setAuthKind(AuthKind.USER.toStr());
		} catch(Exception e) {
			e.printStackTrace();
		}

		if(!authToken.equals("test1234")) {

		List<TnUserTokenInfo> tokenInfo = tnUserTokenInfoMapper.isToken(tnUserTokenInfo);

		try {
				if( tokenInfo.size() <= 0) {
					throw new ManagedException(ManagedExceptionCode.AuthenticationError, CommonConstants.DEFAULT_FG_LANG);
				}else {

						SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						Date tokenRgDt;
						tokenRgDt = dt.parse(tokenInfo.get(0).getRegDt());
						Date now = new Date();

						int tokenAavilableTime = CommonConstants.USER_AUTH_TOKEN_AVAILABLE_TIME;

						long tokenTime = ((now.getTime() - tokenRgDt.getTime()) / 1000 );

						if(tokenTime >= tokenAavilableTime) {
							tnUserTokenInfoMapper.deleteToken(tnUserTokenInfo);
							throw new ManagedException(ManagedExceptionCode.AuthTokenExpired, CommonConstants.DEFAULT_FG_LANG);
						}

					tnUserTokenInfoMapper.updateRegDtToken(tnUserTokenInfo);
					}
				} catch (ParseException e) {
					e.printStackTrace();
				} catch (ManagedException e1) {
					e1.printStackTrace();
					throw new ManagedException(e1.getExceptionCode(), CommonConstants.DEFAULT_FG_LANG);

				}catch (Exception e2) {
					e2.printStackTrace();
					throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
				}
			}
		}
}
