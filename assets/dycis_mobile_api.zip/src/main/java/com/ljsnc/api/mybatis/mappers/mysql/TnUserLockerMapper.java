package com.ljsnc.api.mybatis.mappers.mysql;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;

import com.ljsnc.api.model.TnUserLocker;
import com.ljsnc.api.model.response.DtoUserInfo;

public interface TnUserLockerMapper {


	@SelectKey(before = false, keyProperty="ulId", resultType = int.class, statement=""
			+ "SELECT LAST_INSERT_ID() ")
	@Insert(""
			+ "   INSERT INTO tn_user_locker(   "
			+ "               SC_ID,"
			+ "				USER_ID,  "
			+ "				LOCKER_NO,   "
			+ "             "
			+ "			    START_DATE,   "
			+ "                END_DATE,   "
			+ "                START_TIME,   "
			+ "                END_TIME,   "
			+ "               "
			+ "				 REG_ID,   "
			+ "                REG_DT   "
			+ "  ) VALUES (   "
			+ "           #{scId},   "
			+ "           #{userId},   "
			+ "           #{lockerNo},   "
			+ "           "
			+ "			#{startDate},   "
			+ "           #{endDate},   "
			+ "           #{startTime},   "
			+ "           #{endTime},   "
			+ "			"
			+ "			 #{regId}, "
			+ "          now()   "
			+ "      		)"
			+ "      "
			+ "")
	int insertUserLocker(TnUserLocker tnUserLocker);

	@Select("<script>"
			+ "  SELECT   "
			+ "    UL_ID,   "
			+ "    USER_ID,   "
			+ "    SC_ID,   "
			+ "    LOCKER_NO,   "
			+ "    START_DATE,   "
			+ "    END_DATE,   "
			+ "    START_TIME,   "
			+ "    END_TIME,   "
			+ "    REG_ID,   "
			+ "    REG_DT   "
			+ "  FROM tn_user_locker   "
			+ "   where USER_ID = #{userId}  "
			+ "   AND  STR_TO_DATE(CONCAT(end_date,end_time), '%y %m %d %H %i %s') <![CDATA[  >= ]]> DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s') "
			+ "	order by REG_DT desc "
			+ "	limit 1 "
			+ "</script>")
	DtoUserInfo getUserLockerInfo(@Param("userId") Integer userId);

}
