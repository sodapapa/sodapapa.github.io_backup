package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TnUserMapping implements Serializable  {
	private static final long serialVersionUID = 1L;

	private int umId;
	private int userId;
	private int scId;

	private String fmIdS;
	private String memberNO;

	private String userKey;

	private String regId;
	private String regDt;
	private String modId;
	private String modDt;




	public int getScId() {
		return scId;
	}




	public void setScId(int scId) {
		this.scId = scId;
	}




	public String getFmIdS() {
		return fmIdS;
	}




	public void setFmIdS(String fmIdS) {
		this.fmIdS = fmIdS;
	}




	public String getMemberNO() {
		return memberNO;
	}




	public void setMemberNO(String memberNO) {
		this.memberNO = memberNO;
	}




	public String getRegId() {
		return regId;
	}




	public void setRegId(String regId) {
		this.regId = regId;
	}




	public int getUmId() {
		return umId;
	}




	public void setUmId(int umId) {
		this.umId = umId;
	}




	public int getUserId() {
		return userId;
	}




	public void setUserId(int userId) {
		this.userId = userId;
	}




	public String getUserKey() {
		return userKey;
	}




	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}




	public String getRegDt() {
		return regDt;
	}




	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}




	public String getModId() {
		return modId;
	}




	public void setModId(String modId) {
		this.modId = modId;
	}




	public String getModDt() {
		return modDt;
	}




	public void setModDt(String modDt) {
		this.modDt = modDt;
	}




	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
