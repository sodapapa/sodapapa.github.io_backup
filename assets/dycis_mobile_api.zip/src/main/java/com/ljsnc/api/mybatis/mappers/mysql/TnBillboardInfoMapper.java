package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

import com.ljsnc.api.model.TnBillboard;
import com.ljsnc.api.model.TnBillboardComment;
import com.ljsnc.api.model.TnBillboardInfo;
import com.ljsnc.api.model.response.DtoQnaView;

public interface TnBillboardInfoMapper {

	@Select("<script>"
			+ "   SELECT    "
			+ "     bi.BI_ID,   "
			+ "     bi.BI_TITLE,   "
			+ "     bi.BI_CONTENTS,   "
			+ "     bi.P_BI_ID,   "
			+ "     bi.R_BI_ID,   "
			+ "     bi.BI_DEPTH,   "
			+ "     bi.NOTICE_YN,   "
			+ "     bi.DELETE_YN,   "
			+ "	  bi.REG_ID AS writeId , "
			+ "     DATE_FORMAT( bi.REG_DT, '%Y%m%d%H%i%s') AS regDate,  "
			+ "     IF(IFNULL(bi.PWD_VALUE, 'N') != 'N','Y','N') AS pwd_Yn,   "
			+ "     (SELECT user_nm FROM tn_user u WHERE u.user_id = bi.reg_id) AS writeNm,   "
			+ "     (SELECT COUNT(*) FROM tn_billboard_read br WHERE bi.bi_id = br.bi_id) AS readCnt,   "
			+ "     (SELECT COUNT(*) FROM tn_billboard_like bl WHERE bi.bi_id = bl.bi_id) AS likeCnt,   "
			+ "     IF((SELECT COUNT(*) FROM tn_billboard_read br WHERE bi.bi_id = br.bi_id AND br.user_id = #{userId}) > 0, 'Y', 'N' ) AS readYn,   "
			+ "     IF((SELECT COUNT(*) FROM tn_billboard_like bl WHERE bi.bi_id = bl.bi_id AND bl.user_id = #{userId}) > 0, 'Y', 'N' ) AS likeYn   "
			+ "	  , bg.FILE_PATH  AS gallery_img "
			+ "   FROM   "
			+ "     tn_billboard_info bi LEFT OUTER JOIN tn_billboard_gallery bg ON bi.BI_ID = bg.BI_ID   "
			+ "   WHERE bi.DELETE_YN = 'N'    "
			+ "     AND bi.BILLBOARD_ID = #{billboardId}    "
			+ "	<choose>"
			+ "		<when test=\"billboardId == 14 \">	"
			+ "			  ORDER BY   bi.P_BI_ID    DESC  , bi.BI_ORDER   "
			+ "		</when>"
			+ "		<otherwise>"
			+ "     		ORDER BY regDate DESC   "
			+ "		</otherwise>"
			+ "	</choose>"
			+ "	"
			+ "	LIMIT  ${(pageNo - 1) * (pageSize)} , ${ pageSize}"
			+ ""
			+ "</script>")
	List<TnBillboardInfo> getBillboardList(@Param("billboardId") Integer billboardId, @Param("pageNo") Integer pageNo,
											@Param("pageSize") Integer pageSize, @Param("lastId")  Integer lastId,@Param("userId")  Integer userId);

	@Select("<script>"
			+ "   (SELECT    "
			+ "     bi.BI_ID,   "
			+ "     bi.BI_TITLE,   "
			+ "     bi.BI_CONTENTS,   "
			+ "     bi.P_BI_ID,   "
			+ "     bi.R_BI_ID,   "
			+ "     bi.BI_DEPTH,   "
			+ "     bi.NOTICE_YN,   "
			+ "     bi.DELETE_YN,   "
			+ "	  bi.REG_ID AS writeId , "
			+ "     DATE_FORMAT( bi.REG_DT, '%Y%m%d%H%i%s') AS regDate,  "
			+ "     IF(IFNULL(bi.PWD_VALUE, 'N') != 'N','Y','N') AS pwd_Yn,   "
			+ "     (SELECT user_nm FROM tn_user u WHERE u.user_id = bi.reg_id) AS writeNm,   "
			+ "     (SELECT COUNT(*) FROM tn_billboard_read br WHERE bi.bi_id = br.bi_id) AS readCnt,   "
			+ "     (SELECT COUNT(*) FROM tn_billboard_like bl WHERE bi.bi_id = bl.bi_id) AS likeCnt,   "
			+ "     IF((SELECT COUNT(*) FROM tn_billboard_read br WHERE bi.bi_id = br.bi_id AND br.user_id = #{userId}) > 0, 'Y', 'N' ) AS readYn,   "
			+ "     IF((SELECT COUNT(*) FROM tn_billboard_like bl WHERE bi.bi_id = bl.bi_id AND bl.user_id = #{userId}) > 0, 'Y', 'N' ) AS likeYn   "
			+ "	  , bg.FILE_PATH  AS gallery_img "
			+ "   FROM   "
			+ "     tn_billboard_info bi LEFT OUTER JOIN tn_billboard_gallery bg ON bi.BI_ID = bg.BI_ID   "
			+ "   WHERE bi.DELETE_YN = 'N'    "
			+ "     AND bi.BILLBOARD_ID = #{billboardId}  AND bi.REG_ID = #{userId} AND bi.P_BI_ID = 0  "
			+ "	)  UNION ALL "
			+ "   (SELECT    "
			+ "     bi.BI_ID,   "
			+ "     bi.BI_TITLE,   "
			+ "     bi.BI_CONTENTS,   "
			+ "     bi.P_BI_ID,   "
			+ "     bi.R_BI_ID,   "
			+ "     bi.BI_DEPTH,   "
			+ "     bi.NOTICE_YN,   "
			+ "     bi.DELETE_YN,   "
			+ "	  bi.REG_ID AS writeId , "
			+ "     DATE_FORMAT( bi.REG_DT, '%Y%m%d%H%i%s') AS regDate,  "
			+ "     IF(IFNULL(bi.PWD_VALUE, 'N') != 'N','Y','N') AS pwd_Yn,   "
			+ "     (SELECT user_nm FROM tn_user u WHERE u.user_id = bi.reg_id) AS writeNm,   "
			+ "     (SELECT COUNT(*) FROM tn_billboard_read br WHERE bi.bi_id = br.bi_id) AS readCnt,   "
			+ "     (SELECT COUNT(*) FROM tn_billboard_like bl WHERE bi.bi_id = bl.bi_id) AS likeCnt,   "
			+ "     IF((SELECT COUNT(*) FROM tn_billboard_read br WHERE bi.bi_id = br.bi_id AND br.user_id = #{userId}) > 0, 'Y', 'N' ) AS readYn,   "
			+ "     IF((SELECT COUNT(*) FROM tn_billboard_like bl WHERE bi.bi_id = bl.bi_id AND bl.user_id = #{userId}) > 0, 'Y', 'N' ) AS likeYn   "
			+ "	  , bg.FILE_PATH  AS gallery_img "
			+ "   FROM   "
			+ "     tn_billboard_info bi LEFT OUTER JOIN tn_billboard_gallery bg ON bi.BI_ID = bg.BI_ID   "
			+ "   WHERE bi.DELETE_YN = 'N'    "
			+ "     AND bi.BILLBOARD_ID = #{billboardId}  "
			+ "	  AND bi.P_BI_ID IN (SELECT BI_ID FROM tn_billboard_info WHERE reg_Id = #{userId} ) "
			+ "	)"
			+ "	  ORDER BY   IF(P_BI_ID  <![CDATA[ <= ]]> 0,  BI_ID, P_BI_ID)  DESC  "
			+ "	LIMIT  ${(pageNo - 1) * (pageSize)} , ${ pageSize} "
			+ "		"
			+ "</script>")
	List<TnBillboardInfo> get11InquiryList(@Param("billboardId") Integer billboardId, @Param("pageNo") Integer pageNo,
															@Param("pageSize") Integer pageSize, @Param("lastId")  Integer lastId,@Param("userId")  Integer userId);

	@Select(""
			+ "   SELECT    "
			+ "     bi.BI_ID,   "
			+ "     bi.BI_TITLE,   "
			+ "     bi.BI_CONTENTS,   "
			+ "     bi.P_BI_ID,   "
			+ "     bi.R_BI_ID,   "
			+ "     bi.BI_DEPTH,   "
			+ "     bi.NOTICE_YN,   "
			+ "     bi.DELETE_YN,   "
			+ "     bi.REG_ID AS writeId ,   "
			+ "     DATE_FORMAT( bi.REG_DT, '%Y%m%d%H%i%s') AS regDate, "
			+ "     IF(IFNULL(bi.PWD_VALUE, 'N') != 'N','Y','N') AS PWD_YN,   "
			+ "     bi.READ_CNT,   "
			+ "     bi.LIKE_CNT,   "
			+ "     (SELECT user_nm FROM tn_user u WHERE u.user_id = bi.reg_id) AS WRITE_NM,   "
			+ "     IF((SELECT COUNT(BI_ID) FROM tn_billboard_read br WHERE bi.bi_id = br.bi_id AND br.user_id = #{userId}) > 0, 'Y', 'N' ) AS READ_YN,   "
			+ "     IF((SELECT COUNT(BI_ID) FROM tn_billboard_like bl WHERE bi.bi_id = bl.bi_id AND bl.user_id = #{userId}) > 0, 'Y', 'N' ) AS LIKE_YN  "
			+ "    "
			+ "	 , bg.FILE_PATH AS gallery_img  "
			+ "    , bp.FILE_PATH  AS pds_url   "
			+ "     "
			+ "   FROM   "
			+ "     tn_billboard_info bi LEFT OUTER JOIN tn_billboard_gallery bg ON bi.BI_ID = bg.BI_ID  "
			+ "	   LEFT OUTER JOIN tn_billboard_pds bp ON bi.BI_ID = bp.BI_ID   	 "
			+ "   WHERE bi.DELETE_YN = 'N'    "
			+ "     AND bi.BI_ID = #{biId}    "
			+ "      "
			+ ""
			+ "")
	TnBillboardInfo getBillboardView(@Param("userId") Integer userId, @Param("biId") Integer biId,@Param("pwdValue") String pwdValue);


	@SelectKey(before = false, keyProperty = "biId", resultType = int.class, statement = ""
			+ "SELECT LAST_INSERT_ID() " )
	@Insert(""
			+ "   INSERT INTO tn_billboard_info   "
			+ "               (   "
			+ "                BILLBOARD_ID,   "
			+ "                BI_TITLE,   "
			+ "                BI_CONTENTS,   "
			+ "                P_BI_ID,   "
			+ "                R_BI_ID,   "
			+ "                BI_DEPTH,   "
			+ "                NOTICE_YN,   "
			+ "                DELETE_YN,   "
			+ "                PWD_VALUE,   "
			+ "                SC_ID,   "
			+ "				"
			+ "                REG_TYPE,   "
			+ "                REG_ID,   "
			+ "                REG_DT,   "
			+ "                MOD_TYPE,   "
			+ "                MOD_ID,   "
			+ "                MOD_DT)   "
			+ "   VALUES (   "
			+ "           #{billboardId},   "
			+ "           #{biTitle},   "
			+ "           #{biContents},   "
			+ "           #{pBiId},   "
			+ "           #{rBiId},   "
			+ "           #{biDepth},   "
			+ "           #{noticeYn},   "
			+ "           #{deleteYn},   "
			+ "           #{pwdValue},   "
			+ "           #{scId},   	"
			+ "             "
			+ "           #{regType},   "
			+ "           #{regId},   "
			+ "           now() ,   "
			+ "           #{modType},   "
			+ "           #{modId},   "
			+ "           now() )   "
			+ "      "
			+ "      "
			+ "      ")
	int createBillboardInfo(TnBillboardInfo tnBillboardInfo);

	@Update(""
			+ "  UPDATE tn_billboard_info  "
			+ "  SET   "
			+ "    BI_TITLE = #{biTitle},  "
			+ "    BI_CONTENTS = #{biContents},  "
			+ "    PWD_VALUE = #{pwdValue},  "
			+ "    MOD_TYPE = #{modType},  "
			+ "    MOD_ID = #{modId},  "
			+ "    MOD_DT = now()  "
			+ "  WHERE BI_ID = #{biId}  "
			+ "    "
			+ "    "
			+ "")
	int updateBillboardInfo(TnBillboardInfo tnBillboardInfo);

	@Select(""
			+ "     "
			+ "  SELECT    "
			+ "    COUNT(1)    "
			+ "  FROM   "
			+ "    tn_billboard_info    "
			+ "  WHERE bi_Id = #{biId}    "
			+ "    AND DELETE_YN = 'N'    "
			+ "     "
			+ "     "
			+ "     "
			+ "")
	int cntBillboardInfoByBiId(@Param("biId") Integer biId);




	@Select(""
			+ ""
			+ "	SELECT BILLBOARD_ID FROM tn_billboard b WHERE b.USE_YN = 'Y'	"
			+ ""
			+ "")
	List<TnBillboard> getBillboardIdList();



	@Select(" <script> "
			+ " "
			+ ""
			+ " (SELECT    "
			+ "    (bi.like_cnt * 3)  like_point,   "
			+ "    bi.read_cnt,   "
			+ "    (   "
			+ "      (IFNULL(bi.like_cnt, 0) * 3) + IFNULL(bi.read_cnt, 0)   "
			+ "    ) AS point_sum,   "
			+ "    bi.bi_id,   "
			+ "    bi.BI_TITLE,   "
			+ "    bi.BI_CONTENTS,   "
			+ "    bi.P_BI_ID,   "
			+ "    bi.R_BI_ID,   "
			+ "    bi.BI_DEPTH,   "
			+ "    bi.NOTICE_YN , "
			+ "      bi.READ_CNT,      "
			+ "     bi.LIKE_CNT,      "
			+ "	 bi.REG_ID AS WRITE_ID,  "
			+ "    (SELECT user_nm FROM tn_user u WHERE u.user_id = bi.REG_ID ) AS writeNm,   "
			+ "    DATE_FORMAT( bi.REG_DT, '%Y%m%d%H%i%s') AS regDate,     "
			+ "    IF(IFNULL(bi.PWD_VALUE, 'N') != 'N','Y','N') AS pwd_Yn,      "
			+ "    (SELECT user_nm FROM tn_user u WHERE u.user_id = bi.reg_id) AS writeNm,      "
			+ "    IF((SELECT COUNT(*) FROM tn_billboard_read br WHERE bi.bi_id = br.bi_id AND br.user_id = #{userId}) > 0, 'Y', 'N' ) AS readYn,      "
			+ "    IF((SELECT COUNT(*) FROM tn_billboard_like bl WHERE bi.bi_id = bl.bi_id AND bl.user_id = #{userId}) > 0, 'Y', 'N' ) AS likeYn        "
			+ "       "
			+ "  FROM   "
			+ "    tn_billboard b,   "
			+ "    tn_billboard_info bi    "
			+ "  WHERE b.BILLBOARD_ID = bi.BILLBOARD_ID    "
			+ "    AND b.BILLBOARD_ID =  #{billboardId}    "
			+ "    AND bi.DELETE_YN = 'N'    "
			+ "  ORDER BY point_sum DESC 		   "
			+ "  LIMIT 10   "
			+ "  )   "
			+ "	ORDER BY point_sum DESC 	"
			+ "	LIMIT  5 "
			+ "   "
			+ "</script>")
	List<TnBillboardInfo> getBestList(@Param("userId") Integer userId, @Param("pageNo") Integer pageNo,
				@Param("pageSize") int pageSize, @Param("billboardId")  int billboardId);


	@Select(""
			+ "  SELECT * FROM    "
			+ "      "
			+ "  (SELECT     "
			+ "    bi.BI_ID,    "
			+ "    bi.BI_TITLE,    "
			+ "    bi.BI_CONTENTS,    "
			+ "    bi.P_BI_ID,    "
			+ "    bi.R_BI_ID,    "
			+ "    bi.BI_DEPTH,    "
			+ "    bi.NOTICE_YN,    "
			+ "    bi.DELETE_YN,   "
			+ "	bi.PWD_VALUE,	 "
			+ "    bi.REG_ID AS WRITE_ID,    "
			+ "    DATE_FORMAT(bi.REG_DT, '%Y%m%d%H%i%s') AS REG_DATE,    "
			+ "    IF( IFNULL(bi.PWD_VALUE, 'N') != 'N',    'Y',    'N'  ) AS PWD_YN,    "
			+ "    (SELECT user_nm   FROM    tn_user u   WHERE u.user_id = bi.reg_id) AS WRITE_NM,    "
			+ "    (SELECT IFNULL(COUNT(BI_ID), '0')   FROM    tn_billboard_read br   WHERE bi.bi_id = br.bi_id) AS READ_CNT,    "
			+ "    (SELECT IFNULL(COUNT(BI_ID), '0') AS LIKE_CNT   FROM    tn_billboard_like bl   WHERE bi.bi_id = bl.bi_id) AS LIKE_CNT,    "
			+ "     bg.FILE_PATH AS GALLERY_IMG     "
			+ "  FROM    "
			+ "    tn_billboard_info bi     "
			+ "    LEFT OUTER JOIN tn_billboard_gallery bg     "
			+ "      ON bi.BI_ID = bg.BI_ID     "
			+ "  WHERE bi.DELETE_YN = 'N'     "
			+ "    AND bi.BI_ID = #{biId} ) A ,     "
			+ "      "
			+ "  ( SELECT    "
			+ "    bi.BI_ID AS Q_BI_ID,    "
			+ "    bi.BI_TITLE AS Q_BI_TITLE,    "
			+ "    bi.BI_CONTENTS AS Q_BI_CONTENTS,    "
			+ "    bi.P_BI_ID AS Q_P_BI_ID,    "
			+ "    bi.R_BI_ID AS Q_R_BI_ID,    "
			+ "    bi.BI_DEPTH AS Q_BI_DEPTH,    "
			+ "    bi.NOTICE_YN AS Q_NOTICE_YN,    "
			+ "    bi.PWD_VALUE AS Q_PWD_VALUE ,  "
			+ "    bi.REG_ID AS Q_Writer_id,    "
			+ "    DATE_FORMAT(bi.REG_DT, '%Y%m%d%H%i%s') AS Q_REG_DATE ,    "
			+ "    IF(    IFNULL(bi.PWD_VALUE, 'N') != 'N',    'Y',    'N'  ) AS Q_PWD_YN,    "
			+ "    (SELECT     user_nm   FROM    tn_user u   WHERE u.user_id = bi.reg_id) AS Q_WRITE_NM,    "
			+ "    (SELECT     IFNULL(COUNT(BI_ID), '0')   FROM    tn_billboard_read br   WHERE bi.bi_id = br.bi_id) AS Q_READ_CNT,    "
			+ "    (SELECT     IFNULL(COUNT(BI_ID), '0') AS Q_LIKE_CNT   FROM    tn_billboard_like bl   WHERE bi.bi_id = bl.bi_id) AS Q_LIKE_CNT    "
			+ "      "
			+ "  FROM tn_billboard_info bi WHERE BI_ID = #{pBiId} AND bi.DELETE_YN = 'N' ) Q    "
			+ "      "
			+ ""
			+ "")
	DtoQnaView qnaView(@Param("userId")Integer userId, @Param("biId") Integer biId, @Param("pBiId") Integer pBiId, @Param("pwdValue") String pwdValue);



	@Update(""
			+ " UPDATE tn_billboard_info  "
			+ " SET  "
			+ "   DELETE_YN = 'Y',  "
			+ "   MOD_ID = #{userId},  "
			+ "   MOD_DT = now()  "
			+ " WHERE BI_ID = #{biId}  "
			+ "   "
			+ "    ")
	int billboardDelete(@Param("biId") Integer biId , @Param("userId") Integer userId);

	@Update(""
			+ "   "
			+ "UPDATE tn_billboard_info SET P_BI_ID = #{pBiId} , R_BI_ID = #{rBiId} , BI_ORDER = #{biOrder} , BI_DEPTH = #{biDepth} where BI_ID = #{biId}   "
			+ "   "
			+ "")
	int updatePBiId(@Param("biId") Integer biId, @Param("pBiId") int pBiId, @Param("rBiId") int rBiId ,  @Param("biOrder") int biOrder,  @Param("biDepth") String biDepth);

	@Select(""
			+ ""
			+ " SELECT COUNT(BI_ID)  FROM tn_billboard_info WHERE P_BI_ID =#{pBiId}   "
			+ ""
			+ "")
	int getMaxBiOrder(@Param("pBiId") int pBiId);


	@Update(""
			+ ""
			+ " UPDATE  tn_billboard_info  SET read_cnt  = #{readCnt}  WHERE bi_id = #{biId}   "
			+ ""
			+ "")
	void setReadCnt(HashMap<String, Object> param);

	@Update(""
			+ ""
			+ " UPDATE  tn_billboard_info  SET like_cnt  = #{likeCnt}  WHERE bi_id = #{biId}   "
			+ ""
			+ "")
	void setLikeCnt(HashMap<String, Object> param);

	@Select(""
			+ "   "
			+ " SELECT   "
			+ "   COUNT(BILLBOARD_ID) AS cnt   "
			+ " FROM  "
			+ "   tn_billboard   "
			+ " WHERE WRITER_TYPE LIKE ('%U%')   "
			+ "   AND BILLBOARD_ID = #{billboardId} "
			+ "   "
			+ "")
	int getBillboardPermition(@Param("billboardId") int billboardId);




}
