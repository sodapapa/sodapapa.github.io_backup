package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_DEFAULT)
public class TnBillboardLike implements Serializable{

	private static final long serialVersionUID = 1L;


	private int biId;
	private int userId;
	private String regDt;
	private int likeCnt;

	public int getLikeCnt() {
		return likeCnt;
	}

	public void setLikeCnt(int likeCnt) {
		 this.likeCnt = likeCnt;
	}

	public int getBiId() {
		return biId;
	}

	public void setBiId(int biId) {
		this.biId = biId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getRegDt() {
		return regDt;
	}

	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


}
