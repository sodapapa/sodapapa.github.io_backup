package com.ljsnc.api.biz.manager;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ljsnc.api.biz.util.ApiResponse;
import com.ljsnc.api.exception.ManagedException;
import com.ljsnc.api.exception.ManagedExceptionCode;
import com.ljsnc.api.model.TnSportsCenter;
import com.ljsnc.api.model.TnUser;
import com.ljsnc.api.model.TnUserAtnlc;
import com.ljsnc.api.mybatis.mappers.mysql.TnSportsCenterMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserAtnlcMapper;
import com.ljsnc.api.util.CommonConstants;

@Service
public class LectureManager {

	@Autowired TnSportsCenterMapper 	tnSportsCenterMapper;
	@Autowired TnUserAtnlcMapper tnUserAtnlcMapper;

	public Map<String, Object> getLectureList(Integer userId) {

		List<TnUserAtnlc> tnUserAtnlcList = tnUserAtnlcMapper.getLectureInfo(userId);

		if(tnUserAtnlcList == null)
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse(tnUserAtnlcList);
	}

}
