package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

import com.ljsnc.api.model.TnConnLog;
import com.ljsnc.api.model.TnUser;
import com.ljsnc.api.model.TnUserAtnlc;

public interface TnUserAtnlcMapper {

	@Select(""
			+ " SELECT  "
			+ "   UA_ID,  "
			+ "   USER_ID,  "
			+ "   TRANS_ID,  "
			+ "   ATNCL_NM,  "
			+ "   ATNCL_PRICE,  "
			+ "   START_DATE,  "
			+ "   END_DATE,  "
			+ "   START_TIME,  "
			+ "   END_TIME  "
			+ " FROM tn_user_atnlc  "
			+ " WHERE 1=1 "
			+ ""
			+ " AND user_id = #{userId}  "
			+ "  AND  END_DATE > DATE_FORMAT(NOW(), '%Y%m%d')  "
			+ "")
	List<TnUserAtnlc> getLectureInfo(Integer userId);

	@SelectKey(before = false, keyProperty="umId", resultType = int.class, statement=""
			+ "SELECT LAST_INSERT_ID() ")
	@Insert(""
			+ "   INSERT INTO tn_user_atnlc   "
			+ "               (   "
			+ "                USER_ID,   "
			+ "                TRANS_ID,   "
			+ "                ATNCL_NM,   "
			+ "                ATNCL_PRICE,   "
			+ "                START_DATE,   "
			+ "                END_DATE,   "
			+ "                START_TIME,   "
			+ "                END_TIME,   "
			+ "               "
			+ "				 REG_ID,   "
			+ "                REG_DT,   "
			+ "                MOD_ID,   "
			+ "                MOD_DT)   "
			+ "   VALUES (   "
			+ "           #{userId},   "
			+ "           #{transId},   "
			+ "           #{atnclNm},   "
			+ "           #{atnclPrice},   "
			+ "           #{startDate},   "
			+ "           #{endDate},   "
			+ "           #{startTime},   "
			+ "           #{endTime},   "
			+ "			"
			+ "			 #{regId}, "
			+ "          now(), "
			+ "          #{modId}, "
			+ "          now() ) "
			+ "      "
			+ "      "
			+ "")
	int insertUserAtnlc(TnUserAtnlc tnUserAtnlc);

}
