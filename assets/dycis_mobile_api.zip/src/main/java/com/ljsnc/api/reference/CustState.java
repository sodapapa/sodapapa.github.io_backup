package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum CustState {
	//가입중(01), 가입중지(02), 일시중지(03), 해지(04)
	Joining("01"),
	JoinStop("02"),
	Pause("03"),
	Withdraw("04")
	;
	
	private final String stringValue;

	private CustState(final String newValue)
	{
	    stringValue = newValue;
	}
	
	@JsonValue
	public String toStr()
	{
	    return stringValue;
	}
	
	private static final Map<String, CustState> lookup = new HashMap<String, CustState>();
	
	static
	{
	    for (CustState rt : CustState.values())
	        lookup.put(rt.stringValue, rt);
	}
	
	public static CustState get(String typeStr)
	{
	    return lookup.get(typeStr);
	}
}
