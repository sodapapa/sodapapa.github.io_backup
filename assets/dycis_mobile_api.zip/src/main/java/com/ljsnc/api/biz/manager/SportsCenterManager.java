package com.ljsnc.api.biz.manager;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ljsnc.api.biz.util.ApiResponse;
import com.ljsnc.api.exception.ManagedException;
import com.ljsnc.api.exception.ManagedExceptionCode;
import com.ljsnc.api.model.TnSportsCenter;
import com.ljsnc.api.model.TnSportsCenterImage;
import com.ljsnc.api.model.TnUser;
import com.ljsnc.api.mybatis.mappers.mysql.TnSportsCenterImageMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnSportsCenterMapper;
import com.ljsnc.api.util.CommonConstants;
import com.sun.istack.logging.Logger;

@Service
public class SportsCenterManager {

	@Autowired TnSportsCenterMapper 	tnSportsCenterMapper;
	@Autowired TnSportsCenterImageMapper 	tnSportsCenterImageMapper;

	public Map<String, Object> getCenterList(String searchType, String searchText, Integer pageNo) {

		int pageSize = 10;
		pageNo = pageNo ==null || pageNo == 0 ? 1 : pageNo;

		System.out.println("searchType  " +searchType + ", searchText " + searchText+ ",  pageNo: " +pageNo  );
		List<TnSportsCenter> SportsCenterList = tnSportsCenterMapper.getCenterList(searchType, searchText, pageNo,pageSize );

		if(SportsCenterList.size() <= 0)
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse(SportsCenterList);
	}



	public Map<String, Object> getCenterInfo(int scId) {

		TnSportsCenter sportsCenter = tnSportsCenterMapper.getCenterInfo(scId);

		if(sportsCenter == null )
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		List<TnSportsCenterImage> SportsCenterImageList =tnSportsCenterImageMapper.getCenterImage(scId);

		sportsCenter.setSportsCenterImage(SportsCenterImageList);

		return ApiResponse.makeResponse(sportsCenter);
	}



	public Map<String, Object> getMyCenterList(Integer userId) {
		List<TnSportsCenter> SportsCenterList = tnSportsCenterMapper.getMyCenterList(userId);

		if(SportsCenterList.size() <= 0)
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse(SportsCenterList);
	}

}
