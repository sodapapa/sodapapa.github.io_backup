package com.ljsnc.api.channels;

import java.util.Map;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ljsnc.api.biz.manager.MobileManager;
import com.ljsnc.api.util.EncryptUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;

@Path("fm")
@Produces({ MediaType.APPLICATION_JSON })
@Service
@Api(position = 100, value = "MOBILE", description = "MOBILE API")
public class chMobile {
	@Autowired MobileManager mobileManager;

	@Path("/intro/check")
    @POST
    @ApiOperation(position = 101, value = "1010. 앱실행", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>		\"appVer\": 101,				[fitmoa Application 버전]"
    		+ "<br>		\"apiVer\": 101,				[fitmoa Api 버전]"
    		+ "<br>		\"updateYn\": \"N\",			[fitmoa App 업데이트 존재 여부(Y, N)]"
    		+ "<br>		\"marketUrl\": \"market://aaa.com\",	[fitmoa App 앱스토어 마켓 URL]"
    		+ "<br>		\"keyString\": \"1234567890\",		[문자열 스트링]"
    		+ "<br>	}"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> introCheck(
    		@FormParam("appFlag") @ApiParam(value="앱관리", required = true) String appFlag,
    		@FormParam("deviceKind") @ApiParam(value="디바이스 종류. A:안드로이드, I:아이오에스", required = true) String deviceKind,
    		@FormParam("appVer") @ApiParam(value="앱버전", required = false) Integer appVer)

    {
		return this.mobileManager.introCheck(appFlag, deviceKind, appVer);
    }



	@Path("/user/login")
    @POST
    @ApiOperation(position = 201, value = "201. 로그인", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>		\"userId\": 1,				[fitmoa App 회원 고유 key 값]"
    		+ "<br>		\"authToken\": \"fitmoa\",			[fitmoa App 회원 로그인 아이디]"
    		+ "<br>		\"userNm\": \"김영철\",			[fitmoa App 회원 이름]"
    		+ "<br>		\"userGender\": \"01\",			[fitmoa App 회원 성별 (01: 남자, 02: 여자)]"
    		+ "<br>		\"userType\": \"01\",			[fitmoa App 회원 타입 (01: 정회원(매핑된 회원), 02: 준회원(매핑 안된 회원)]"
    		+ "<br>	}"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> userLogin(
    		@FormParam("userLoginId") @ApiParam(value="아이디", required = true) String userLoginId,
    		@FormParam("userPw") @ApiParam(value="비밀번호", required = true) String userPw,
    		@FormParam("deviceId") @ApiParam(value="deviceId", required = false) String deviceId,
    		@FormParam("deviceKind") @ApiParam(value="A:안드로이드, I:아이오에스", required = false) String deviceKind,
    		@FormParam("pushKey") @ApiParam(value="푸쉬 발송키", required = false) String pushKey,
    		@FormParam("EncryptYn") @ApiParam(value="암호화 여부. (Y, N)", required = false) String EncryptYn)

    {

		if("N".equals(EncryptYn)) {
			EncryptUtil enc = new EncryptUtil();
			userPw = enc.encryptSHA256(userPw);
		}

		return this.mobileManager.userLogin(userLoginId, userPw, deviceId, deviceKind, pushKey );
    }


	@Path("/user/reg")
    @POST
    @ApiOperation(position = 202, value = "202. 회원가입", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> userReg(
    		@FormParam("userLoginId") @ApiParam(value="아이디. 6자 이상 영문+숫자 또는 영문", required = true) String userLoginId,
    		@FormParam("userPw") @ApiParam(value="비밀번호. 특수문자,영어대소문자,숫자 10 ~ 16 자리 조합", required = true) String userPw,
    		@FormParam("userNm") @ApiParam(value="사용자이름. 이문렬", required = true) String userNm,
    		@FormParam("phoneNo") @ApiParam(value="핸드폰번호. 01047859456", required = true) String phoneNo,
    		@FormParam("userEmail") @ApiParam(value="이메일. jackson@gmail.com", required = true) String userEmail,
    		@FormParam("userBirthDay") @ApiParam(value="생년월일, 19981231", required = true) String userBirthDay,
    		@FormParam("userGender") @ApiParam(value="성별 ( 남: 01, 여: 02 )", required = true) String userGender,
    		@FormParam("userAddr") @ApiParam(value="주소. 서울시 송파구 문정동", required = false) String userAddr,
    		@FormParam("userAddrDetail") @ApiParam(value="상세주소. 테라타워2", required = false) String userAddrDetail,
    		@FormParam("pushKey") @ApiParam(value="푸쉬키. pushkeyString", required = false) String pushKey,
    		@FormParam("deviceId") @ApiParam(value="디바이스ID. (UUID, androidID)", required = true) String deviceId,
    		@FormParam("deviceKind") @ApiParam(value="디바이스 종류.  A:안드로이드, I:아이오에스", required = true) String deviceKind,
    		@FormParam("EncryptYn") @ApiParam(value="암호화 여부. (Y, N)", required = false) String EncryptYn )


    {

		if("N".equals(EncryptYn)) {
			EncryptUtil enc = new EncryptUtil();
			userPw = enc.encryptSHA256(userPw);
		}

		return this.mobileManager.userRegist(userLoginId, userPw, userNm, phoneNo, userEmail, userBirthDay, userGender, userAddr, userAddrDetail, pushKey, deviceId, deviceKind);
    }


	/*@Path("/user/sendsms")
    @POST
    @ApiOperation(position = 203, value = "203. 인증번호 발송", notes = "")
    public Map<String, Object> userSendsms(
    		@FormParam("appFlag") @ApiParam(value="앱관리", required = true) String appFlag,
    		@FormParam("deviceKind") @ApiParam(value="디바이스 종류", required = true) String deviceKind )

    {
		return this.mobileManager.introCheck(appFlag, deviceKind);
    }


	@Path("/user/findid")
    @POST
    @ApiOperation(position = 204, value = "204. 아이디 찾기", notes = "")
    public Map<String, Object> userFindid(
    		@FormParam("appFlag") @ApiParam(value="앱관리", required = true) String appFlag,
    		@FormParam("deviceKind") @ApiParam(value="디바이스 종류", required = true) String deviceKind )

    {
		return this.mobileManager.introCheck(appFlag, deviceKind);
    }

	@Path("/user/newpwd")
    @POST
    @ApiOperation(position = 205, value = "205. 비밀번호 변경", notes = "")
    public Map<String, Object> userNewpwd(
    		@FormParam("appFlag") @ApiParam(value="앱관리", required = true) String appFlag,
    		@FormParam("deviceKind") @ApiParam(value="디바이스 종류", required = true) String deviceKind )

    {
		return this.mobileManager.introCheck(appFlag, deviceKind);
    }*/

	@Path("/user/modify")
    @POST
    @ApiOperation(position = 206, value = "206. 회원정보 수정", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> userModPwd(
    		@FormParam("userId") @ApiParam(value="아이디", required = true) int userId,
    		@FormParam("userNm") @ApiParam(value="사용자이름. 이문렬", required = true) String userNm,
    		@FormParam("phoneNo") @ApiParam(value="핸드폰번호. 01047859456", required = true) String phoneNo,
    		@FormParam("userEmail") @ApiParam(value="이메일", required = true) String userEmail,
    		@FormParam("userBirthDay") @ApiParam(value="생년월일", required = true) String userBirthday,
    		@FormParam("userGender") @ApiParam(value="성별.  01(남), 02(여)", required = true) String userGender,
    		@FormParam("userPost") @ApiParam(value="번지", required = false) String userPost,
    		@FormParam("userAddr") @ApiParam(value="주소", required = false) String userAddr,
    		@FormParam("userAddrDetail") @ApiParam(value="상세주소", required = false) String userAddrDetail,
    		@FormParam("authToken") @ApiParam(value="토큰", required = true) String authToken )

    {
		return this.mobileManager.modUser(userId, userNm, phoneNo, userEmail, userBirthday, userGender, userPost, userAddr, userAddrDetail);
    }

	@Path("/user")
    @POST
    @ApiOperation(position = 207, value = "207. 회원정보 상세조회", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>		\"userId\": 1,				[fitmoa App 회원 고유 key 값]"
    		+ "<br>		\"userLoginId\": \"fitmoa\",		[fitmoa App 회원 로그인 아이디]"
    		+ "<br>		\"phoneNo\": \"01067784882\",		[fitmoa App 회원 연락처]"
    		+ "<br>		\"userNm\": \"김영철\",			[fitmoa App 회원 이름]"
    		+ "<br>		\"userEmail\": \"fitmoa@dycis.co.kr\",	[fitmoa App 회원 이메일]"
    		+ "<br>		\"userBirthday\": \"19880526\",		[fitmoa App 회원 생년월일]"
    		+ "<br>		\"userGender\": \"01\",			[fitmoa App 회원 성별 (01: 남자, 02: 여자)]"
    		+ "<br>		\"userType\": \"01\",			[fitmoa App 회원 타입 (01: 정회원(매핑된 회원), 02: 준회원(매핑 안된 회원)]"
    		+ "<br>	}"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> user(
    		@FormParam("userId") @ApiParam(value="회원 key", required = true) int userId,
    		@FormParam("authToken") @ApiParam(value="토큰", required = true) String authToken)

    {
		return this.mobileManager.findUserInfo(userId);
    }


	@Path("/user/barcode")
    @POST
    @ApiOperation(position = 208, value = "208. 바코드 생성하기", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>		\"barcodeToken\": 1,			[fitmoa App 회원 바코드 토큰 값]"
    		+ "<br>		\"expiryDt\": \"2019-10-01 18:02:44\",	[fitmoa App 회원 바코드 토큰 만료 시간]"
    		+ "<br>	}"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> userBarcode(
    		@FormParam("userId") @ApiParam(value="회원 key", required = true) int userId,
    		@FormParam("authToken") @ApiParam(value="토큰", required = true) String authToken )

    {
		return this.mobileManager.createBarcode(userId);
    }


	@Path("/user/isId")
    @POST
    @ApiOperation(position = 209, value = "209. 아이디 중복확인", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> userIsId(
    		@FormParam("userLoginId") @ApiParam(value="회원 아이디", required = true) String userLoginId )

    {
		return this.mobileManager.isLoginId(userLoginId);
    }

	@Path("/term/info")
    @POST
    @ApiOperation(position = 210, value = "210. 약관 정보 얻기", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>		\"termId\": 1,				[요청한 약관의 key 값]"
    		+ "<br>		\"termVersion\": \"fitmoa\",		[요청한 약관 버전]"
    		+ "<br>		\"termContents\": \"01067784882\",		[요청한 약관 내용]"
    		+ "<br>	}"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> termInfo(
    		@FormParam("userId") @ApiParam(value="회원 아이디", required = true) int userId,
    		@FormParam("termType") @ApiParam(value="약관 타입. 01: 개인정보처리, 02: 이용약관, 03: 마케팅활용 동의", required = true) String termType,
    		@FormParam("authToken") @ApiParam(value="토큰", required = true) String authToken )

    {
		return this.mobileManager.getTermInfo(userId, termType);
    }

	@Path("/term/argree")
    @POST
    @ApiOperation(position = 211, value = "211. 약관 정보 동의", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> termAgree(
    		@FormParam("authToken") @ApiParam(value="토큰", required = true) String authToken,
    		@FormParam("userId") @ApiParam(value="회원 아이디", required = true) int userId,
    		@FormParam("termId") @ApiParam(value="약관 타입. 개인정보처리방침: 1, 이용약관: 2", required = true) int termId,
    		@FormParam("agreeYn") @ApiParam(value="약관 동의 여부", required = true) String agreeYn )

    {
		return this.mobileManager.createTermAgreeYn(userId, termId, agreeYn);
    }





	@Path("/user/newpwd")
    @POST
    @ApiOperation(position = 212, value = "212. 비밀번호 변경", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> newpwd(
    		@FormParam("authToken") @ApiParam(value="인증 여부를 확인하는 랜덤 토큰 값", required = true) String authToken,
    		@FormParam("userId") @ApiParam(value="사용자ID(KEY)", required = true) int userId,
    		@FormParam("nowpwd") @ApiParam(value="기존 비밀번호(암호화)", required = true) String nowpwd,
    		@FormParam("newpwd") @ApiParam(value="새 비밀번호(암호화)", required = true) String newpwd,
    		@FormParam("EncryptYn") @ApiParam(value="암호화 여부. (Y, N)", required = false) String EncryptYn )

    {
		if("N".equals(EncryptYn)) {
			EncryptUtil enc = new EncryptUtil();
			nowpwd = enc.encryptSHA256(nowpwd);
			newpwd = enc.encryptSHA256(newpwd);
		}

		return this.mobileManager.modUserPw(userId, nowpwd, newpwd);
    }

	@Path("/push/list")
    @POST
    @ApiOperation(position = 213, value = "213. 수신함 목록", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>		\"totalCnt\": 5,				[푸쉬 전체 갯수]"
    		+ "<br>		\"rows\": [				[푸쉬 리스트]"
    		+ "<br>		  {"
    		+ "<br>			\"pslId\": 1,			[푸쉬 항목 당 고유 key 값]"
    		+ "<br>			\"userId\": 2,			[fitmoa App 회원 고유 key 값]"
    		+ "<br>			\"pushType\": \"01\",		[푸쉬 형식 (01: 텍스트)]"
    		+ "<br>			\"title\": \"제목\",		[푸쉬 제목]"
    		+ "<br>			\"contents\": \"내용\",		[푸쉬 내용]"
    		+ "<br>			\"sendDt\": \"2019.10.08\",		[푸쉬 발송 시간]"
    		+ "<br>			\"readYn\": \"Y\",			[회원이 푸쉬를 읽었는지 여부 (Y: 읽음, N: 읽지 않음)]"
    		+ "<br>		  },"
    		+ "<br>		  {"
    		+ "<br>			\"pslId\": 2,			"
    		+ "<br>			\"userId\": 2,	"
    		+ "<br>			\"pushType\": \"01\",		"
    		+ "<br>			\"title\": \"제목\",	"
    		+ "<br>			\"contents\": \"내용\",		"
    		+ "<br>			\"sendDt\": \"2019.10.08\",		"
    		+ "<br>			\"readYn\": \"N\"		"
    		+ "<br>		  },"
    		+ "<br>		  {"
    		+ "<br>			\"pslId\": 2,			"
    		+ "<br>			\"userId\": 3,			"
    		+ "<br>				."
    		+ "<br>				."
    		+ "<br>		  },"
    		+ "<br>				."
    		+ "<br>				."
    		+ "<br>				."
    		+ "<br>		]"
    		+ "<br>	}"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> pushList(
    		@FormParam("authToken") @ApiParam(value="인증 여부를 확인하는 랜덤 토큰 값", required = true) String authToken,
    		@FormParam("userId") @ApiParam(value="사용자ID(KEY)", required = true) int userId,
    		@FormParam("pageNo") @ApiParam(value="페이지 번호", required = true) Integer pageNo )

    {

		return this.mobileManager.findPushList(userId, pageNo);
    }

	@Path("/push/read")
    @POST
    @ApiOperation(position = 214, value = "214. 수신함 읽기", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>		\"pslId\": 1,				[푸쉬 항목 당 고유 key 값]"
    		+ "<br>		\"userId\": 2,				[fitmoa App 회원 고유 key 값]"
    		+ "<br>		\"pushType\": \"01\",			[푸쉬 형식 (01: 텍스트)]"
    		+ "<br>		\"title\": \"제목\",			[푸쉬 제목]"
    		+ "<br>		\"contents\": \"내용\",			[푸쉬 내용]"
    		+ "<br>		\"sendDt\": \"2019.10.08\",			[푸쉬 발송 시간]"
    		+ "<br>	}"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> pushRead(
    		@FormParam("authToken") @ApiParam(value="인증 여부를 확인하는 랜덤 토큰 값", required = true) String authToken,
    		@FormParam("userId") @ApiParam(value="사용자ID(KEY)", required = true) int userId,
    		@FormParam("pslId") @ApiParam(value="발송한 push 고유 key", required = true) Integer pslId )

    {

		return this.mobileManager.readPush(userId, pslId);
    }
}
