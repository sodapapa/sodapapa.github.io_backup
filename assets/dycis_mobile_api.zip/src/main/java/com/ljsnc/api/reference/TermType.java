package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum TermType {
	//01 : 개인정보처리 약관
	//02 : 서비스 이용 약관
	//03 : 제3자 동의 약관
	PrivacyPolicy("01"),
	ServicePolicy("02"),
	ThirdPartiesAcceptPolicy("03")
	;
	
	private final String stringValue;

	private TermType(final String newValue)
	{
	    stringValue = newValue;
	}
	
	@JsonValue
	public String toStr()
	{
	    return stringValue;
	}
	
	private static final Map<String, TermType> lookup = new HashMap<String, TermType>();
	
	static
	{
	    for (TermType rt : TermType.values())
	        lookup.put(rt.stringValue, rt);
	}
	
	public static TermType get(String typeStr)
	{
	    return lookup.get(typeStr);
	}
}
