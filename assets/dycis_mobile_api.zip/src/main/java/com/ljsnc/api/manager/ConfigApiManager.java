package com.ljsnc.api.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.ljsnc.api.model.TmConfigApi;
import com.ljsnc.api.mybatis.mappers.mysql.TmConfigApiMapper;
import com.ljsnc.api.util.CacheName;

@Service
public class ConfigApiManager {
	private static final Logger logger = LoggerFactory.getLogger(MessageManager.class);
	
	@Autowired TmConfigApiMapper configApiMapper;
	
	@Cacheable(value = CacheName.CONFIG_API, unless = "#result == null")
	public String selectConfigApi(String confId, String sDefault){
		logger.debug("{}", confId);
		
		TmConfigApi config = configApiMapper.selectConfigApi(confId);
		
		String sResult = sDefault;
		if (config != null && config.getConf_val() != null && config.getConf_val().equals("") == false)
			sResult = config.getConf_val();
		
		return sResult;
	}
}
