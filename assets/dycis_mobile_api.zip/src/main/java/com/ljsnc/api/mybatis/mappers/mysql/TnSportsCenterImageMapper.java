package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ljsnc.api.model.TnSportsCenter;
import com.ljsnc.api.model.TnSportsCenterImage;

public interface TnSportsCenterImageMapper {


	@Select(""
			+ "  SELECT   "
			+ "    SCI_ID,   "
			+ "    SC_ID,   "
			+ "    SCI_IMG_URL,   "
			+ "    ORDERING,   "
			+ "    REG_ID,   "
			+ "    REG_DT   "
			+ "  FROM tn_sports_center_image   "
			+ "  WHERE SC_ID = #{scId}   "
			+ "     "
			+ "")
	List<TnSportsCenterImage> getCenterImage(@Param("scId")  int scId);



}
