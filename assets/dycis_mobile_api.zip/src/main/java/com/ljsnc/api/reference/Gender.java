package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum Gender {
	MAN("01"),
	WOMAN("02")
	;
	
	private final String stringValue;

	private Gender(final String newValue)
	{
	    stringValue = newValue;
	}
	
	@JsonValue
	public String toStr()
	{
	    return stringValue;
	}
	
	private static final Map<String, Gender> lookup = new HashMap<String, Gender>();
	
	static
	{
	    for (Gender rt : Gender.values())
	        lookup.put(rt.stringValue, rt);
	}
	
	public static Gender get(String typeStr)
	{
	    return lookup.get(typeStr);
	}
	
}
