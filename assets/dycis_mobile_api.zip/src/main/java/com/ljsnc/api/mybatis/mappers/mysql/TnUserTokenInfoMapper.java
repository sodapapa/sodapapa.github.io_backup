package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.ljsnc.api.model.TnUserTokenInfo;

public interface TnUserTokenInfoMapper {
	@Insert(""
			+ "INSERT INTO tn_user_token_info(USER_ID, AUTH_TOKEN, AUTH_KIND, REG_DT ) "
			+ " VALUES( #{userId}, #{authToken}, #{authKind}, now() )")
	Integer createToken(TnUserTokenInfo tokenInfo);


	@Update(""
			+ "UPDATE tn_user_token_info SET REG_DT= now() "
			+ " WHERE USER_ID = #{userId} and AUTH_TOKEN = #{authToken} AND AUTH_KIND = #{authKind}  "
			)
	Integer updateRegDtToken(TnUserTokenInfo tokenInfo);


	@Select(""
			+ "SELECT DATE_FORMAT(REG_DT, '%Y-%m-%d %H:%i:%s') as REG_DT  "
			+ " FROM tn_user_token_info WHERE USER_ID = #{userId} AND AUTH_TOKEN = #{authToken} AND AUTH_KIND = #{authKind} ")
	List<TnUserTokenInfo> isToken(TnUserTokenInfo tokenInfo);

	@Delete("<script>"
			+ "DELETE FROM tn_user_token_info "
			+ "	WHERE "
			+ "		USER_ID = #{userId} "
			+ "		<if test=\" authToken != null and authToken != '' \">"
			+ "			AND AUTH_TOKEN = #{authToken} "
			+ "		</if>"
			+ "		AND AUTH_KIND = #{authKind}  "
			+ "</script>")
	Integer deleteToken(TnUserTokenInfo tokenInfo);

	@Delete(""
			+ ""
			+ "DELETE FROM tn_user_token_info WHERE USER_ID = #{userId}"
			+ ""
			+ "")
	Integer deleteWithdrawUserToken(TnUserTokenInfo tokenInfo);


}
