package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_DEFAULT)
public class TnTermInfo implements Serializable{
	private static final long serialVersionUID = 1L;

	private int termId;
	private String termNm;
	private String termType;
	private int termVersion;
	private String termContents;
	private String termUrl;
	private String regDt;

	private String agreeYn;



	public String getTermNm() {
		return termNm;
	}


	public void setTermNm(String termNm) {
		this.termNm = termNm;
	}


	public String getAgreeYn() {
		return agreeYn;
	}


	public void setAgreeYn(String agreeYn) {
		this.agreeYn = agreeYn;
	}


	public int getTermId() {
		return termId;
	}


	public void setTermId(int termId) {
		this.termId = termId;
	}


	public String getTermType() {
		return termType;
	}



	public void setTermType(String termType) {
		this.termType = termType;
	}



	public int getTermVersion() {
		return termVersion;
	}



	public void setTermVersion(int termVersion) {
		this.termVersion = termVersion;
	}



	public String getTermContents() {
		return termContents;
	}



	public void setTermContents(String termContents) {
		this.termContents = termContents;
	}



	public String getRegDt() {
		return regDt;
	}



	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}


	public String getTermUrl() {
		return termUrl;
	}



	public void setTermUrl(String termUrl) {
		this.termUrl = termUrl;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
