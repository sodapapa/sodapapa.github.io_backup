package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_DEFAULT)
public class TnBillboardInfo implements Serializable{

	private static final long serialVersionUID = 1L;

	private int biId;
	private int billboardId;
	private String biTitle;
	private String biContents;
	private int pBiId;
	private int rBiId;
	private int scId;
	private String biDepth;
	private String noticeYn;
	private String pwdYn;
	private String pwdValue;
	private String deleteYn;

	private String writeId;
	private String writeNm;
	private String writeImg;

	private String likeCnt ;
	private String readCnt;
	private String readYn;
	private String likeYn;

	private String galleryImg;
	private String pdsUrl;

	private String regType;
	private String regId;
	private String regDate;
	private String modType;
	private String modId;
	private String modDate;

	private String bgId;
	private String bpId;

	private String filePath;
	private String fileName;
	private String fileFormat;



	public String getPdsUrl() {
		return pdsUrl;
	}
	public void setPdsUrl(String pdsUrl) {
		this.pdsUrl = pdsUrl;
	}


	public int getScId() {
		return scId;
	}
	public void setScId(int scId) {
		this.scId = scId;
	}
	public String getGalleryImg() {
		return galleryImg;
	}
	public void setGalleryImg(String galleryImg) {
		this.galleryImg = galleryImg;
	}
	public String getWriteId() {
		return writeId;
	}
	public void setWriteId(String writeId) {
		this.writeId = writeId;
	}
	public String getBiDepth() {
		return biDepth;
	}
	public void setBiDepth(String biDepth) {
		this.biDepth = biDepth;
	}
	public String getWriteNm() {
		return writeNm;
	}
	public void setWriteNm(String writeNm) {
		this.writeNm = writeNm;
	}
	public String getWriteImg() {
		return writeImg;
	}
	public void setWriteImg(String writeImg) {
		this.writeImg = writeImg;
	}
	public String getReadYn() {
		return readYn;
	}
	public void setReadYn(String readYn) {
		this.readYn = readYn;
	}
	public String getLikeYn() {
		return likeYn;
	}
	public void setLikeYn(String likeYn) {
		this.likeYn = likeYn;
	}
	public String getPwdYn() {
		return pwdYn;
	}
	public void setPwdYn(String pwdYn) {
		this.pwdYn = pwdYn;
	}
	public String getBgId() {
		return bgId;
	}
	public void setBgId(String bgId) {
		this.bgId = bgId;
	}
	public String getBpId() {
		return bpId;
	}
	public void setBpId(String bpId) {
		this.bpId = bpId;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileFormat() {
		return fileFormat;
	}
	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}




	public int getBiId() {
		return biId;
	}
	public void setBiId(int biId) {
		this.biId = biId;
	}
	public int getBillboardId() {
		return billboardId;
	}
	public void setBillboardId(int billboardId) {
		this.billboardId = billboardId;
	}
	public String getBiTitle() {
		return biTitle;
	}
	public void setBiTitle(String biTitle) {
		this.biTitle = biTitle;
	}
	public String getBiContents() {
		return biContents;
	}
	public void setBiContents(String biContents) {
		this.biContents = biContents;
	}






	public int getpBiId() {
		return pBiId;
	}
	public void setpBiId(int pBiId) {
		this.pBiId = pBiId;
	}
	public int getrBiId() {
		return rBiId;
	}
	public void setrBiId(int rBiId) {
		this.rBiId = rBiId;
	}



	public String getNoticeYn() {
		return noticeYn;
	}
	public void setNoticeYn(String noticeYn) {
		this.noticeYn = noticeYn;
	}
	public String getPwdValue() {
		return pwdValue;
	}
	public void setPwdValue(String pwdValue) {
		this.pwdValue = pwdValue;
	}
	public String getDeleteYn() {
		return deleteYn;
	}
	public void setDeleteYn(String deleteYn) {
		this.deleteYn = deleteYn;
	}
//	public int getLikeCnt() {
//		return likeCnt;
//	}
//	public void setLikeCnt(int likeCnt) {
//		this.likeCnt = likeCnt;
//	}
	public String getRegType() {
		return regType;
	}
	public void setRegType(String regType) {
		this.regType = regType;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getModType() {
		return modType;
	}
	public void setModType(String modType) {
		this.modType = modType;
	}
	public String getModId() {
		return modId;
	}
	public void setModId(String modId) {
		this.modId = modId;
	}




	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getModDate() {
		return modDate;
	}
	public void setModDate(String modDate) {
		this.modDate = modDate;
	}
	public String getLikeCnt() {
		return likeCnt;
	}
	public void setLikeCnt(String likeCnt) {
		this.likeCnt = likeCnt;
	}
	public String getReadCnt() {
		return readCnt;
	}
	public void setReadCnt(String readCnt) {
		this.readCnt = readCnt;
	}



	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


}
