package com.ljsnc.api.channels;

import java.util.Map;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ljsnc.api.biz.manager.MyInfoManager;
import com.ljsnc.api.util.EncryptUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;

@Path("my")
@Produces({ MediaType.APPLICATION_JSON })
@Service
@Api(position = 400, value = "MyInfo", description = "MyInfo")
public class chMyInfo {
	@Autowired MyInfoManager myInfoManager;

	@Path("/mail/send")
    @POST
    @ApiOperation(position = 401, value = "401. 베일발송 처리", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "</pre>"
    		)
    public Map<String, Object> mailSend(
    		@FormParam("recvMail") @ApiParam(value="받는 사람의 메일주소", required = true) String recvMail,
    		@FormParam("mailType") @ApiParam(value="01:아이디 찾기, 02: 비밀번호 찾기", required = true) String mailType
    		)
    {
		return this.myInfoManager.mailSend(recvMail, mailType);
    }

	@Path("/term/url")
    @POST
    @ApiOperation(position = 402, value = "402. 최신약관 Url", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>		[ { "
    		+ "<br>		\"termType\": \"01\" , 			[약관 종류]"
    		+ "<br>		\"termNm\": \"이용약관\" 		[약관 이름]"
    		+ "<br>		\"termVersion\": \"1\" 			[약관 버전]"
    		+ "<br>		\"termUrl\": \" \" 					[약관 URL]"
    		+ "<br>	},{"
    		+ "<br>		\"termType\": \"02\" , 				[약관 종류]"
    		+ "<br>		\"termNm\": \"개인정보 동의\"     [약관 이름]"
    		+ "<br>		\"termVersion\": \"2\" 	    		[약관 버전]"
    		+ "<br>		\"termUrl\": \" \"						[약관 URL]"
    		+ "<br>	}, {... }, {... }] "
    		+ "<br>	}"
    		+ "<br>}"
    		+ "</pre>"
    		)
    public Map<String, Object> termUrl(){
		return this.myInfoManager.termUrl();
    }

	@Path("/term/info")
	@POST
	@ApiOperation(position = 403, value = "403. 사용자 약관 동의 확인", notes = ""
			+ "<br><br><b>Response Sample</b>"
			+ "<pre>"
			+ "<br>{"
			+ "<br>	\"code\": 1000,		[코드]"
			+ "<br>	\"msg\": \"SUCCESS\",		[성공, 실패 메시지]"

    		+ "<br>	\"data\": {"
    		+ "<br>		[{ "
    		+ "<br>		\"termType\": \"01\" ,		[약관 종류]"
    		+ "<br>		\"termNm\": \"이용약관\"		[약관 이름]"
    		+ "<br>		\"termVersion\": \"1\"		[약관 버전]"
    		+ "<br>		\"termUrl\": \" \"		[약관 URL]"
    		+ "<br>		\"agreeYn\": \"Y\"		[가장 최신 약관 정보의 동의 여부 YnN]"
    		+ "<br>		},{"
    		+ "<br>		\"termType\": \"02\" ,		[약관 종류]"
    		+ "<br>		\"termNm\": \"개인정보 동의\"		[약관 이름]"
    		+ "<br>		\"termVersion\": \"2\"		[약관 버전]"
    		+ "<br>		\"termUrl\": \"N \"		[약관 URL]"
    		+ "<br>		\"agreeYn\": \"Y\"		[가장 최신 약관 정보의 동의 여부 YnN]"
    		+ "<br>	}, {... }, {... }] "
			+ "<br>	}"
			+ "<br>}"
			+ "</pre>"
			)
	public Map<String, Object> termInfo(
    		@FormParam("authToken") @ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
    		@FormParam("userId") @ApiParam(value="회원고유ID", required = false) Integer userId){

		return this.myInfoManager.termInfo(authToken, userId);
	}

	@Path("/term/agree")
	@POST
	@ApiOperation(position = 404, value = "404. 사용자 약관 동의 처리", notes = ""
			+ "<br><br><b>Response Sample</b>"
			+ "<pre>"
			+ "<br>{"
			+ "<br>	\"code\": 1000,					[코드]"
			+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
			+ "<br>}"
			+ "</pre>"
			)
	public Map<String, Object> termAgree(
			@FormParam("authToken") @ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
			@FormParam("userId") @ApiParam(value="회원고유ID", required = true) Integer userId,
			@FormParam("termType") @ApiParam(value="약관타입", required = true) String termType){

		return this.myInfoManager.termAgree(authToken, userId, termType);
	}


	@Path("/user/info")
	@POST
	@ApiOperation(position = 405, value = "405. 나의 회원 정보 (수강,락카)", notes = ""
			+ "<br><br><b>Response Sample</b>"
			+ "<pre>"
			+ "<br>{"
			+ "<br>	\"code\": 1000,					[코드]"
			+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
			+ "<br>}"
			+ "</pre>"
			)
	public Map<String, Object> userInfo(
			@FormParam("authToken") @ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
			@FormParam("userId") @ApiParam(value="회원고유ID", required = true) Integer userId){

		return this.myInfoManager.userInfo(userId);
	}



	@Path("/user/withdraw")
	@POST
	@ApiOperation(position = 406, value = "406. 회원 탈퇴", notes = ""
			+ "<br><br><b>Response Sample</b>"
			+ "<pre>"
			+ "<br>{"
			+ "<br>	\"code\": 1000,					[코드]"
			+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
			+ "<br>}"
			+ "</pre>"
			)
	public Map<String, Object> userWithdraw(
			@FormParam("authToken")	@ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
			@FormParam("userId") 		@ApiParam(value="회원고유ID", required = true) Integer userId,
    		@FormParam("userPw") 		@ApiParam(value="비밀번호", required = true) String userPw,
			@FormParam("EncryptYn") 	@ApiParam(value="암호화 여부. (Y, N)", required = false) String EncryptYn)
			{

		if("N".equals(EncryptYn)) {
			EncryptUtil enc = new EncryptUtil();
			userPw = enc.encryptSHA256(userPw);
		}

		return this.myInfoManager.userWithdraw(userId,userPw);
	}


}
