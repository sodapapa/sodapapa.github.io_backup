package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_DEFAULT)
public class TnBillboard implements Serializable{

	private static final long serialVersionUID = 1L;


	private String billboardId;
	private String billboardType;
	private String billboardNm;
	private String writerType;
	private String commentYn;
	private String replyYn;
	private String useYn;
	private String biCnt;





	public String getBillboardId() {
		return billboardId;
	}





	public void setBillboardId(String billboardId) {
		this.billboardId = billboardId;
	}





	public String getBillboardType() {
		return billboardType;
	}





	public void setBillboardType(String billboardType) {
		this.billboardType = billboardType;
	}





	public String getBillboardNm() {
		return billboardNm;
	}





	public void setBillboardNm(String billboardNm) {
		this.billboardNm = billboardNm;
	}





	public String getWriterType() {
		return writerType;
	}





	public void setWriterType(String writerType) {
		this.writerType = writerType;
	}





	public String getCommentYn() {
		return commentYn;
	}





	public void setCommentYn(String commentYn) {
		this.commentYn = commentYn;
	}





	public String getReplyYn() {
		return replyYn;
	}





	public void setReplyYn(String replyYn) {
		this.replyYn = replyYn;
	}





	public String getUseYn() {
		return useYn;
	}





	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}





	public String getBiCnt() {
		return biCnt;
	}





	public void setBiCnt(String biCnt) {
		this.biCnt = biCnt;
	}





	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


}
