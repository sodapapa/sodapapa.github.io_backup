package com.ljsnc.api.biz.util;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;


public class StaticFunc {
	/**
	 * 문자열 체크. null or "" 이면 "" 리턴.
	 */
	public static String checkStr(String str)
	{
		if (str == null || str.trim().equals(""))	return "";
		return str;
	}
	
	
	/**
	 * 정수형 체크. null이면 0 리턴
	 */
	public static Integer checkInt(Integer in)
	{
		if (in == null)	return 0;
		return in;
	}
	
	
	/**
	 * 실수형 체크. null이면 0 리턴
	 */
	public static Double checkDouble(Double in)
	{
		if (in == null)	return 0.0;
		return in;
	}
	
	/**
	 * 공문자 체크. null or "" 이면 true 리턴.
	 */
	public static boolean emptyStr(String str)
	{
		if (str == null || str.trim().equals(""))	return true;
		return false;
	}
	
	
	/*
	 * IP 얻기?
	 */
	public static String getRemoteAddr(HttpServletRequest request)
	{
		String remoteAddr = request.getHeader("X-Forwarded-For");
		
		if (emptyStr(remoteAddr))
			remoteAddr = request.getRemoteAddr();
		
		return remoteAddr;
	}
	
	/*
	 * 날짜??
	 */
	public static String getDate()
    {
    	Calendar calendar = Calendar.getInstance();
    	
    	StringBuffer times;
    	
    	times = new StringBuffer();
        times.append(Integer.toString(calendar.get(Calendar.YEAR)));
		if((calendar.get(Calendar.MONTH)+1)<10)
        { 
            times.append("0"); 
        }
		times.append(Integer.toString(calendar.get(Calendar.MONTH)+1));
		if((calendar.get(Calendar.DATE))<10) 
        { 
            times.append("0");	
        } 
		times.append(Integer.toString(calendar.get(Calendar.DATE)));
    	
    	return times.toString();
    }
	
	/**
	 * 시간얻기..
	 * @return
	 */
    public static String getTime()
    {
    	Calendar calendar = Calendar.getInstance();
    	StringBuffer times;
    	times = new StringBuffer();

    	times.append("[");
    	if((calendar.get(Calendar.HOUR_OF_DAY))<10) 
        { 
            times.append("0"); 
        } 
 		times.append(Integer.toString(calendar.get(Calendar.HOUR_OF_DAY)));
 		times.append(":");
 		if((calendar.get(Calendar.MINUTE))<10) 
        { 
            times.append("0"); 
        }
 		times.append(Integer.toString(calendar.get(Calendar.MINUTE)));
 		times.append(":");
 		if((calendar.get(Calendar.SECOND))<10) 
        { 
            times.append("0"); 
        }
 		times.append(Integer.toString(calendar.get(Calendar.SECOND)));
 		times.append("]");
 		
 		return times.toString();
    }
    
    
    /**
	 * queryString -> Map
	 * @return
	 */
    public static Map<String, String> getQueryMap(String query)
    {
        String[] params = query.split("&");
        Map<String, String> map = new HashMap<String, String>();
        for (String param : params)
        {
        	System.out.println("params?? param = " + param);
            String name = param.split("=")[0];
            String value = param.split("=",2)[1];
            map.put(name, value);
        }
        return map;
    }
    
    
    /**
	 * 숫자체크... -> Map
	 * @return
	 */
    public static boolean isNumber(String str){
        boolean result = false;
         
         
        try{
            Double.parseDouble(str) ;
            result = true ;
        }catch(Exception e){}
         
         
        return result ;
    }


}
