package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ljsnc.api.model.TnTermInfo;

public interface TnTermInfoMapper {
	  @Select(""
			  + "SELECT TERM_ID, TERM_VERSION, TERM_CONTENTS	" +
			  "FROM tn_term_info "
			  + "WHERE "
			  + "		TERM_TYPE = #{termType} "
			  + "")
	  TnTermInfo findTermInfo(@Param("termType")String termType);


	@Select(""
			+ "SELECT TERM_ID, TERM_VERSION, TERM_CONTENTS	"
			+ "FROM tn_term_info WHERE (TERM_TYPE = '01' || TERM_TYPE = '02') "
			+ "ORDER BY REG_DT DESC LIMIT 2 "
			+ "")
	List<TnTermInfo> findTermInfoList();

	 @Select(""
	 		+ "  (SELECT    "
	 		+ "   TERM_ID, TERM_NM, TERM_TYPE, TERM_VERSION , TERM_URL    "
	 		+ "  FROM   "
	 		+ "    tn_term_info    "
	 		+ "  WHERE term_type = '01'    "
	 		+ "  ORDER BY REG_DT DESC LIMIT 1   "
	 		+ "  )    "
	 		+ "  UNION   "
	 		+ "  (SELECT    "
	 		+ "    TERM_ID, TERM_NM, TERM_TYPE, TERM_VERSION , TERM_URL    "
	 		+ "  FROM   "
	 		+ "    tn_term_info    "
	 		+ "  WHERE term_type = '02'    "
	 		+ "  ORDER BY REG_DT DESC  LIMIT 1  "
	 		+ "  )    "
	 		+ "  UNION   "
	 		+ "  (SELECT    "
	 		+ "    TERM_ID, TERM_NM, TERM_TYPE, TERM_VERSION , TERM_URL    "
	 		+ "  FROM   "
	 		+ "    tn_term_info    "
	 		+ "  WHERE term_type = '03'    "
	 		+ "  ORDER BY REG_DT DESC   LIMIT 1 "
	 		+ "  )   "
	 		+ "     "
	 		+ "     "
			+ "")
	List<TnTermInfo> findTermInfoListUrl();


	 @Select("<script>"
			 + "  "
			 + " <foreach collection=\"list\" item=\"item\" index=\"index\" separator=\"UNION\">"
			 + " (SELECT    "
			 + "   TERM_ID, TERM_NM, TERM_TYPE, TERM_VERSION , TERM_URL    "
			 + "  FROM   "
			 + "    tn_term_info    "
			 + "  WHERE term_type = #{item.termType}    "
			 + "  ORDER BY REG_DT DESC LIMIT 1   "
			 + "  )  	  "
			 + "  </foreach> "
			 + "     "
			 + "     "
			 + "</script>")
	 List<TnTermInfo> findTermInfoListUrByTermType( List<TnTermInfo> items);


}
