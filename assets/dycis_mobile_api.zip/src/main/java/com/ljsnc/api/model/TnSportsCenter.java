package com.ljsnc.api.model;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TnSportsCenter implements Serializable {
	private static final long serialVersionUID = 1L;

	private int 	scId;
	private String 	scLoginId;
	private String 	scPw;
	private String 	scIsdyYn;
	private String 	scNm;
	private String 	scCn;
	private String 	scTel;
	private String 	scOperTime;
	private String 	scPost;
	private String 	scAddr;
	private String 	scAddrDetail;
	private String 	scAddrLa;
	private String 	scAddrLo;
	private String 	scFrnchsType;
	private String 	scArea;
	private String 	scCtgry;
	private String 	scRealm;
	private String 	scIndut;
	private String 	scItem;
	private String 	scThema;
	private String 	scLogoImgUrl;
	private String 	scMainImgUrl;
	private int 	centerSeqNo;
	private String 	regId;
	private String 	regDt;
	private String 	modId;
	private String 	modDt;
	private String 	scCnt;

	private List<TnSportsCenterImage> sportsCenterImage;




	public String getScCnt() {
		return scCnt;
	}
	public void setScCnt(String scCnt) {
		this.scCnt = scCnt;
	}
	public void setScIsdyYn(String scIsdyYn) {
		this.scIsdyYn = scIsdyYn;
	}
	public int getScId() {
		return scId;
	}
	public void setScId(int scId) {
		this.scId = scId;
	}
	public String getScLoginId() {
		return scLoginId;
	}
	public void setScLoginId(String scLoginId) {
		this.scLoginId = scLoginId;
	}
	public String getScPw() {
		return scPw;
	}
	public void setScPw(String scPw) {
		this.scPw = scPw;
	}
	public String getScIsdyYn() {
		return scIsdyYn;
	}
	public void setScScIsdyYn(String scIsdyYn) {
		this.scIsdyYn = scIsdyYn;
	}
	public String getScNm() {
		return scNm;
	}
	public void setScNm(String scNm) {
		this.scNm = scNm;
	}
	public String getScCn() {
		return scCn;
	}
	public void setScCn(String scCn) {
		this.scCn = scCn;
	}
	public String getScTel() {
		return scTel;
	}
	public void setScTel(String scTel) {
		this.scTel = scTel;
	}
	public String getScOperTime() {
		return scOperTime;
	}
	public void setScOperTime(String scOperTime) {
		this.scOperTime = scOperTime;
	}
	public String getScPost() {
		return scPost;
	}
	public void setScPost(String scPost) {
		this.scPost = scPost;
	}
	public String getScAddr() {
		return scAddr;
	}
	public void setScAddr(String scAddr) {
		this.scAddr = scAddr;
	}
	public String getScAddrDetail() {
		return scAddrDetail;
	}
	public void setScAddrDetail(String scAddrDetail) {
		this.scAddrDetail = scAddrDetail;
	}
	public String getScAddrLa() {
		return scAddrLa;
	}
	public void setScAddrLa(String scAddrLa) {
		this.scAddrLa = scAddrLa;
	}
	public String getScAddrLo() {
		return scAddrLo;
	}
	public void setScAddrLo(String scAddrLo) {
		this.scAddrLo = scAddrLo;
	}
	public String getScFrnchsType() {
		return scFrnchsType;
	}
	public void setScFrnchsType(String scFrnchsType) {
		this.scFrnchsType = scFrnchsType;
	}
	public String getScArea() {
		return scArea;
	}
	public void setScArea(String scArea) {
		this.scArea = scArea;
	}
	public String getScCtgry() {
		return scCtgry;
	}
	public void setScCtgry(String scCtgry) {
		this.scCtgry = scCtgry;
	}
	public String getScRealm() {
		return scRealm;
	}
	public void setScRealm(String scRealm) {
		this.scRealm = scRealm;
	}
	public String getScIndut() {
		return scIndut;
	}
	public void setScIndut(String scIndut) {
		this.scIndut = scIndut;
	}
	public String getScItem() {
		return scItem;
	}
	public void setScItem(String scItem) {
		this.scItem = scItem;
	}
	public String getScThema() {
		return scThema;
	}
	public void setScThema(String scThema) {
		this.scThema = scThema;
	}
	public String getScLogoImgUrl() {
		return scLogoImgUrl;
	}
	public void setScLogoImgUrl(String scLogoImgUrl) {
		this.scLogoImgUrl = scLogoImgUrl;
	}
	public String getScMainImgUrl() {
		return scMainImgUrl;
	}
	public void setScMainImgUrl(String scMainImgUrl) {
		this.scMainImgUrl = scMainImgUrl;
	}
	public int getCenterSeqNo() {
		return centerSeqNo;
	}
	public void setCenterSeqNo(int centerSeqNo) {
		this.centerSeqNo = centerSeqNo;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getModId() {
		return modId;
	}
	public void setModId(String modId) {
		this.modId = modId;
	}
	public String getModDt() {
		return modDt;
	}
	public void setModDt(String modDt) {
		this.modDt = modDt;
	}


	public List<TnSportsCenterImage> getSportsCenterImage() {
		return sportsCenterImage;
	}
	public void setSportsCenterImage(List<TnSportsCenterImage> tnSportsCenterImage) {
		this.sportsCenterImage = tnSportsCenterImage;
	}

	@Override
	public String toString() {
		return "TnSportsCenter [scId=" + scId + ", scLoginId=" + scLoginId + ", scPw=" + scPw + ", scNm=" + scNm
				+ ", scCn=" + scCn + ", scTel=" + scTel + ", scOperTime=" + scOperTime + ", scPost=" + scPost
				+ ", scAddr=" + scAddr + ", scAddrDetail=" + scAddrDetail + ", scAddrLa=" + scAddrLa + ", scAddrLo="
				+ scAddrLo + ", scFrnchsType=" + scFrnchsType + ", scArea=" + scArea + ", scCtgry=" + scCtgry
				+ ", scRealm=" + scRealm + ", scIndut=" + scIndut + ", scItem=" + scItem + ", scThema=" + scThema
				+ ", scLogoImgUrl=" + scLogoImgUrl + ", scMainImgUrl=" + scMainImgUrl + ", centerSeqNo=" + centerSeqNo
				+ ", regId=" + regId + ", regDt=" + regDt + ", modId=" + modId + ", modDt=" + modDt + "]";
	}



}
