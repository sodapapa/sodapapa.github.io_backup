package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_DEFAULT)
public class TnUserTermAgree implements Serializable{
	private static final long serialVersionUID = 1L;

	private int userId;
	private int termId;
	private String agreeYn;
	private String agreeDt;



	public int getUserId() {
		return userId;
	}



	public void setUserId(int userId) {
		this.userId = userId;
	}



	public int getTermId() {
		return termId;
	}



	public void setTermId(int termId) {
		this.termId = termId;
	}



	public String getAgreeYn() {
		return agreeYn;
	}



	public void setAgreeYn(String agreeYn) {
		this.agreeYn = agreeYn;
	}



	public String getAgreeDt() {
		return agreeDt;
	}



	public void setAgreeDt(String agreeDt) {
		this.agreeDt = agreeDt;
	}



	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
