package com.ljsnc.api.mybatis.mappers.mysql;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ljsnc.api.model.TcUserCenterInfo;
import com.ljsnc.api.model.TcUserInfo;
import com.ljsnc.api.model.TnSportsCenter;

public interface TcUserInfoMapper {

	@Select(""
			+ "SELECT * "
			+ "FROM TC_USER_INFO	"
			+ "WHERE USER_KEY = #{userKey} ")
	TcUserInfo findUserInfo(@Param("userKey")String userKey);

}
