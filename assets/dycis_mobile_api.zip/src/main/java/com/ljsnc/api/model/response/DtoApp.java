package com.ljsnc.api.model.response;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.ljsnc.api.biz.util.StaticFunc;

public class DtoApp implements Serializable{
	private static final long serialVersionUID = 1L;

	private String svcid;
	private String service_no;
	private String service_type;
	private String api_service_url;
	private String toggle;
	private String opts;
	private List<DtoAppInfo> apps_info;
	
	public String getSvcid() {
		return svcid;
	}
	public void setSvcid(String svcid) {
		this.svcid = StaticFunc.checkStr(svcid);
	}
	public String getService_no() {
		return service_no;
	}
	public void setService_no(String service_no) {
		this.service_no = StaticFunc.checkStr(service_no);
	}
	public String getService_type() {
		return service_type;
	}
	public void setService_type(String service_type) {
		this.service_type = StaticFunc.checkStr(service_type);
	}
	public String getApi_service_url() {
		return api_service_url;
	}
	public void setApi_service_url(String api_service_url) {
		this.api_service_url = StaticFunc.checkStr(api_service_url);
	}
	public String getToggle() {
		return toggle;
	}
	public void setToggle(String toggle) {
		this.toggle = StaticFunc.checkStr(toggle);
	}
	public String getOpts() {
		return opts;
	}
	public void setOpts(String opts) {
		this.opts = StaticFunc.checkStr(opts);
	}
	public List<DtoAppInfo> getApps_info() {
		return apps_info;
	}
	public void setApps_info(List<DtoAppInfo> apps_info) {
		this.apps_info = apps_info;
	}
	
	@Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this);
        
    }
	
}
