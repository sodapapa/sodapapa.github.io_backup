package com.ljsnc.api.mybatis.mappers.mysql;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ljsnc.api.model.TmMsg;
import com.ljsnc.api.reference.FgLang;

public interface TmMsgMapper {
	
	@Select(""
			+ "SELECT CD_SYS, MSG_CD, MSG_NO, FG_LANG, MSG_NM, MSG_DESC, REG_ID, REG_DATE, MOD_ID, MOD_DATE"
			+ " FROM tm_msg"
			+ " WHERE CD_SYS = #{cdSys}"
			+ " AND MSG_CD = #{cdMsg}"
			+ " AND MSG_NO = #{noMsg}"
			+ " AND FG_LANG = #{fgLang}"
			)
	TmMsg selectMsg(@Param("cdSys")String cdSys, @Param("cdMsg")String cdMsg, @Param("noMsg")String noMsg, @Param("fgLang")FgLang fgLang);
}
