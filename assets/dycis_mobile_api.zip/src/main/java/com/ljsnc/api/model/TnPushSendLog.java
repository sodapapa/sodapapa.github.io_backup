package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TnPushSendLog implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int pslId;
	private int userId;
	private String pushKey;
	private String pushType;
	private String title;
	private String contents;
	private String deviceKind;
	private String sendSuccessYn;
	private String sendDt;
	private String readYn;
	private String readDt;
	
	
	public int getPslId() {
		return pslId;
	}
	public void setPslId(int pslId) {
		this.pslId = pslId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPushKey() {
		return pushKey;
	}
	public void setPushKey(String pushKey) {
		this.pushKey = pushKey;
	}
	public String getPushType() {
		return pushType;
	}
	public void setPushType(String pushType) {
		this.pushType = pushType;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getDeviceKind() {
		return deviceKind;
	}
	public void setDeviceKind(String deviceKind) {
		this.deviceKind = deviceKind;
	}
	public String getSendSuccessYn() {
		return sendSuccessYn;
	}
	public void setSendSuccessYn(String sendSuccessYn) {
		this.sendSuccessYn = sendSuccessYn;
	}
	public String getSendDt() {
		return sendDt;
	}
	public void setSendDt(String sendDt) {
		this.sendDt = sendDt;
	}
	public String getReadYn() {
		return readYn;
	}
	public void setReadYn(String readYn) {
		this.readYn = readYn;
	}
	public String getReadDt() {
		return readDt;
	}
	public void setReadDt(String readDt) {
		this.readDt = readDt;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
