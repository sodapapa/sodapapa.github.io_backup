package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class TnUserTokenInfo implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private int userId;
	private String authToken;
	private String authKind;
	private String regDt;
	

	
	
	
	public int getUserId() {
		return userId;
	}





	public void setUserId(int userId) {
		this.userId = userId;
	}

	
	
	public String getAuthToken() {
		return authToken;
	}





	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}
	
	
	
	
	public String getAuthKind() {
		return authKind;
	}





	public void setAuthKind(String authKind) {
		this.authKind = authKind;
	}
	
	
	
	
	public String getRegDt() {
		return regDt;
	}





	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}

	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
