package com.ljsnc.api.util;

import com.ljsnc.api.reference.FgLang;

public interface CommonConstants
{
	public static final int DEFAULT_LIST_CNT = 1000;
	public static final FgLang DEFAULT_FG_LANG = FgLang.Korean;

	public static final String HEADER_FG_LANG    = "fgLang";   		// 언어. KO,EN,JA
	public static final String HEADER_CUST_ID    = "custId";		// 회원
	public static final String HEADER_AUTH_TOKEN = "authToken"; 	// 인증 토큰.

	public static final int RESPONSE_SUCCESS_CODE  = 1000;
	public static final String RESPONSE_SUCCESS_MSG  = "SUCCESS";
	public static final String RESPONSE_SUCCESS_HOST  = "dycis_mobile";
	public static final String RESPONSE_SUCCESS_HASH = "";

	public static final int RESPONSE_FAIL_CODE  = 0;
	public static final String RESPONSE_FAIL_MSG  = "FAIL";

	public static final String HEADER_SVC_ID = "svcid";		//서비스 ID
	public static final String HEADER_TOKEN = "token";		//토큰
	public static final String HEADER_HASH = "hash";		//토큰
	public static final String HEADER_NATIONAL = "national";		//토큰


	public static final Integer AUTH_TOKEN_LENGTH = 12;
	public static final Integer BARCODE_TOKEN_LENGTH = 8;
	public static final Integer BARCODE_TOKEN_LENGTH_4 = 4;
	public static final Integer MEMBER_NO_LENGTH = 12;

	public static final Integer BARCODE_AVAILABLE_TIME = 60*3;				// 3분
	public static final Integer USER_AUTH_TOKEN_AVAILABLE_TIME = 60*60;		// 60분
	public static final Integer MAIL_AUTH_TOKEN_AVAILABLE_TIME = 60*60;		// 60분
	public static final Integer CENTER_AUTH_TOKEN_AVAILABLE_TIME = 60*60*24*365;	// 1년

	public static final String PUSH_SERVER_KEY = "AIzaSyCoo2hyDMTnPj3GVuciOzf80za2qL77TPQ";

	// 연동 로그 관련 텍스트..
	public static final String LOG_PATH = "/usr/local/server/celeb_api/logs/payment";

	public static final Boolean LOG_IS = false;

	public static final Integer FREE_BILLBOARD_ID = 12;
	//=====================================================================
	// PUSH 관련
	//=====================================================================
	//스케줄 실행 시간 설정 초단위로 설정 (기본값은 10초)
	//schedule.interval = 1

	//#/Users/dakccom/Downloads/pushserver/apns_dev.p12
	//ios.cert.key = D:\\characcon_prod.p12
	public static String IOS_CERT_KEY = "D:/_cert/aut_push12_v2.p12";
	public static String IOS_CERT_PASSWORD = "soccer11";
	public static boolean IOS_CERT_PRODUCT = false;

	//안드로이드 키 세팅 (FCM)
	//public static String ANDROID_CERT_KEY = "AAAAX4VgtxY:APA91bHt-urgTt-3BvGddff6JaglzasGvbF_e-oNvyFE1kvZv772zMtxYfVUvVkdR8CQJloGP2eGH24rMRxNOqAACGOmPu-9bRqhigPp0GAhLuna-N35q7vbAkHjKAIzBEenTn1eT93r";
	public static String ANDROID_CERT_KEY = "AIzaSyDnd2XEe1eCsDLxEXi26OnGHAUPuIxPkOk";
	public static String ANDROID_CERT_URL = "https://fcm.googleapis.com/fcm/send";

	public static final String PUSHSEQ	= "pushSeq";    // 로그확인을 위해서 꼭 필요 ^^	O	인터페이스 호출
	public static final String P_TYPE	= "p_type";     // 푸쉬종류구분	O	1:일반,2:일반(이미지),3:팝업형태
	public static final String ALERT    = "alert";      // 타이틀	X	없으면 앱이름
	public static final String CONT		= "cont";       // 내용	O	글자 15글자로 처리..
	public static final String IMG_URL	= "img_url";    // 푸쉬 창에 나타날 이미지	X	이미지가 있는경우 창에 나타남
	public static final String LINK_URL	= "link_url";   // 링크URL	X	리턴URL  // 없으면 초기
	public static final String LINK_NM	= "link_nm";    // 링크명	X	링크이름.

	public static final String IMG_UPLOAD_PATH = "/usr/local/server/dycis_mobile_api/webapps/ROOT/pds/02";
	public static final String IMG_UPLOAD_PATH_DB_PARAM = "/pds/02";

	public static final String MAIL_TYPE_ID	= "01";    // 메일타입 아이디 찾기
	public static final String MAIL_TYPE_PW	= "02";    // 메일타입 비밀번호 초기화



}
