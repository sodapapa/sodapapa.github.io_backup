package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;

import com.ljsnc.api.model.TnBillboard;
import com.ljsnc.api.model.TnBillboardComment;
import com.ljsnc.api.model.TnBillboardInfo;

public interface TnBillboardMapper {

	@Select(""
			+ " SELECT   "
			+ "   *   "
			+ " FROM  "
			+ "   tn_billboard_info bi   "
			+ " WHERE BILLBOARD_ID =   "
			+ "   (SELECT   "
			+ "     billBoard_id   "
			+ "   FROM  "
			+ "     tn_billboard   "
			+ "   WHERE BILLBOARD_TYPE = '01'   "
			+ "   LIMIT 1)  "
			+ "   "
			+ "   ")
	List<TnBillboardInfo> getBillboardList();

	@Select(""
			+ ""
			+ " SELECT   "
			+ "   *   "
			+ " FROM  "
			+ "   tn_billboard_info bi   "
			+ " WHERE BI_ID =  #{biId} "
			+ ""
			)
	TnBillboardInfo getBillboard(@Param("biId") Integer biId);


	@Select(""
			+ "  SELECT  "
			+ "    BC_ID,  "
			+ "    BI_ID,  "
			+ "    BC_CONTENTS,  "
			+ "    DELETE_YN,  "
			+ "    REG_TYPE,  "
			+ "    MOD_TYPE  "
			+ "  FROM tn_billboard_comment  "
			+ "  WHERE BI_ID = #{biId}  "
			+ "    "
			+ "    "
			+ "")
	List<TnBillboardComment> getCommentList(@Param("biId")Integer biId);

	@SelectKey(before = false, keyProperty="biId", resultType = int.class, statement=""
			+ "SELECT LAST_INSERT_ID() ")
	@Insert(""
			+ "   INSERT INTO tn_billboard_info   "
			+ "               ("
			+ "                BILLBOARD_ID,   "
			+ "                BI_TITLE,   "
			+ "                BI_CONTENTS,   "
			+ "                P_BI_ID,   "
			+ "                NOTICE_YN,   "
			+ "                DELETE_YN,   "
			+ "                PWD_VALUE,   "
			+ "                LIKE_CNT,   "
			+ "                REG_TYPE,   "
			+ "                REG_ID,   "
			+ "                REG_DT,   "
			+ "                MOD_TYPE,   "
			+ "                MOD_ID,   "
			+ "                MOD_DT)   "
			+ "   VALUES (   "
			+ "           #{billboardId},   "
			+ "           #{biTitle},   "
			+ "           #{biContents},   "
			+ "           #{pBiId},   "
			+ "           #{noticeYn},   "
			+ "           #{deleteYn},   "
			+ "           #{pwdValue},   "
			+ "           #{likeCnt},   "
			+ "           #{regType},   "
			+ "           #{regId},   "
			+ "           #{regDt},   "
			+ "           #{modType},   "
			+ "           #{modId},   "
			+ "           #{modDt});   "
			+ "      "
			+ "      ")
	int writeBillboard(TnBillboardInfo tnBillboardInfo);

	@Select(""
			+ " SELECT   "
			+ "   *   "
			+ " FROM  "
			+ "   tn_billboard_info bi   "
			+ " WHERE BILLBOARD_ID =   "
			+ "   (SELECT   "
			+ "     billBoard_id   "
			+ "   FROM  "
			+ "     tn_billboard   "
			+ "   WHERE BILLBOARD_TYPE = '02'   "
			+ "   LIMIT 1)  "
			+ "   "
			+ "   ")
	List<TnBillboardInfo> getQnaList();

	@Select(""
			+ ""
			+ " SELECT   "
			+ "   *   "
			+ " FROM  "
			+ "   tn_billboard_info bi   "
			+ " WHERE BI_ID =  #{biId} "
			+ ""
			)
	TnBillboardInfo qnaRead(@Param("biId") Integer biId);


	@Select(""
			+ "  SELECT    "
			+ "    bi.BI_ID,   "
			+ "    bi.BILLBOARD_ID,   "
			+ "    bi.BI_TITLE,   "
			+ "    bi.BI_CONTENTS,   "
			+ "    bi.P_BI_ID,   "
			+ "    bi.NOTICE_YN,   "
			+ "    bi.DELETE_YN,   "
			+ "    bi.PWD_VALUE,   "
			+ "    bi.LIKE_CNT,   "
			+ "    bi.REG_TYPE,   "
			+ "    bi.MOD_TYPE,   "
			+ "       "
			+ "    bg.BG_ID,   "
			+ "    bg.FILE_PATH,   "
			+ "    bg.FILE_NAME,   "
			+ "    bg.FILE_FORMAT   "
			+ "        "
			+ "  FROM   "
			+ "    tn_billboard_info bi,   "
			+ "    tn_billboard_gallery bg    "
			+ "  WHERE bi.BI_ID = bg.BI_ID   "
			+ "  AND bi.BI_ID = #{biId}   "
			+ ""
			+ ""
			+ "     ")
	TnBillboardInfo getGalleryInfo(@Param("biId") Integer biId);

	@SelectKey(before = false, keyProperty="bgId", resultType = int.class, statement=""
			+ "SELECT LAST_INSERT_ID() ")
	@Insert(""
			+ "   INSERT INTO tn_billboard_gallery     "
			+ "               (     "
			+ "                BI_ID,     "
			+ "                FILE_PATH,     "
			+ "                FILE_NAME,     "
			+ "                FILE_FORMAT,     "
			+ "                DELETE_YN,     "
			+ "                REG_TYPE,     "
			+ "                REG_ID,     "
			+ "                REG_DT,     "
			+ "                MOD_TYPE,     "
			+ "                MOD_ID,     "
			+ "                MOD_DT)     "
			+ "   VALUES (     			"
			+ "           #{biId},     "
			+ "           #{filePath},     "
			+ "           #{fileName},     "
			+ "           #{fileFormat},     "
			+ "           #{deleteYn},     "
			+ "           #{regType},     "
			+ "           #{regId},     "
			+ "            now(),     "
			+ "           #{modType},     "
			+ "           #{modId},     "
			+ "            now());     "
			+ "        "
			+ "")
	int writeBillboardGallery(TnBillboardInfo tnBillboardGallery);

	@SelectKey(statement="select SEQ_STUDENT.nextval FROM DUAL", keyProperty="id", before=true, resultType=int.class)
	@Select("<script>"
			+ "   SELECT     "
			+ "     billboard_Type,    "
			+ "     billboard_Nm,    "
			+ "     writer_Type,    "
			+ "     comment_Yn,    "
			+ "     reply_Yn,    "
			+ "     use_Yn,    "
			+ "     (SELECT     "
			+ "       COUNT(*)     "
			+ "     FROM    "
			+ "       tn_billboard_info     "
			+ "     WHERE BILLBOARD_ID = #{billboardId}  AND DELETE_YN = 'N ' "
			+ "		<if test=\"billboardId == 12 \" > 	"
			+ "			AND reg_Id = #{userId}"
			+ "		</if>"
			+ " 		) AS biCnt     "
			+ "   FROM    "
			+ "     tn_billboard     "
			+ "   WHERE Billboard_id = #{billboardId}     "
			+ "       "
			+ "       "
			+ "</script>")
	TnBillboard getBillboardInfo(@Param("billboardId") Integer billboardId, @Param("userId") Integer userId);
}
