package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum MailType {
	FindId("01"),
	ResetPassword("02")
	;
	
	private final String stringValue;

	private MailType(final String newValue)
	{
	    stringValue = newValue;
	}
	
	@JsonValue
	public String toStr()
	{
	    return stringValue;
	}
	
	private static final Map<String, MailType> lookup = new HashMap<String, MailType>();
	
	static
	{
	    for (MailType rt : MailType.values())
	        lookup.put(rt.stringValue, rt);
	}
	
	public static MailType get(String typeStr)
	{
	    return lookup.get(typeStr);
	}
	
}
