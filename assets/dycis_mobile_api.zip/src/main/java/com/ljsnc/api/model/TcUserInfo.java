package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TcUserInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	private String userKey;
	private String userEmail;
	private String userPassword;
	private String userName;
	private String userBirth;
	private String userGender;
	private String bodyHeight;
	private String bodyWeight;
	private String userPhone;
	private String userImage;
	private String userType;
	private String facebookTokenUuid;
	private String promotionYn;
	private String centerYn;
	private String userStat;
	private String osType;
	
	
	public String getUserKey() {
		return userKey;
	}


	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}


	public String getUserEmail() {
		return userEmail;
	}


	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}


	public String getUserPassword() {
		return userPassword;
	}


	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserBirth() {
		return userBirth;
	}


	public void setUserBirth(String userBirth) {
		this.userBirth = userBirth;
	}


	public String getUserGender() {
		return userGender;
	}


	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}


	public String getBodyHeight() {
		return bodyHeight;
	}


	public void setBodyHeight(String bodyHeight) {
		this.bodyHeight = bodyHeight;
	}


	public String getBodyWeight() {
		return bodyWeight;
	}


	public void setBodyWeight(String bodyWeight) {
		this.bodyWeight = bodyWeight;
	}


	public String getUserPhone() {
		return userPhone;
	}


	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}


	public String getUserImage() {
		return userImage;
	}


	public void setUserImage(String userImage) {
		this.userImage = userImage;
	}


	public String getUserType() {
		return userType;
	}


	public void setUserType(String userType) {
		this.userType = userType;
	}


	public String getFacebookTokenUuid() {
		return facebookTokenUuid;
	}


	public void setFacebookTokenUuid(String facebookTokenUuid) {
		this.facebookTokenUuid = facebookTokenUuid;
	}


	public String getPromotionYn() {
		return promotionYn;
	}


	public void setPromotionYn(String promotionYn) {
		this.promotionYn = promotionYn;
	}


	public String getCenterYn() {
		return centerYn;
	}


	public void setCenterYn(String centerYn) {
		this.centerYn = centerYn;
	}


	public String getUserStat() {
		return userStat;
	}


	public void setUserStat(String userStat) {
		this.userStat = userStat;
	}


	public String getOsType() {
		return osType;
	}


	public void setOsType(String osType) {
		this.osType = osType;
	}


	public String getKakaoToken() {
		return kakaoToken;
	}


	public void setKakaoToken(String kakaoToken) {
		this.kakaoToken = kakaoToken;
	}


	public String getAutoLoginYn() {
		return autoLoginYn;
	}


	public void setAutoLoginYn(String autoLoginYn) {
		this.autoLoginYn = autoLoginYn;
	}


	public String getWithDrowYn() {
		return withDrowYn;
	}


	public void setWithDrowYn(String withDrowYn) {
		this.withDrowYn = withDrowYn;
	}


	public String getBlockYmd() {
		return blockYmd;
	}


	public void setBlockYmd(String blockYmd) {
		this.blockYmd = blockYmd;
	}


	public String getWidthDrowYmd() {
		return widthDrowYmd;
	}


	public void setWidthDrowYmd(String widthDrowYmd) {
		this.widthDrowYmd = widthDrowYmd;
	}


	public String getAuthType() {
		return authType;
	}


	public void setAuthType(String authType) {
		this.authType = authType;
	}


	public String getRegYmdt() {
		return regYmdt;
	}


	public void setRegYmdt(String regYmdt) {
		this.regYmdt = regYmdt;
	}


	public String getRegUser() {
		return regUser;
	}


	public void setRegUser(String regUser) {
		this.regUser = regUser;
	}


	public String getModYmdt() {
		return modYmdt;
	}


	public void setModYmdt(String modYmdt) {
		this.modYmdt = modYmdt;
	}


	public String getModUser() {
		return modUser;
	}


	public void setModUser(String modUser) {
		this.modUser = modUser;
	}


	public String getUseYn() {
		return useYn;
	}


	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}


	private String kakaoToken;
	private String autoLoginYn;
	private String withDrowYn;
	private String blockYmd;
	private String widthDrowYmd;
	private String authType;
	private String regYmdt;
	private String regUser;
	private String modYmdt;
	private String modUser;
	private String useYn;
	
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
		
}
