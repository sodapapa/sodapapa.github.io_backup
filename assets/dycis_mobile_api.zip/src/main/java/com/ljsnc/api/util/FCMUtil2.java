package com.ljsnc.api.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.auth.oauth2.GoogleCredentials;

/* 2019-10-16 강현구
 * FCM 모듈 (HTTP V1 프로토콜) 
 * 대양 2차 오픈시 사용
 *  */
public class FCMUtil2 {

	private static final Logger logger = LoggerFactory.getLogger(FCMUtil2.class);
	
	private static final String PROJECT_ID = "fitmoa-membership";
	
	private static final String ENDPOINT_V1 = "https://fcm.googleapis.com/v1/projects/"+PROJECT_ID+"/messages:send";
	
	private String pushKey;
	
	private Map<String, Object> data;
	
	private int responseCode;
	
	private String responseMsg;

	public void setPushKey(String pushKey) {
		this.pushKey = pushKey;
	}
	
	public void setData(String key, Object value) {
		if(data == null)
			data = new HashMap<String, Object>();
		
		this.data.put(key, value);
	}
	
	private String getAccessToken() {
		ClassPathResource resource = new ClassPathResource("config/firebase/fitmoa-membership-firebase-adminsdk-up8d2-04f6848083.json");
	
		GoogleCredentials g = null;
		String accessToken = null;
		try {
			g = GoogleCredentials
					.fromStream(new FileInputStream(resource.getURI().getPath()))
					.createScoped(Arrays.asList("https://www.googleapis.com/auth/firebase.messaging"));
			
			g.refreshIfExpired();
			accessToken = g.getAccessToken().getTokenValue();
		} catch (IOException e) {
			e.printStackTrace();
		}
		 
		return accessToken;
	}
	
	public Map<String, Object> push() throws Exception {
		URL url;
		Map<String, Object> resultMap = null;
		
		url = new URL(ENDPOINT_V1);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		
		con.setRequestMethod("POST");
		con.setDoInput(true);
		con.setRequestProperty("Authorization", "Bearer " + getAccessToken());
		con.setRequestProperty("Content-Type", "application/json; UTF-8");
		con.setDoOutput(true);
		
		Map<String, Object> message = new HashMap<String, Object>();
		message.put("data", this.data);
		message.put("token", pushKey);
		
		Map<String, Object> httpV1Body = new HashMap<String, Object>();
		httpV1Body.put("message", message);
		
		ObjectMapper mapper = new ObjectMapper();
		String body = mapper.writeValueAsString(httpV1Body);
		
		logger.info(body);
		
		OutputStream out = con.getOutputStream();
		out.write(body.getBytes());
		out.flush();
		
		out.close();
		
		responseCode = con.getResponseCode();
		responseMsg = con.getResponseMessage();
		
		InputStream in = null;
		if(responseCode >= 400) {
			in = con.getErrorStream();
		}else {
			in = con.getInputStream();
		}
		
		BufferedReader bin = new BufferedReader(new InputStreamReader(in));
		String resposeBody = "";
		String l = null;
		while( (l = bin.readLine()) != null ) {
			resposeBody += l;
		}
		
		if(responseCode >= 400)
			throw new HttpException("Invalid response code: "+responseCode+"\n" 
									+"Message: " + resposeBody);
		
		resultMap = new HashMap<String, Object>();
		resultMap.put("code", responseCode);
		resultMap.put("msg", responseMsg);
		resultMap.put("body", resposeBody);
		
		return resultMap;
	}
	
}
