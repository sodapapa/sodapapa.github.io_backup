package com.ljsnc.api.biz.manager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ljsnc.api.biz.util.ApiResponse;
import com.ljsnc.api.biz.util.KeyGenerator;
import com.ljsnc.api.biz.util.StaticFunc;
import com.ljsnc.api.exception.ManagedException;
import com.ljsnc.api.exception.ManagedExceptionCode;
import com.ljsnc.api.model.TcUserInfo;
import com.ljsnc.api.model.TnBarcode;
import com.ljsnc.api.model.TnPushSendLog;
import com.ljsnc.api.model.TnSportsCenter;
import com.ljsnc.api.model.TnUser;
import com.ljsnc.api.model.TnUserAtnlc;
import com.ljsnc.api.model.TnUserLocker;
import com.ljsnc.api.model.TnUserMapping;
//import com.ljsnc.api.model.TnUserTokenInfo;
import com.ljsnc.api.model.response.DtoCenterLoginInfo;
import com.ljsnc.api.mybatis.mappers.mysql.TcUserInfoMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnBarcodeMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnPushSendLogMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnSportsCenterMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserAtnlcMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserLockerMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserMappingMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserTokenInfoMapper;
import com.ljsnc.api.reference.PushType;
import com.ljsnc.api.reference.UserType;
import com.ljsnc.api.util.CommonConstants;
import com.ljsnc.api.util.FCMUtil;
import com.ljsnc.api.util.FCMUtil2;

@Service
public class SystemManager {
	private static final Logger logger = LoggerFactory.getLogger(SystemManager.class);

	@Autowired TnSportsCenterMapper 	tnSportsCenterMapper;
	@Autowired TnUserTokenInfoMapper 	tnUserTokenInfoMapper;
	@Autowired TnUserMapper 			tnUserMapper;
	@Autowired TnBarcodeMapper			tnBarcodeMapper;
	@Autowired TcUserInfoMapper			tcUserInfoMapper;
	@Autowired TnUserMappingMapper		tnUserMappingMapper;
	@Autowired TnUserAtnlcMapper		tnUserAtnlcMapper;
	@Autowired TnPushSendLogMapper		tnPushSendLogMapper;
	@Autowired TnUserLockerMapper		tnUserLockerMapper;

	public Map<String, Object> centerLogin(String scLoginId, String scPw) {

		if(StaticFunc.emptyStr(scLoginId) || StaticFunc.emptyStr(scPw))
			throw new ManagedException(ManagedExceptionCode.EmptyParameter, CommonConstants.DEFAULT_FG_LANG);

		TnSportsCenter tnSportCenter = tnSportsCenterMapper.loginCheck(scLoginId, scPw);

		if(tnSportCenter == null) {
			throw new ManagedException(ManagedExceptionCode.InvalidUser, CommonConstants.DEFAULT_FG_LANG);
		}
		// 2019-10-16 강현구: 센터회원 토큰 랜덤처리 주석-> 1년 유효 토큰으로 변경
		/*String loginToken = KeyGenerator.createKey(CommonConstants.AUTH_TOKEN_LENGTH);

		TnUserTokenInfo tokenInfo = new TnUserTokenInfo();
		tokenInfo.setUserId(tnSportCenter.getScId());
		tokenInfo.setAuthKind("URMG");
		tnUserTokenInfoMapper.deleteToken(tokenInfo);
		tokenInfo.setAuthToken(loginToken);

		if(tnUserTokenInfoMapper.createToken(tokenInfo) <= 0)
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);*/

		String loginToken = null;
		switch(tnSportCenter.getScId()) {
		case 1990000001:
			loginToken = "nTYfoBTuJGQE";
			break;
		case 1990000002:
			loginToken = "kyNKQnEoWbUH";
			break;
		case 1990000003:
			loginToken = "EViuahwDZ4Qm";
			break;
		case 1990000004:
			loginToken = "fVTnOmMDL2W3";
			break;
		case 1990000005:
			loginToken = "ijX3SGn4KJSM";
			break;
		}

		DtoCenterLoginInfo dtoCenterLoginInfo = new DtoCenterLoginInfo();
		dtoCenterLoginInfo.setScId(tnSportCenter.getScId());
		dtoCenterLoginInfo.setAuthToken(loginToken);

		return ApiResponse.makeResponse(dtoCenterLoginInfo);
	}

	public Map<String, Object> findUserList(String userLoginId, String userNm, String phoneNo, String userBirthday) {
		logger.info("{}, {}, {}", userLoginId, userNm, phoneNo, userBirthday);

		TnUser tnUser = new TnUser();
		tnUser.setUserLoginId(userLoginId);
		tnUser.setUserNm(userNm);
		tnUser.setPhoneNo(phoneNo);
		tnUser.setUserBirthday(userBirthday);

		List<TnUser> tnUserList = tnUserMapper.findUserList(tnUser);
		if(tnUserList.size() <= 0)
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse(tnUserList);
	}


	public Map<String, Object> findUserInfo(int userId) {

		TnUser tnUser = tnUserMapper.findUserInfo(userId);
		if(tnUser == null) {
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);
		}

		return ApiResponse.makeResponse(tnUser);
	}

	public Map<String, Object> userMapping(int userId, String userKey) {

		TnUser tnUser = tnUserMapper.findUserInfo(userId);
		if(tnUser == null) {
			throw new ManagedException(ManagedExceptionCode.InvalidUser, CommonConstants.DEFAULT_FG_LANG);
		}

		TcUserInfo tcUserInfo = tcUserInfoMapper.findUserInfo(userKey);
		if(tcUserInfo == null) {
			throw new ManagedException(ManagedExceptionCode.InvalidCenterUser, CommonConstants.DEFAULT_FG_LANG);
		}

		if(tnUserMappingMapper.isMappingUser(userId, userKey) != null ) {
			throw new ManagedException(ManagedExceptionCode.ExistMappingUser, CommonConstants.DEFAULT_FG_LANG);
		}

		if(tnUserMappingMapper.mappingUser(userId, userKey) <= 0)
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);

		tnUserMapper.updateUserType(userId, UserType.RegularMember.toStr());

		return ApiResponse.makeResponse();
	}

	public Map<String, Object> expiryBarcode(String barcordToken) {

		TnBarcode tnBarcode = tnBarcodeMapper.findBarcodeToken(barcordToken);

		if(tnBarcode == null) {
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);
		}

		Date expireDate = null;
		Date now = new Date();

		try {
			expireDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(tnBarcode.getExpiryDt());
		} catch(Exception e) {
			e.printStackTrace();
		}

		long expirySec = ((expireDate.getTime() - now.getTime()));
		if( expirySec <= 0 ) {
			throw new ManagedException(ManagedExceptionCode.BarcodeTokenExpired, CommonConstants.DEFAULT_FG_LANG);
		}

		//if(tnBarcodeMapper.deleteBarcodeToken(tnBarcode) <= 0)
		//	throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse();
	}

	/* 2019-10-16 강현구
	 * FCM HTTP 프로토콜
	 * 대양 1차 오픈시 사용
	 *  */
	public Map<String, Object> pushSend(Integer userId, String phoneNo, String title, String contents) {
		logger.info("USER_ID : {}, PHONE_NO : " + phoneNo, userId);

		List<TnUser> tnUserList = null;
		if(userId != null && phoneNo != null) {
			tnUserList = tnUserMapper.findUserPushKey(userId, null);
		}else {
			tnUserList = tnUserMapper.findUserPushKey(userId, phoneNo);
		}

		int size = tnUserList.size();

		if( size <= 0 )
			throw new ManagedException(ManagedExceptionCode.InvalidUser, CommonConstants.DEFAULT_FG_LANG);

		if(size > 1)
			throw new ManagedException(ManagedExceptionCode.DupliacateUserPhoneNo, CommonConstants.DEFAULT_FG_LANG);

		String pushKey = tnUserList.get(0).getPushKey();
		if(StaticFunc.emptyStr(pushKey)) {
			logger.info("푸쉬 키가 비어있습니다.");
			throw new ManagedException(ManagedExceptionCode.FailFCMPush, CommonConstants.DEFAULT_FG_LANG);
		}

		TnPushSendLog tnPushSendLog = new TnPushSendLog();
		tnPushSendLog.setUserId(userId);
		tnPushSendLog.setPushKey(pushKey);
		tnPushSendLog.setPushType(PushType.Text.toStr());
		tnPushSendLog.setTitle(title);
		tnPushSendLog.setContents(contents);
		tnPushSendLog.setDeviceKind(tnUserList.get(0).getDeviceKind());
		tnPushSendLog.setSendSuccessYn("Y");
		tnPushSendLogMapper.insertPushLog(tnPushSendLog);

		FCMUtil fcm = new FCMUtil();
		fcm.setAuth(CommonConstants.PUSH_SERVER_KEY);
		fcm.setPushKey(tnUserList.get(0).getPushKey());
		fcm.setData("pslId", tnPushSendLog.getPslId());
		fcm.setData("title", title);
		fcm.setData("contents", contents);

		Map<String, Object> resultMap = fcm.push();
		logger.info(resultMap.toString());

		int f = 0;
		try {
			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> map = mapper.readValue((String)resultMap.get("body"), new TypeReference<Map<String, Object>>(){});

			f = (int)map.get("failure");
		}catch(Exception e) {
			e.printStackTrace();
		}

		if( f > 0 ) {
			tnPushSendLogMapper.updateSendSuccess("N");
			throw new ManagedException(ManagedExceptionCode.FailFCMPush, CommonConstants.DEFAULT_FG_LANG);
		}

		return ApiResponse.makeResponse();
	}


	/* 2019-10-16 강현구
	 * FCM HTTP V1 프로토콜
	 * 대양 2차 오픈시 사용
	 *  */
	public Map<String, Object> pushSend2(Integer userId, String phoneNo, String title, String contents) {
		logger.info("USER_ID : {}, PHONE_NO : " + phoneNo, userId);

		List<TnUser> tnUserList = null;
		if(userId != null && phoneNo != null) {
			tnUserList = tnUserMapper.findUserPushKey(userId, null);
		}else {
			tnUserList = tnUserMapper.findUserPushKey(userId, phoneNo);
		}

		int size = tnUserList.size();

		if( size <= 0 )
			throw new ManagedException(ManagedExceptionCode.InvalidUser, CommonConstants.DEFAULT_FG_LANG);

		if(size > 1)
			throw new ManagedException(ManagedExceptionCode.DupliacateUserPhoneNo, CommonConstants.DEFAULT_FG_LANG);

		String pushKey = tnUserList.get(0).getPushKey();
		if(StaticFunc.emptyStr(pushKey)) {
			logger.info("푸쉬 키가 비어있습니다.");
			throw new ManagedException(ManagedExceptionCode.FailFCMPush, CommonConstants.DEFAULT_FG_LANG);
		}

		TnPushSendLog tnPushSendLog = new TnPushSendLog();
		tnPushSendLog.setUserId(userId);
		tnPushSendLog.setPushKey(pushKey);
		tnPushSendLog.setPushType(PushType.Text.toStr());
		tnPushSendLog.setTitle(title);
		tnPushSendLog.setContents(contents);
		tnPushSendLog.setDeviceKind(tnUserList.get(0).getDeviceKind());
		tnPushSendLog.setSendSuccessYn("Y");
		tnPushSendLogMapper.insertPushLog(tnPushSendLog);

		FCMUtil2 fcm = new FCMUtil2();
		fcm.setPushKey(tnUserList.get(0).getPushKey());
		fcm.setData("pslId", String.valueOf(tnPushSendLog.getPslId())); // HTTP V1 Integer 값도 String 으로 보내야 함
		fcm.setData("title", title);
		fcm.setData("contents", contents);

		Map<String, Object> resultMap = null;
		try {
			resultMap = fcm.push();
			logger.info(resultMap.toString());
		}catch (Exception e) {
			logger.debug("Exception Message: ",e);
			tnPushSendLogMapper.updateSendSuccess("N");
			throw new ManagedException(ManagedExceptionCode.FailFCMPush, CommonConstants.DEFAULT_FG_LANG);
		}

		return ApiResponse.makeResponse();
	}

	public Map<String, Object> userMember(int scId, Integer userId, String memberNo) {

		TnUserMapping tnUserMapping = new TnUserMapping();

		tnUserMapping.setUserId(userId);
		tnUserMapping.setUserKey("0");
		tnUserMapping.setMemberNO(memberNo);
		tnUserMapping.setScId(scId);

		tnUserMapping.setRegId(Integer.toString(userId));
		tnUserMapping.setModId(Integer.toString(userId));


		if (tnUserMappingMapper.insertUserMapping(tnUserMapping) <= 0)
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse();
	}


	public Map<String, Object> userAtnlc(Integer scId, Integer userId, String atnlcNm, String atnlcPrice, String startDate,
			String endDate, String startTime, String endTime) {
		TnUserAtnlc tnUserAtnlc = new TnUserAtnlc();

		tnUserAtnlc.setUserId(userId);
		tnUserAtnlc.setTransId(0);
		tnUserAtnlc.setAtnclNm(atnlcNm);
		tnUserAtnlc.setAtnclPrice(atnlcPrice);
		tnUserAtnlc.setStartDate(startDate);
		tnUserAtnlc.setEndDate(endDate);
		tnUserAtnlc.setStartTime(startTime);
		tnUserAtnlc.setEndTime(endTime);

		if(tnUserAtnlcMapper.insertUserAtnlc(tnUserAtnlc) <= 0 ) {
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}

		return ApiResponse.makeResponse();
	}

	public Map<String, Object> userLocker(Integer scId, Integer userId, String lockerNo, String startDate, String endDate,
			String startTime, String endTime) {

		TnUserLocker tnUserLocker = new TnUserLocker();

		tnUserLocker.setUserId(Integer.toString(userId));
		tnUserLocker.setScId(Integer.toString(scId));
		tnUserLocker.setLockerNo(lockerNo);
		tnUserLocker.setStartDate(startDate);
		tnUserLocker.setStartTime(startTime);
		tnUserLocker.setEndDate(endDate);
		tnUserLocker.setEndTime(endTime);

		if(tnUserLockerMapper.insertUserLocker(tnUserLocker) <= 0 ) {
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}

		return ApiResponse.makeResponse();
	}


}
