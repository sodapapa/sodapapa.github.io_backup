package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.ljsnc.api.model.OpUserDevice;
import com.ljsnc.api.model.TbApp;

public interface OpUserDeviceMapper {

	@Select(""
			+ "	SELECT count(*) "
			+ " FROM OP_USER_DEVICE "
			+ " WHERE DEVICE_ID = #{deviceId}")
	Integer selectCount(@Param("deviceId")String deviceId);

	@Select(""
			+ "	SELECT DEVICE_ID, CUST_ID, DEVICE_TYPE, PUSH_KEY, CREATED_DATE, CREATED_USER_ID, UPDATED_DATE, UPDATED_USER_ID "
			+ " FROM OP_USER_DEVICE "
			+ " WHERE DEVICE_ID = #{deviceId}")
	Integer selectOne(@Param("deviceId")String deviceId);


	@Insert(""
			+ "INSERT INTO OP_USER_DEVICE(DEVICE_ID, CUST_ID, DEVICE_TYPE, PUSH_KEY, CREATED_DATE, CREATED_USER_ID, UPDATED_DATE, UPDATED_USER_ID) "
			+ " VALUES( #{deviceId}, #{custId}, #{deviceType}, #{pushKey}, DATE_FORMAT(NOW(),'%Y%m%d%H%i%s'), '0', DATE_FORMAT(NOW(),'%Y%m%d%H%i%s'),'0') ")
	Integer insertOne(@Param("deviceId")String deviceId, @Param("custId")String custId,
			@Param("deviceType")String deviceType, @Param("pushKey")String pushKey	);


	@Update(""
			+ " UPDATE OP_USER_DEVICE SET CUST_ID = #{custId}, DEVICE_TYPE = #{deviceType}, PUSH_KEY = #{pushKey},"
			+ " UPDATED_DATE = DATE_FORMAT(NOW(),'%Y%m%d%H%i%s'), UPDATED_USER_ID = '0' "
			+ " WHERE DEVICE_ID = #{deviceId} " )
	Integer updateOne(@Param("deviceId")String deviceId, @Param("custId")String custId,
			@Param("deviceType")String deviceType, @Param("pushKey")String pushKey	);


	@Delete(""
			+ "	DELETE FROM OP_USER_DEVICE WHERE DEVICE_ID = #{deviceId}	")	//삭제하기.
	Integer deleteOne(@Param("deviceId")String deviceId);

	@Select(""
			+ " SELECT DEVICE_TYPE, PUSH_KEY FROM OP_USER_DEVICE WHERE LENGTH(PUSH_KEY) > 10 ORDER BY CREATED_DATE ASC ")
	List<OpUserDevice> selectPushKeyList();


	@Insert(""
			+ " INSERT op_push_target_user SELECT #{pushSeq}, PUSH_KEY, 'N', DATE_FORMAT(NOW(),'%Y%m%d%H%i%s'), '0', DATE_FORMAT(NOW(),'%Y%m%d%H%i%s'), '0' "
			+ " FROM OP_USER_DEVICE WHERE LENGTH(PUSH_KEY) > 10 ORDER BY CREATED_DATE ASC ")
	Integer insertSelectTargerUser( @Param("pushSeq")Integer pushSeq);


}
