package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

// KR, EN, JP
public enum FgLang
{
	Korean("ko"),
	English("en"),
	Japanese("ja"),
	;
	
    private final String stringValue;

    private FgLang(final String newValue)
    {
        stringValue = newValue;
    }

    @JsonValue
    public String toStr()
    {
        return stringValue;
    }

    private static final Map<String, FgLang> lookup = new HashMap<String, FgLang>();

    static
    {
        for (FgLang rt : FgLang.values())
            lookup.put(rt.stringValue, rt);
    }

    public static FgLang get(String typeStr)
    {
        return lookup.get(typeStr);
    }
}
