package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum DeviceKind {
	Android("A"),
	Ios("I")
	;
	
	private final String stringValue;

	private DeviceKind(final String newValue)
	{
	    stringValue = newValue;
	}
	
	@JsonValue
	public String toStr()
	{
	    return stringValue;
	}
	
	private static final Map<String, DeviceKind> lookup = new HashMap<String, DeviceKind>();
	
	static
	{
	    for (DeviceKind rt : DeviceKind.values())
	        lookup.put(rt.stringValue, rt);
	}
	
	public static DeviceKind get(String typeStr)
	{
	    return lookup.get(typeStr);
	}
}
