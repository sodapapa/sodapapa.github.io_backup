package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TnSportsCenterImage implements Serializable {
	private static final long serialVersionUID = 1L;

	private int sciId;
	private int scId;
	private String sciImgUrl;
	private String ordering;
	private String regId;
	private String regDt;
	public int getSciId() {
		return sciId;
	}
	public void setSciId(int sciId) {
		this.sciId = sciId;
	}
	public int getScId() {
		return scId;
	}
	public void setScId(int scId) {
		this.scId = scId;
	}
	public String getSciImgUrl() {
		return sciImgUrl;
	}
	public void setSciImgUrl(String sciImgUrl) {
		this.sciImgUrl = sciImgUrl;
	}
	public String getOrdering() {
		return ordering;
	}
	public void setOrdering(String ordering) {
		this.ordering = ordering;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}


	@Override
	public String toString() {
		return "TnSportsCenterImage [sciId=" + sciId + ", scId=" + scId + ", sciImgUrl=" + sciImgUrl + ", ordering="
				+ ordering + ", regId=" + regId + ", regDt=" + regDt + "]";
	}


}
