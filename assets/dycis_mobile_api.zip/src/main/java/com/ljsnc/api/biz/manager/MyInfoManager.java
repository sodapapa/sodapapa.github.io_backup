package com.ljsnc.api.biz.manager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ljsnc.api.biz.util.ApiResponse;
import com.ljsnc.api.biz.util.KeyGenerator;
import com.ljsnc.api.exception.ManagedException;
import com.ljsnc.api.exception.ManagedExceptionCode;
import com.ljsnc.api.model.TnTermInfo;
import com.ljsnc.api.model.TnUser;
import com.ljsnc.api.model.TnUserAtnlc;
import com.ljsnc.api.model.TnUserTermAgree;
import com.ljsnc.api.model.TnUserTokenInfo;
import com.ljsnc.api.model.TnUserTokenMail;
import com.ljsnc.api.model.response.DtoUserInfo;
import com.ljsnc.api.mybatis.mappers.mysql.TnTermInfoMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserAtnlcMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserLockerMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserTermAgreeMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserTokenInfoMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserTokenMailMapper;
import com.ljsnc.api.util.CommonConstants;
import com.ljsnc.api.util.MailUtil;

@Service
public class MyInfoManager {

	@Autowired TnUserTokenMailMapper 	tnUserTokenMailMapper;
	@Autowired TnTermInfoMapper 		tnTermInfoMapper 	;
	@Autowired TnUserTermAgreeMapper	tnUserTermAgreeMapper;
	@Autowired TnUserLockerMapper	tnUserLockerMapper;
	@Autowired TnUserAtnlcMapper tnUserAtnlcMapper;
	@Autowired TnUserMapper tnUserMapper;
	@Autowired TnUserTokenInfoMapper tnUserTokenInfoMapper ;

	@Value("${dycis.api.host.dev}")
	private String apiHost;

	public Map<String, Object> mailSend(String recvMail, String mailType) {
		// TODO Auto-generated method stub

		TnUserTokenMail tnUserTokenMail = new TnUserTokenMail();

		try {

			String mailCheckToken = KeyGenerator.createKey(CommonConstants.AUTH_TOKEN_LENGTH );

			String subjects = "dycis Fitmoa ";
			String contents = "dycis Fitmoa ";

			if(mailType.equals(CommonConstants.MAIL_TYPE_ID)) {

				subjects += "아이디 찾기 ";
				contents += "아이디 찾기 아래 주소로 접속하여 아이디를 찾아주시기 바랍니다.<br><br>";
				contents += apiHost + "/customer/searchId.html?token=" + mailCheckToken;

			}else {

				subjects += "비밀번호 변경 ";
				contents += "비밀번호 변경 아래 주소로 접속하여 아이디를 변경해주시기 바랍니다.<br><br>";
				contents += apiHost + "/customer/resetPassword.html?token=" + mailCheckToken;
			}

			String result = MailUtil.sendEmail(recvMail, subjects, contents);

			tnUserTokenMail.setMailToken(mailCheckToken);
			tnUserTokenMail.setMailType(mailType);
			tnUserTokenMail.setUserMail(recvMail);
			tnUserTokenMail.setRegId("system");

			if("F".equals(result)) {
				throw new ManagedException(ManagedExceptionCode.FailSendEmail, CommonConstants.DEFAULT_FG_LANG);
			}


		} catch (Exception e) {
			e.printStackTrace();
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}


		if(tnUserTokenMailMapper.insertUserTokenMail(tnUserTokenMail) <= 0) {

			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}

		return ApiResponse.makeResponse();
	}


	public Map<String, Object> termUrl() {
		List<TnTermInfo> tnTermInfoList =  tnTermInfoMapper.findTermInfoListUrl();

		if(tnTermInfoList == null)
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse(tnTermInfoList);
	}


	public Map<String, Object> termInfo(String authToken, Integer userId) {

		List<TnTermInfo> userTermAgreeInfoList = tnUserTermAgreeMapper.getUserTermAgreeInfo(userId);

		if(userTermAgreeInfoList == null)
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse(userTermAgreeInfoList);
	}


	public Map<String, Object> termAgree(String authToken, Integer userId, String termType) {

		List<String> Test = Arrays.asList(termType.split("\\^"));
		System.out.println("test " + Test.toString());

		String arrTermType[] = termType.split("\\^");

		for (int i = 0; i < arrTermType.length; i++) {
 			int termAgreeChk = tnUserTermAgreeMapper.termAgreeChk(userId, arrTermType[i]);

			if(termAgreeChk <= 0) {

				int latestRermId = tnUserTermAgreeMapper.getLatestRermId(arrTermType[i]);

				TnUserTermAgree tmp = new TnUserTermAgree();
				tmp.setUserId(userId);
				tmp.setAgreeYn("Y");
				tmp.setTermId(latestRermId);

				if(tnUserTermAgreeMapper.createUserTermAgreeYn(tmp) <= 0)
					throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);

			}
		}

		return ApiResponse.makeResponse();
	}


	public Map<String, Object> userInfo(Integer userId) {

		DtoUserInfo result = new DtoUserInfo();

		result = tnUserLockerMapper.getUserLockerInfo(userId);
		List<TnUserAtnlc> tnUserAtnlcList= tnUserAtnlcMapper.getLectureInfo(userId);

		if(tnUserAtnlcList.size() > 0 && result != null) { // 락커도 있고 리스트도 있고
			result.setTnUserAtnlcList(tnUserAtnlcList);

			return ApiResponse.makeResponse(result);
		}else if(tnUserAtnlcList.size() > 0 && result == null) { // 락커는 없고 리스트는 있고

			DtoUserInfo result2 = new DtoUserInfo();
			result2.setTnUserAtnlcList(tnUserAtnlcList);

			return ApiResponse.makeResponse(result2);
		}else if(tnUserAtnlcList.size() <= 0 && result == null) { // 락커도 없고 리스트도 없고

			DtoUserInfo result2 = new DtoUserInfo();
			result2.setTnUserAtnlcList(tnUserAtnlcList);

			return ApiResponse.makeResponse(result2);
		}else { 															// 락커만 있고

			return ApiResponse.makeResponse(result);
		}




	}


	public Map<String, Object> userWithdraw(Integer userId, String userPw) {

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat fdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String strCal = fdf.format(cal.getTime());

		if(tnUserMapper.loginCheckByUserId(userId, userPw) <= 0)
			throw new ManagedException(ManagedExceptionCode.IncorrectPassword, CommonConstants.DEFAULT_FG_LANG);

		TnUser tnUser = tnUserMapper.findUserInfo(userId);

		TnUserTokenInfo tnUserTokenInfo = new TnUserTokenInfo();
		tnUserTokenInfo.setUserId(userId);

		TnUser tnUserWithdraw = new TnUser();
			String userLoginId = tnUser.getUserLoginId();
			userLoginId = userLoginId + "_" + strCal;

		tnUserWithdraw.setUserId(userId);
		tnUserWithdraw.setUserLoginId(userLoginId);
		tnUserWithdraw.setWithdrawYn("Y");
		tnUserWithdraw.setUserPw("");

		if(tnUserMapper.withdrawUser(tnUserWithdraw) <= 0 ) {

			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}

		if(tnUserTokenInfoMapper.deleteWithdrawUserToken(tnUserTokenInfo) <= 0 ) {

			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}

		return ApiResponse.makeResponse();
	}

}
