package com.ljsnc.api.mybatis.mappers.mysql;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;

import com.ljsnc.api.model.TnBarcode;

public interface TnBarcodeMapper {
	@SelectKey(statement = "SELECT BARCODE_TOKEN, DATE_FORMAT(EXPIRY_DT, '%Y-%m-%d %H:%i:%s') as EXPIRY_DT FROM tn_barcode WHERE USER_ID = #{userId}", before = false, keyProperty = "barcodeToken,expiryDt", resultType = TnBarcode.class)
	@Insert(""
			+ "INSERT INTO tn_barcode(USER_ID, UM_ID, SC_ID, BARCODE_TOKEN, EXPIRY_DT, REG_ID, REG_DT) "
			+ "VALUES(#{userId}, #{umId}, #{scId}, #{barcodeToken}, #{expiryDt}, #{regId}, NOW()) "
			+ "ON DUPLICATE KEY UPDATE UM_ID = #{umId}, SC_ID = #{scId}, BARCODE_TOKEN = #{barcodeToken}, EXPIRY_DT = #{expiryDt} ")
	int createBarcodeToken(TnBarcode barcodeInfo);
	
	@Select(""
			+ "SELECT "
			+ "		USER_ID "
			+ " 	, UM_ID	"
			+ "		, SC_ID	"
			+ "		, BARCODE_TOKEN	"
			+ "		, DATE_FORMAT(EXPIRY_DT, '%Y-%m-%d %H:%i:%s') AS EXPIRY_DT "
			+ "		, REG_ID "
			+ "		, REG_DT	"
			+ "FROM tn_barcode	"
			+ "WHERE "
			+ "	BARCODE_TOKEN = #{barcodeToken}	")
	TnBarcode findBarcodeToken(@Param("barcodeToken") String barcodeToken);
	
	
	@Delete(""
			+ "DELETE FROM tn_barcode	"
			+ "WHERE USER_ID = #{userId} AND BARCODE_TOKEN = #{barcodeToken} ")
	int deleteBarcodeToken(TnBarcode barcodeInfo);
}
