package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TnUserAtnlc implements Serializable  {
	private static final long serialVersionUID = 1L;

	private int uaId;
	private int userId;
	private int transId;
	private String atnclNm;
	private String atnclPrice;
	private String startDate;
	private String endDate;
	private String startTime;
	private String endTime;
	private String regId;
	private String regDt;
	private String modId;
	private String modDt;

	public int getUaId() {
		return uaId;
	}
	public void setUaId(int uaId) {
		this.uaId = uaId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public String getAtnclNm() {
		return atnclNm;
	}
	public void setAtnclNm(String atnclNm) {
		this.atnclNm = atnclNm;
	}
	public String getAtnclPrice() {
		return atnclPrice;
	}
	public void setAtnclPrice(String atnclPrice) {
		this.atnclPrice = atnclPrice;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getModId() {
		return modId;
	}
	public void setModId(String modId) {
		this.modId = modId;
	}
	public String getModDt() {
		return modDt;
	}
	public void setModDt(String modDt) {
		this.modDt = modDt;
	}

	@Override
	public String toString() {
		return "TnUserAtnlc [uaId=" + uaId + ", userId=" + userId + ", transId=" + transId + ", atnclNm=" + atnclNm
				+ ", atnclPrice=" + atnclPrice + ", startDate=" + startDate + ", endDate=" + endDate + ", startTime="
				+ startTime + ", endTime=" + endTime + ", regId=" + regId + ", regDt=" + regDt + ", modId=" + modId
				+ ", modDt=" + modDt + "]";
	}

}
