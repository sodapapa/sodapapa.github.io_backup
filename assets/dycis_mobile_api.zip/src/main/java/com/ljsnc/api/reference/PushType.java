package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum PushType {
	Text("01")	///텍스트 형식 
	;
	
	private final String stringValue;

	private PushType(final String newValue)
	{
	    stringValue = newValue;
	}
	
	@JsonValue
	public String toStr()
	{
	    return stringValue;
	}
	
	private static final Map<String, PushType> lookup = new HashMap<String, PushType>();
	
	static
	{
	    for (PushType rt : PushType.values())
	        lookup.put(rt.stringValue, rt);
	}
	
	public static PushType get(String typeStr)
	{
	    return lookup.get(typeStr);
	}
}
