package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TcUserCenterInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	private String userKey;
	private String cneterSeqNo;
	private String joinMonth;
	private String cardNo;
	private String memberNo;
	private String representYn;
	private String mobileBarcd;
	private String regYmdt;
	private String regUser;
	private String modYmdt;
	private String modUser;
	public String getUserKey() {
		return userKey;
	}
	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}
	public String getCneterSeqNo() {
		return cneterSeqNo;
	}
	public void setCneterSeqNo(String cneterSeqNo) {
		this.cneterSeqNo = cneterSeqNo;
	}
	public String getJoinMonth() {
		return joinMonth;
	}
	public void setJoinMonth(String joinMonth) {
		this.joinMonth = joinMonth;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public String getRepresentYn() {
		return representYn;
	}
	public void setRepresentYn(String representYn) {
		this.representYn = representYn;
	}
	public String getMobileBarcd() {
		return mobileBarcd;
	}
	public void setMobileBarcd(String mobileBarcd) {
		this.mobileBarcd = mobileBarcd;
	}
	public String getRegYmdt() {
		return regYmdt;
	}
	public void setRegYmdt(String regYmdt) {
		this.regYmdt = regYmdt;
	}
	public String getRegUser() {
		return regUser;
	}
	public void setRegUser(String regUser) {
		this.regUser = regUser;
	}
	public String getModYmdt() {
		return modYmdt;
	}
	public void setModYmdt(String modYmdt) {
		this.modYmdt = modYmdt;
	}
	public String getModUser() {
		return modUser;
	}
	public void setModUser(String modUser) {
		this.modUser = modUser;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
		
}
