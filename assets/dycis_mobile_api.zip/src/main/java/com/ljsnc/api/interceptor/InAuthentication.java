package com.ljsnc.api.interceptor;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.jaxrs.interceptor.JAXRSInInterceptor;
import org.apache.cxf.message.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;

import com.ljsnc.api.exception.ManagedException;
import com.ljsnc.api.exception.ManagedExceptionCode;
import com.ljsnc.api.model.TnUserTokenInfo;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserTokenInfoMapper;
import com.ljsnc.api.reference.AuthKind;
import com.ljsnc.api.util.CommonConstants;


public class InAuthentication extends JAXRSInInterceptor
{
	private static final Logger logger = LoggerFactory.getLogger(InAuthentication.class);

	@Autowired private TnUserTokenInfoMapper tnUserTokenInfoMapper;

	private static int transactionId = 100000001;
	private static synchronized int getTransactionId()
	{
		transactionId++;
		if (transactionId > 999999999)
			transactionId = 100000001;

		return transactionId;
	}


	public boolean excludeApiUrl(String url) {

		boolean isExclude = false;

		if(url.contains("/fm/intro/check") || url.contains("/fm/user/login")
		 || url.contains("/fm/user/reg") || url.contains("/fm/user/isId")
		 || url.contains("/ct/login") || url.contains("/my/term/url")
		 || url.contains("/my/mail/send") || url.contains("/usr/findId")
		 || url.contains("/usr/resetPw")
		 || url.contains("/bd/billboard/write")
		)  {
			isExclude = true;
		}

		return isExclude;
	}

	public void handleMessage(Message message)
	{
		// swagger api 제외..
		if (message.get(Message.REQUEST_URI).toString().contains("api-docs"))
		{
			return;
		}

		MDC.put("TID", "T" + getTransactionId());

		logger.debug("REQUEST_URI:{} {}", message.get(Message.HTTP_REQUEST_METHOD), message.get(Message.REQUEST_URI).toString());

		// 인증 제외 apis
		if ( excludeApiUrl(message.get(Message.REQUEST_URI).toString()) )
		{
			return;
		}

		//Map<String, List<String>> headers = (Map<String, List<String>>)message.get(Message.PROTOCOL_HEADERS);
		// 인증 체크


		try {
			byte[] byteBody = IOUtils.readBytesFromStream(message.getContent(InputStream.class));
//			byte[] byteBody = IOUtils.readBytesFromStream(message.getContent(InputStream.class));

			Map<String, Object> requestBody = new HashMap<String, Object>();
			String[] body = (new String(byteBody)).split("&");

//			System.out.println("body.toString() : " +  new String(byteBody) );
//			logger.debug("CONTENT_TYPE:{} {}", message.get(Message.CONTENT_TYPE));

			if(body.length >= 1) {
				for(String item : body) {
//					System.out.println("item :  " +  item);
					String[] pair = item.split("=");
					String name = "";
					String value = "";

					int len = pair.length;
					for( int i = 0; i < len; i++ ) {
						if(i == 0)
							name = pair[0];
						else if(i == 1)
							value = pair[1];
					}

					requestBody.put(name, value);
				}
			}


			String authKind = null;
			String userOrScId = null ;
			String authToken = (String)requestBody.get("authToken");

			if(message.get(Message.REQUEST_URI).toString().contains("/fm")) {
				authKind = AuthKind.USER.toStr();
				if(requestBody.containsKey("userId")) {
					userOrScId = (String)requestBody.get("userId");
				}else {
					throw new ManagedException(ManagedExceptionCode.EmptyParameter, CommonConstants.DEFAULT_FG_LANG);
				}

			}

			if(message.get(Message.REQUEST_URI).toString().contains("/sc")
					|| message.get(Message.REQUEST_URI).toString().contains("/lc")
					|| message.get(Message.REQUEST_URI).toString().contains("/my")
					|| message.get(Message.REQUEST_URI).toString().contains("/bd")	) {
				authKind = AuthKind.USER.toStr();
				if(requestBody.containsKey("userId")) {
					userOrScId = (String)requestBody.get("userId");
				}else {
					throw new ManagedException(ManagedExceptionCode.EmptyParameter, CommonConstants.DEFAULT_FG_LANG);
				}

			}

			else if(message.get(Message.REQUEST_URI).toString().contains("/ct")) {
				authKind = AuthKind.URMG.toStr();
				if(requestBody.containsKey("scId")) {
					userOrScId = (String)requestBody.get("scId");
				}else {
					throw new ManagedException(ManagedExceptionCode.EmptyParameter, CommonConstants.DEFAULT_FG_LANG);
				}
			}

			TnUserTokenInfo tnUserTokenInfo = null;
			try {
				tnUserTokenInfo = new TnUserTokenInfo();
				tnUserTokenInfo.setUserId(Integer.parseInt(userOrScId));
				tnUserTokenInfo.setAuthToken(authToken);
				tnUserTokenInfo.setAuthKind(authKind);
			} catch(Exception e) {
				e.printStackTrace();
			}


			if(!authToken.equals("test1234")) {

			List<TnUserTokenInfo> tokenInfo = tnUserTokenInfoMapper.isToken(tnUserTokenInfo);

				if( tokenInfo.size() <= 0) {
					throw new ManagedException(ManagedExceptionCode.AuthenticationError, CommonConstants.DEFAULT_FG_LANG);
				}else {

					SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Date tokenRgDt = dt.parse(tokenInfo.get(0).getRegDt());
					Date now = new Date();

					int tokenAavilableTime = 0;
					if(authKind == AuthKind.USER.toStr()) {
						tokenAavilableTime = CommonConstants.USER_AUTH_TOKEN_AVAILABLE_TIME;
					} else if( authKind == AuthKind.URMG.toStr() ) {
						tokenAavilableTime = CommonConstants.CENTER_AUTH_TOKEN_AVAILABLE_TIME;
					}

					long tokenTime = ((now.getTime() - tokenRgDt.getTime()) / 1000 );

					if(tokenTime >= tokenAavilableTime) {
						tnUserTokenInfoMapper.deleteToken(tnUserTokenInfo);
						throw new ManagedException(ManagedExceptionCode.AuthTokenExpired, CommonConstants.DEFAULT_FG_LANG);
					}

					tnUserTokenInfoMapper.updateRegDtToken(tnUserTokenInfo);
				}
			}



			message.setContent(InputStream.class, new ByteArrayInputStream(byteBody));
		} catch (Exception e) {
			if(e instanceof ManagedException) {
				throw (ManagedException)e;
			}

			e.printStackTrace();
		}


		// 16.04.01 FG_LANG
		/*FgLang fgLang = null;
		try
		{
			if (headers.get(CommonConstants.HEADER_FG_LANG) != null)
				fgLang = FgLang.get(headers.get(CommonConstants.HEADER_FG_LANG).get(0));
		}
		catch (Exception e)
		{
			fgLang = null;
		}*/

		// 16.09.20 토른값 설정
		/*List<String> value = new ArrayList<String>();
		value.add("1");
		headers.put(CommonConstants.HEADER_AUTH_TOKEN, value);*/

		//16.11.08 MY API 회원 상태 체크.
		/*if (message.get(Message.REQUEST_URI).toString().contains("/my/"))
		{
			String custId = null;
			try
			{
				custId = headers.get(CommonConstants.HEADER_CUST_ID).get(0);
			}
			catch (Exception e)
			{
				logger.error("custId is Invalid = {}", custId);
				throw new ManagedException(ManagedExceptionCode.InvalidParameter, fgLang);
			}

			try
			{*/
				/* 회원 정보 조회
				TbCustInfo custInfo = this.tbCustInfoMapper.findOne(custId);
				if (custInfo == null || custInfo.getCustState() == CustState.Withdraw)
				{
					logger.error("Cust not Valid = {}", custInfo);
					throw new ManagedException(ManagedExceptionCode.NotMember, fgLang);
				}
				*/
			/*}
			catch (ManagedException me)
			{
				message.put(FaultMode.class, FaultMode.CHECKED_APPLICATION_FAULT); // WARN Log 안찍도록...
				throw me;
			}
			catch (Exception e)
			{
				throw new ManagedException(ManagedExceptionCode.ServerError, fgLang);
			}
		}*/

		// 16.09.20 토른체크제외
		// 16.05.25 AUTH TOKEN
		/*
		String authToken = null, custId = null;
		try
		{
			authToken = headers.get(CommonConstants.HEADER_AUTH_TOKEN).get(0);
			custId = headers.get(CommonConstants.HEADER_CUST_ID).get(0);

			if (this.utilManager.checkTestMode())
				if (authToken.equals("0") || authToken.equals("1"))
					return;
		}
		catch (Exception e)
		{
			logger.error("TOKEN is Invalid = {}, {}", custId, authToken);
			throw new ManagedException(ManagedExceptionCode.InvalidParameter, fgLang);
		}

		try
		{
			String dbToken = this.tbCustInfoMapper.authToken(custId, CustState.Withdraw);
			if (dbToken == null || dbToken.equals(authToken) == false)
			{
				logger.error("TOKEN not Matched = {}, {}", dbToken, authToken);
				throw new ManagedException(ManagedExceptionCode.AuthenticationError, fgLang);
			}
		}
		catch (ManagedException me)
		{
			message.put(FaultMode.class, FaultMode.CHECKED_APPLICATION_FAULT); // WARN Log 안찍도록...
			throw me;
		}
		catch (Exception e)
		{
			throw new ManagedException(ManagedExceptionCode.ServerError, fgLang);
		}
		*/

    }
}