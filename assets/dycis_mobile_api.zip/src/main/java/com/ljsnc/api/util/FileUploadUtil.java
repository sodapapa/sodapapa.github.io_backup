package com.ljsnc.api.util;

import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageFilter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.imageio.ImageIO;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.ljsnc.api.exception.ManagedException;
import com.ljsnc.api.exception.ManagedExceptionCode;

import scala.collection.concurrent.Map;


public class FileUploadUtil {

	private static final Logger logger = LoggerFactory.getLogger(FileUploadUtil.class);

	public static HashMap<String,Object> fileUpload(MultipartFile body, int biId, String fileNm, String Flag)
			throws Exception {

		HashMap<String, Object> resultMap =  new HashMap<String, Object>();

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat fdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String strCal = fdf.format(cal.getTime());
		String savePath = "";

		if(Flag.equals("G")) {

			 savePath = CommonConstants.IMG_UPLOAD_PATH + "/gallery/" + biId ;
			 resultMap.put("filePath", savePath);

		}else if(Flag.equals("P")) {

			 savePath = CommonConstants.IMG_UPLOAD_PATH + "/pds/" + biId ;
			 resultMap.put("filePath", savePath);
		}

		logger.debug("{}, {}, {}", body.getInputStream(), body.getOriginalFilename());
		try
		{

			String fileName = "";

			if (body.getInputStream() == null){

				resultMap.put("result", "false");
				return resultMap;
			}

			File file = new File(savePath);

			if(!file.exists()){

				file.mkdirs();
	        }

			if(Flag.equals("G")) {

				fileName = biId + "_" + strCal + ".jpg";
				String filePath= savePath + "/" +fileName ;
				BufferedImage bufImg0 = ImageIO.read(body.getInputStream());
				ImageIO.write(bufImg0, "jpg", new File(filePath));

				resultMap.put("fileName", fileName);
				resultMap.put("fileFormat", ".jpg");

			}else if(Flag.equals("P")) {

				fileName = fileNm;
				String filePath= savePath + "/" +fileName ;

				InputStream fin =body.getInputStream();
				FileOutputStream fos = new FileOutputStream(filePath);

				byte[] buffer = new byte[1024];

				while(true){

					int count = fin.read(buffer);
					System.out.println("COUNT : " + count);

					if(count == -1){
						System.out.println("더이상 읽은 데이터가 없다.");
						break;
					}

					fos.write(buffer, 0, count);
				}

				fin.close();
				fos.close();
				}
				String fileExtention[] 	= fileName.split(".");


				resultMap.put("fileName", fileName);
				resultMap.put("fileFormat", "."+fileExtention[1]);

		}catch (Exception e)	{
			e.printStackTrace();
			throw new ManagedException(ManagedExceptionCode.LinkError,  CommonConstants.DEFAULT_FG_LANG);
		}

		return resultMap;

	}
}
