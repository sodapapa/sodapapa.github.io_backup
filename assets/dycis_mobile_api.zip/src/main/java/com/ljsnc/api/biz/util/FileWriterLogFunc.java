package com.ljsnc.api.biz.util;

import java.io.File;
import java.io.FileWriter;
import java.util.Map;

import com.ljsnc.api.util.CommonConstants;


public class FileWriterLogFunc {
	/**
	 * 로그 남기기..
	 */
	public static void logWriter(String strFile, String str)
	{
		if(CommonConstants.LOG_IS == false)
			return;
		
		try
		{
			File file = new File(CommonConstants.LOG_PATH);
	        file.createNewFile();
	        
	        FileWriter file2 = new FileWriter(CommonConstants.LOG_PATH+"/" + strFile + "_"+StaticFunc.getDate()+".log", true);
	        
	        file2.write("\n************************************************\n");
	        file2.write("PageCall time : " + StaticFunc.getTime());
	        file2.write("\nStr : " + str);
	        file2.write("\n************************************************\n");
		}
		catch(Exception e){
			e.printStackTrace();
		}
        
	}
	
	
	/**
	 * 로그 남기기..
	 */
	public static void logWriter(String strFile, Map<String, Object>  mapLogs)
	{
		if(CommonConstants.LOG_IS == false)
			return;
		
		try
		{
			File file = new File(CommonConstants.LOG_PATH);
	        file.createNewFile();

	        FileWriter file2 = new FileWriter(CommonConstants.LOG_PATH+"/" + strFile + "_"+StaticFunc.getDate()+".log", true);

	        file2.write("\n\n************************************************\n");
	        file2.write("PageCall time : " + StaticFunc.getTime());
	        
	        //MAP의 KEY값을 이용하여 VALUE값 가져오기
	        for (String mapkey : mapLogs.keySet()){
	        	file2.write("\n" + mapkey + " : " + mapLogs.get(mapkey));
	        }
	        file2.write("\n************************************************\n");
	        file2.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
}
