package com.ljsnc.api.biz.manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ljsnc.api.biz.util.ApiResponse;
import com.ljsnc.api.biz.util.StaticFunc;
import com.ljsnc.api.exception.ManagedException;
import com.ljsnc.api.exception.ManagedExceptionCode;
import com.ljsnc.api.model.TnUser;
import com.ljsnc.api.model.TnUserTokenMail;

import com.ljsnc.api.mybatis.mappers.mysql.TnUserMapper;

import com.ljsnc.api.mybatis.mappers.mysql.TnUserTokenMailMapper;
import com.ljsnc.api.reference.MailType;
import com.ljsnc.api.util.CommonConstants;
import com.ljsnc.api.util.EncryptUtil;

@Service
public class UserManager {
	private static final Logger logger = LoggerFactory.getLogger(UserManager.class);

	@Autowired TnUserTokenMailMapper		tnUserTokenMailMapper;
	@Autowired TnUserMapper					tnUserMapper;

	/*
	 * 19.09.16.
	 * @appFlag = 마켓별 관리 플리그
	 * @deviceKind = 인드로이드: A, 아이폰: I
	 */
	@Transactional
	public Map<String, Object> findIdByMailToken(String token) throws Exception {
		logger.debug("{}, {}", token);

		if( StaticFunc.emptyStr(token) )
			throw new ManagedException(ManagedExceptionCode.EmptyParameter, CommonConstants.DEFAULT_FG_LANG);

		
		TnUserTokenMail tnUserTokenMail = tnUserTokenMailMapper.findEmailByToken(token);
		if(tnUserTokenMail == null) {
			throw new ManagedException(ManagedExceptionCode.AuthTokenExpired, CommonConstants.DEFAULT_FG_LANG);
		}
		
		isTokenExprired(tnUserTokenMail);
		
		MailType mailType = MailType.get(tnUserTokenMail.getMailType());
		if(!MailType.FindId.equals(mailType)) {
			throw new ManagedException(ManagedExceptionCode.AuthenticationError, CommonConstants.DEFAULT_FG_LANG);
		}
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		List<String> tnUserLoginIdList = tnUserMapper.findUserLoginIdListByMail(tnUserTokenMail.getUserMail());
		int size = tnUserLoginIdList.size();
		if(size > 1) {
			for(int j = 0; j < size; j++) {
				StringBuilder loginId = new StringBuilder(tnUserLoginIdList.get(j));
				int len = loginId.length();
				for(int i = 0; i < len; i++) {
					if(i == 1 || i == 3 || i == 5) {
						loginId.setCharAt(i, '*');
					}
				}
				tnUserLoginIdList.set(j, loginId.toString());
			}
		}
		resultMap.put("list", tnUserLoginIdList);
		
		
		tnUserTokenMailMapper.expiryTokenMail(tnUserTokenMail.getUtmId());
		return ApiResponse.makeResponse(resultMap);
	}

	
	@Transactional
	public Map<String, Object> resetPwByMailToken(String token, String userLoginId, String userNm, String newPw) throws Exception {
		logger.debug("{}", token);

		if( StaticFunc.emptyStr(token) || StaticFunc.emptyStr(userLoginId) || StaticFunc.emptyStr(userNm) || 
			StaticFunc.emptyStr(newPw) )
			throw new ManagedException(ManagedExceptionCode.EmptyParameter, CommonConstants.DEFAULT_FG_LANG);

		TnUserTokenMail tnUserTokenMail = tnUserTokenMailMapper.findEmailByToken(token);
		if(tnUserTokenMail == null) {
			throw new ManagedException(ManagedExceptionCode.AuthTokenExpired, CommonConstants.DEFAULT_FG_LANG);
		}
		
		isTokenExprired(tnUserTokenMail);
		
		MailType mailType = MailType.get(tnUserTokenMail.getMailType());
		if(!MailType.ResetPassword.equals(mailType)) {
			throw new ManagedException(ManagedExceptionCode.AuthenticationError, CommonConstants.DEFAULT_FG_LANG);
		}
		
		Matcher pwMacher = Pattern.compile("^(?=.*?[0-9])(?=.*[a-zA-Z]).{10,20}$").matcher(newPw);
		if(!pwMacher.matches()) {
			throw new ManagedException(ManagedExceptionCode.InvalidPassword, CommonConstants.DEFAULT_FG_LANG);
		}
		
		TnUser tnUser = new TnUser();
		tnUser.setUserLoginId(userLoginId);
		tnUser.setUserNm(userNm);
		
		tnUser = tnUserMapper.findUserForRsPw(tnUser);
		
		if(tnUser == null) {
			throw new ManagedException(ManagedExceptionCode.InvalidUser, CommonConstants.DEFAULT_FG_LANG);
		}
		
		if(!tnUserTokenMail.getUserMail().equals(tnUser.getUserEmail())) {
			throw new ManagedException(ManagedExceptionCode.AuthenticationError, CommonConstants.DEFAULT_FG_LANG);
		}
		
		EncryptUtil encryptUtil = new EncryptUtil();
		tnUserMapper.modUserPassword(tnUser.getUserId(), encryptUtil.encryptSHA256(newPw));
		tnUserTokenMailMapper.expiryTokenMail(tnUserTokenMail.getUtmId());
		return ApiResponse.makeResponse();
	}
	
	private boolean isTokenExprired(TnUserTokenMail tnUserTokenMail) throws Exception {
		
		if( "Y".equals(tnUserTokenMail.getConfirmYn())) {
			throw new ManagedException(ManagedExceptionCode.AuthTokenExpired, CommonConstants.DEFAULT_FG_LANG);
		}
		
		Date regDt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(tnUserTokenMail.getRegDt());
		Date current = new Date();
		
		long tokenTime = ((current.getTime() - regDt.getTime()) / 1000);
		
		if(tokenTime >= CommonConstants.MAIL_AUTH_TOKEN_AVAILABLE_TIME) {
			tnUserTokenMailMapper.expiryTokenMail(tnUserTokenMail.getUtmId());
			throw new ManagedException(ManagedExceptionCode.AuthTokenExpired, CommonConstants.DEFAULT_FG_LANG);
		}
		
		return true;
	}


}
