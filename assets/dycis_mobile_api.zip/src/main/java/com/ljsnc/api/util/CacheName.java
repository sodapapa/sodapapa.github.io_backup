package com.ljsnc.api.util;


/**
 * ehcache 이름들 
 */
public interface CacheName
{
	public static final String MESSAGE = "message";
	public static final String CONFIG_API = "configApi";
	public static final String AUTH_TOKEN = "authToken";
}
