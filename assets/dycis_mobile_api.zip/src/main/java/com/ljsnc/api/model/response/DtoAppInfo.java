package com.ljsnc.api.model.response;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.ljsnc.api.biz.util.StaticFunc;

public class DtoAppInfo implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String id;
	private String name;
	private String pid;
	private String app_type;
	private String package_name;
	private String activity_name;
	private Double version_code;
	private String app_url;
	private String auto_start;
	
	public String getAuto_start() {
		return auto_start;
	}
	public void setAuto_start(String auto_start) {
		this.auto_start = StaticFunc.checkStr(auto_start);
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = StaticFunc.checkStr(id);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = StaticFunc.checkStr(name);
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = StaticFunc.checkStr(pid);
	}
	public String getApp_type() {
		return app_type;
	}
	public void setApp_type(String app_type) {
		this.app_type = StaticFunc.checkStr(app_type);
	}
	public Double getVersion_code() {
		return version_code;
	}
	public void setVersion_code(Double version_code) {
		this.version_code = StaticFunc.checkDouble(version_code);
	}
	public String getPackage_name() {
		return package_name;
	}
	public void setPackage_name(String package_name) {
		this.package_name = StaticFunc.checkStr(package_name);
	}
	public String getActivity_name() {
		return activity_name;
	}
	public void setActivity_name(String activity_name) {
		this.activity_name = StaticFunc.checkStr(activity_name);
	}
	public String getApp_url() {
		return app_url;
	}
	public void setApp_url(String app_url) {
		this.app_url = StaticFunc.checkStr(app_url);
	}
	
	@Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this);
    }
}
