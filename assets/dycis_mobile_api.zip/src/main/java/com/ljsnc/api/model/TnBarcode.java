package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_DEFAULT)
public class TnBarcode implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private int userId;
	private int umId;
	private int scId;
	private String barcodeToken;
	private String expiryDt;
	private String regId;
	private String regDt;
	
	

	public int getUserId() {
		return userId;
	}



	public void setUserId(int userId) {
		this.userId = userId;
	}



	public int getUmId() {
		return umId;
	}



	public void setUmId(int umId) {
		this.umId = umId;
	}


	public int getScId() {
		return scId;
	}



	public void setScId(int scId) {
		this.scId = scId;
	}



	public String getBarcodeToken() {
		return barcodeToken;
	}



	public void setBarcodeToken(String barcodeToken) {
		this.barcodeToken = barcodeToken;
	}



	public String getExpiryDt() {
		return expiryDt;
	}



	public void setExpiryDt(String expiryDt) {
		this.expiryDt = expiryDt;
	}



	public String getRegId() {
		return regId;
	}



	public void setRegId(String regId) {
		this.regId = regId;
	}



	public String getRegDt() {
		return regDt;
	}



	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}



	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
