package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum ContentsType {
	Image("IMG"),
	Vod("VOD"),
	Mp3("MP3"),
	Live("LIVE")
	;
	
	private final String stringValue;

	private ContentsType(final String newValue)
	{
	    stringValue = newValue;
	}
	
	@JsonValue
	public String toStr()
	{
	    return stringValue;
	}
	
	private static final Map<String, ContentsType> lookup = new HashMap<String, ContentsType>();
	
	static
	{
	    for (ContentsType rt : ContentsType.values())
	        lookup.put(rt.stringValue, rt);
	}
	
	public static ContentsType get(String typeStr)
	{
	    return lookup.get(typeStr);
	}
}
