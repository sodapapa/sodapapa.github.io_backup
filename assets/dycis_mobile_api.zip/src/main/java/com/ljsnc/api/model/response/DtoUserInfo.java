package com.ljsnc.api.model.response;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.ljsnc.api.biz.util.StaticFunc;
import com.ljsnc.api.model.TnUserAtnlc;

public class DtoUserInfo implements Serializable{
	private static final long serialVersionUID = 1L;

	private int ulId;

	private String scId;
	private String userId;
	private String lockerNo;

	private String startDate;
	private String endDate;
	private String startTime;
	private String endTime;

	private String regId;

	private List<TnUserAtnlc> tnUserAtnlcList;





	public int getUlId() {
		return ulId;
	}





	public void setUlId(int ulId) {
		this.ulId = ulId;
	}





	public String getScId() {
		return scId;
	}





	public void setScId(String scId) {
		this.scId = scId;
	}





	public String getUserId() {
		return userId;
	}





	public void setUserId(String userId) {
		this.userId = userId;
	}





	public String getLockerNo() {
		return lockerNo;
	}





	public void setLockerNo(String lockerNo) {
		this.lockerNo = lockerNo;
	}





	public String getStartDate() {
		return startDate;
	}





	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}





	public String getEndDate() {
		return endDate;
	}





	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}





	public String getStartTime() {
		return startTime;
	}





	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}





	public String getEndTime() {
		return endTime;
	}





	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}





	public String getRegId() {
		return regId;
	}





	public void setRegId(String regId) {
		this.regId = regId;
	}





	public List<TnUserAtnlc> getTnUserAtnlcList() {
		return tnUserAtnlcList;
	}





	public void setTnUserAtnlcList(List<TnUserAtnlc> tnUserAtnlcList) {
		this.tnUserAtnlcList = tnUserAtnlcList;
	}





	@Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this);

    }

}
