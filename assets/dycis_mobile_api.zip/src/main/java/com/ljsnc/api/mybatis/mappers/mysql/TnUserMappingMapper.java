package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

import com.ljsnc.api.model.TnConnLog;
import com.ljsnc.api.model.TnUser;
import com.ljsnc.api.model.TnUserMapping;

public interface TnUserMappingMapper {


	@Insert(""
			+ "INSERT INTO tn_user_mapping(USER_ID, USER_KEY, REG_ID, REG_DT"
			+ "					, MOD_ID, MOD_DT) "
			+ "VALUES (#{userId}, #{userKey}, null"
			+ "			, now(), null, now() )")
	int mappingUser(@Param("userId")int userId, @Param("userKey")String userKey);

	@Select(""
			+ "SELECT * "
			+ "FROM	"
			+ "		tn_user_mapping	"
			+ "WHERE "
			+ "		USER_ID = #{userId}")
	TnUserMapping findUser(@Param(value = "userId") int userId);


	@Select(""
			+ "SELECT * "
			+ "FROM	"
			+ "		tn_user_mapping	"
			+ "WHERE "
			+ "		USER_ID = #{userId} OR USER_KEY = #{userKey} ")
	TnUserMapping isMappingUser(@Param("userId")int userId, @Param("userKey")String userKey);


	@SelectKey(before = false, keyProperty="umId", resultType = int.class, statement=""
			+ "SELECT LAST_INSERT_ID() ")
	@Insert(""
			+ "  INSERT INTO tn_user_mapping "
			+ "              ("
			+ "               USER_ID, "
			+ "               USER_KEY, "
			+ "               SC_ID, "
			+ "               MEMBER_NO, "
			+ "               "
			+ "				 REG_ID, "
			+ "               REG_DT, "
			+ "               MOD_ID, "
			+ "               MOD_DT) "
			+ "  VALUES ( "
			+ "          #{userId}, "
			+ "          #{userKey}, "
			+ "          #{scId}, "
			+ "          #{memberNo}, "
			+ "         			 "
			+ "			#{regId}, "
			+ "          now(), "
			+ "          #{modId}, "
			+ "          now() ); "
			+ "   "
			+ "   "
			+ "")
	int insertUserMapping(TnUserMapping tnUserMapping);

}
