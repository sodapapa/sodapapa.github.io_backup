package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.ljsnc.api.reference.FgLang;

public class TmMsg implements Serializable{
	private static final long serialVersionUID = 1L;
	
	/*시스템 코드*/
	private String cdSys;
	
	/*메세지 코드*/
	private String msgCd;
	
	/*메세지 번호*/
	private String msgNo;
	
	/*언어*/
	private FgLang fgLang;
	
	/*메세지 이름*/
	private String msgNm;
	
	/*메세지 상세*/
	private String msgDesc;
	
	/*등록자*/
	private String regId;
	
	/*등록일*/
	private String regDate;
	
	/*수정자*/
	private String modId;
	
	/*수정일*/
	private String modDate;
	
	public String getCdSys() {
		return cdSys;
	}

	public void setCdSys(String cdSys) {
		this.cdSys = cdSys;
	}

	public String getMsgCd() {
		return msgCd;
	}

	public void setMsgCd(String msgCd) {
		this.msgCd = msgCd;
	}

	public String getMsgNo() {
		return msgNo;
	}

	public void setMsgNo(String msgNo) {
		this.msgNo = msgNo;
	}

	public FgLang getFgLang() {
		return fgLang;
	}

	public void setFgLang(FgLang fgLang) {
		this.fgLang = fgLang;
	}

	public String getMsgNm() {
		return msgNm;
	}

	public void setMsgNm(String msgNm) {
		this.msgNm = msgNm;
	}

	public String getMsgDesc() {
		return msgDesc;
	}

	public void setMsgDesc(String msgDesc) {
		this.msgDesc = msgDesc;
	}

	public String getRegId() {
		return regId;
	}

	public void setRegId(String regId) {
		this.regId = regId;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	public String getModId() {
		return modId;
	}

	public void setModId(String modId) {
		this.modId = modId;
	}

	public String getModDate() {
		return modDate;
	}

	public void setModDate(String modDate) {
		this.modDate = modDate;
	}

	@Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this);
    }
}
