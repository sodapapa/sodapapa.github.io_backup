package com.ljsnc.api.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

/* 2019-10-16 강현구
 * FCM 모듈 (HTTP 프로토콜) 
 * 대양 1차 오픈시 사용
 *  */
public class FCMUtil {

	private static final Logger logger = LoggerFactory.getLogger(FCMUtil.class);
	
	private static final String ENDPOINT = "https://fcm.googleapis.com/fcm/send";
	
	private String auth;
	
	private String pushKey;
	
	private Map<String, Object> data;
	
	private int responseCode;
	
	private String responseMsg;

	public void setAuth(String auth) {
		this.auth = auth;
	}

	public void setPushKey(String pushKey) {
		this.pushKey = pushKey;
	}
	
	public void setData(String key, Object value) {
		if(data == null)
			data = new HashMap<String, Object>();
		
		this.data.put(key, value);
	}
	
	public Map<String, Object> push() {
		URL url;
		Map<String, Object> resultMap = null;
		try {
			url = new URL(ENDPOINT);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			
			con.setRequestMethod("POST");
			con.setDoInput(true);
			con.setRequestProperty("Authorization", "key="+auth);
			con.setRequestProperty("Content-Type", "application/json; UTF-8");
			con.setDoOutput(true);
			
			Map<String, Object> message = new HashMap<String, Object>();
			message.put("data", this.data);
			message.put("to", pushKey);
			
			ObjectMapper mapper = new ObjectMapper();
			String body = mapper.writeValueAsString(message);
			
			logger.info(body);
			
			OutputStream out = con.getOutputStream();
			out.write(body.getBytes());
			out.flush();
			
			out.close();
			
			responseCode = con.getResponseCode();
			responseMsg = con.getResponseMessage();
			BufferedReader bin = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String resposeBody = "";
			String l = null;
			while( (l = bin.readLine()) != null ) {
				resposeBody += l;
			}
			resultMap = new HashMap<String, Object>();
			resultMap.put("code", responseCode);
			resultMap.put("msg", responseMsg);
			resultMap.put("body", resposeBody);
			
		} catch (Exception e) {
			logger.debug("Invalid FCMUtil.class: ", e);
		}
		
		return resultMap;
		
	}
	
}
