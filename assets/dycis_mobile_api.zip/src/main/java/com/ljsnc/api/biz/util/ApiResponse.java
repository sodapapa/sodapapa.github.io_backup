package com.ljsnc.api.biz.util;

import java.util.LinkedHashMap;
import java.util.Map;

import com.ljsnc.api.exception.ManagedException;
import com.ljsnc.api.util.CommonConstants;


public class ApiResponse
{
	/**
	 * 코드, 메시지만 포함한 결과 객체 생성
	 * @return
	 */
	public static Map<String, Object> makeResponse()
	{
		Map<String, Object> response = new LinkedHashMap<String, Object>();

		//Map<String, Object> result = new LinkedHashMap<String, Object>();
		response.put("code", CommonConstants.RESPONSE_SUCCESS_CODE);
		response.put("msg", CommonConstants.RESPONSE_SUCCESS_MSG);
		//response.put("result", result);

		return response;
	}


	/**
	 * 단순 스트링..
	 * @return
	 */
	/*public static Map<String, Object> makeResponseString()
	{
		Map<String, Object> response = new LinkedHashMap<String, Object>();

		Map<String, Object> result = new LinkedHashMap<String, Object>();
		result.put("code", CommonConstants.RESPONSE_SUCCESS_CODE);
		result.put("msg", CommonConstants.RESPONSE_SUCCESS_MSG);
		result.put("host", CommonConstants.RESPONSE_SUCCESS_HOST);
		result.put("hash", CommonConstants.RESPONSE_SUCCESS_HASH);
		response.put("OK", result);

		return response;
	}*/


	/**
	 * ManagedExceptionCode에 해당하는 결과 객체 생성
	 * @param me
	 * @return
	 */
	public static Map<String, Object> makeResponse(ManagedException managedException)
	{
		Map<String, Object> response = new LinkedHashMap<String, Object>();
		//Map<String, Object> result = new LinkedHashMap<String, Object>();

		response.put("code", managedException.getExceptionCode().getCode());
		response.put("msg", managedException.getMsg());
		//response.put("result", result);

		return response;
	}

	/**
	 * 코드, 메시지, data를 포함한 결과 객체 생성
	 * @param list 결과에 담을 data 객체
	 * @return
	 */
	public static Map<String, Object> makeResponse(Object data)
	{
		//Map<String, Object> result = new LinkedHashMap<String, Object>();
		Map<String, Object> response = makeResponse();
		response.put("data", data);

		return response;
	}


	/**
	 * 카카오 통해서 가져올때??
	 * @param list 결과에 담을 data 객체
	 * @return
	 */
	public static Map<String, Object> makeResponse(String code, String msg)
	{
		Map<String, Object> response = new LinkedHashMap<String, Object>();
		//Map<String, Object> result = new LinkedHashMap<String, Object>();
		response.put("code", code);
		response.put("msg", msg);
		//response.put("result", result);

		return response;
	}
}
