package com.ljsnc.api.channels;

import java.util.Map;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ljsnc.api.biz.manager.SportsCenterManager;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;

@Path("sc")
@Produces({ MediaType.APPLICATION_JSON })
@Service
@Api(position = 500, value = "SportsCenter", description = "SportsCenter API")
public class chSportsCenter {
	@Autowired SportsCenterManager sportsCenterManager;

	@Path("/sportcenter/list")
    @POST
    @ApiOperation(position = 501, value = "1. 스포츠센터 목록(검색)", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>		{"
    		+ "<br>			\"scId\": \"1990000001\",			[센터 고유 아이디]"
    		+ "<br>			\"scLoginId\": \"fitmoa\",	[센터 로그인 아이디] "
    		+ "<br>			\"scIsdyYn\": \"\",		[대양회원여부]"
    		+ "<br>			\"scNm\": \"\",			[센터명]"
    		+ "<br>			\"scCn\": \"\"\",		[스포츠 센터 내용]"
    		+ "<br>			\"scTel\": \"\",		[센터 연락처]"
    		+ "<br>			\"scOperTime\": \"\",	[센터 운영시간 ]"
    		+ "<br>			\"scPost\": \"\",		[우편번호  ]"
    		+ "<br>			\"scAddr\": \"\",		[주소  ]"
    		+ "<br>			\"scAddrDetail\": \"\",		[상세주소  ]"
    		+ "<br>			\"scAddrLa\": \"\",		[위도  ]"
    		+ "<br>			\"scAddrLo\": \"\",		[경도  ]"
    		+ "<br>			\"scFrnchsType\": \"\",		[프렌차이즈 타입  ]"
    		+ "<br>			\"scArea\": \"\",		[지역코드]"
    		+ "<br>			\"scCtgry\": \"\",		[카테고리 ]"
    		+ "<br>			\"scRealm\": \"\",		[분야 ]"
    		+ "<br>			\"scInduty\": \"\",		[업종 ]"
    		+ "<br>			\"scItem\": \"\",		[종목 ]"
    		+ "<br>			\"scThema\": \"\",		[테마 ]"
    		+ "<br>			\"scLogoImgUrl\": \"\",		[센터로고 이미지  ]"
    		+ "<br>			\"scMainImgUrl\": \"\",		[센터메인 이미지 ]"
    		+ "<br>		},"
    		+ "<br>		{"
    		+ "<br>			\"scId\": \"1990000002\",			[센터 고유 아이디]"
    		+ "<br>			\"scLoginId\": \"fitmoa2\",	[센터 로그인 아이디] "
    		+ "<br>			\"scIsdyYn\": \"\",		[대양회원여부]"
    		+ "<br>			\"scNm\": \"\",			[센터명]"
    		+ "<br>			\"scCn\": \"\"\",		[스포츠 센터 내용]"
    		+ "<br>			\"scTel\": \"\",		[센터 연락처]"
    		+ "<br>			\"scOperTime\": \"\",	[센터 운영시간 ]"
    		+ "<br>			\"scPost\": \"\",		[우편번호  ]"
    		+ "<br>			\"scAddr\": \"\",		[주소  ]"
    		+ "<br>			\"scAddrDetail\": \"\",		[상세주소  ]"
    		+ "<br>			\"scAddrLa\": \"\",		[위도  ]"
    		+ "<br>			\"scAddrLo\": \"\",		[경도  ]"
    		+ "<br>			\"scFrnchsType\": \"\",		[프렌차이즈 타입  ]"
    		+ "<br>			\"scArea\": \"\",		[지역코드]"
    		+ "<br>			\"scCtgry\": \"\",		[카테고리 ]"
    		+ "<br>			\"scRealm\": \"\",		[분야 ]"
    		+ "<br>			\"scInduty\": \"\",		[업종 ]"
    		+ "<br>			\"scItem\": \"\",		[종목 ]"
    		+ "<br>			\"scThema\": \"\",		[테마 ]"
    		+ "<br>			\"scLogoImgUrl\": \"\",		[센터로고 이미지  ]"
    		+ "<br>			\"scMainImgUrl\": \"\",		[센터메인 이미지 ]"
    		+ "<br>		},"
    		+ "<br>	}"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> List(
    		@FormParam("authToken") @ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
    		@FormParam("userId") @ApiParam(value="회원 key", required = true) Integer userId,
    		@FormParam("searchType") @ApiParam(value="검색 타입", required = false) String searchType,
    		@FormParam("searchText") @ApiParam(value="검색어", required = false) String searchText,
    		@FormParam("pageNo") @ApiParam(value="페이지 번호", required = false) Integer pageNo
    		)

    {
		return this.sportsCenterManager.getCenterList(searchType, searchText, pageNo);
    }

	@Path("/sportcenter/view")
    @POST
    @ApiOperation(position = 502, value = "2. 스포츠센터 상세정보", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>			\"scId\": \"1990000001\",			[센터 고유 아이디]"
    		+ "<br>			\"scLoginId\": \"fitmoa1\",	[센터 로그인 아이디] "
    		+ "<br>			\"scIsdyYn\": \"\",		[대양회원여부]"
    		+ "<br>			\"scNm\": \"\",			[센터명]"
    		+ "<br>			\"scCn\": \"\"\",		[스포츠 센터 내용]"
    		+ "<br>			\"scTel\": \"\",		[센터 연락처]"
    		+ "<br>			\"scOperTime\": \"\",	[센터 운영시간 ]"
    		+ "<br>			\"scPost\": \"\",		[우편번호  ]"
    		+ "<br>			\"scAddr\": \"\",		[주소  ]"
    		+ "<br>			\"scAddrDetail\": \"\",		[상세주소  ]"
    		+ "<br>			\"scAddrLa\": \"\",		[위도  ]"
    		+ "<br>			\"scAddrLo\": \"\",		[경도  ]"
    		+ "<br>			\"scFrnchsType\": \"\",		[프렌차이즈 타입  ]"
    		+ "<br>			\"scArea\": \"\",		[지역코드]"
    		+ "<br>			\"scCtgry\": \"\",		[카테고리 ]"
    		+ "<br>			\"scRealm\": \"\",		[분야 ]"
    		+ "<br>			\"scInduty\": \"\",		[업종 ]"
    		+ "<br>			\"scItem\": \"\",		[종목 ]"
    		+ "<br>			\"scThema\": \"\",		[테마 ]"
    		+ "<br>			\"scLogoImgUrl\": \"\",		[센터로고 이미지  ]"
    		+ "<br>			\"scMainImgUrl\": \"\",		[센터메인 이미지 ]"
    		+ "<br>			\"scCnt\": \"\",		[센터 리스트 갯수]"
    		+ "<br>    		\"sportsCenterImage\": [     "
    		+ "<br>         		 {     "
    		+ "<br>            		\"sciId\": 143,     "
    		+ "<br>            		\"scId\": 1990000001,     "
    		+ "<br>           		 \"sciImgUrl\": \"http://220.76.91.51:8051/sportscenter/1990000001/gallary_20191022101529_00.png \",     "
    		+ "<br>            		\"ordering\": \"0\",     "
    		+ "<br>            		\"regId\": \"1\",     "
    		+ "<br>            		\"regDt\": \"2019-10-22 10:13:47.0\"     "
    		+ "<br>          		},     "
    		+ "<br>          		{     "
    		+ "<br>            		\"sciId\": 145,     "
    		+ "<br>            		\"scId\": 1990000001,     "
    		+ "<br>            		\"sciImgUrl\": \"http://220.76.91.51:8051/sportscenter/1990000001/gallary_20191022101542_00.png\",     "
    		+ "<br>            		\"ordering\": \"0\",     "
    		+ "<br>            		\"regId\": \"1\",     "
    		+ "<br>           		 	\"regDt\": \"2019-10-22 10:14:00.0\"     "
    		+ "<br>          		}     "
    		+ "<br>        ]     "
    		+ "<br>         "
    		+ "<br>	}"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> Info(
    		@FormParam("authToken") @ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
    		@FormParam("userId") @ApiParam(value="푸쉬 발송 대상자 앱 회원 ID", required = false) Integer userId,
    		@FormParam("scId") @ApiParam(value="조회할 센터 아이디", required = false) int scId
    		)

    {
		return this.sportsCenterManager.getCenterInfo(scId);
    }

	@Path("/my/list")
    @POST
    @ApiOperation(position = 503, value = "3. 나의센터목록", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>			\"scId\": \"1990000001\",			[센터 고유 아이디]"
    		+ "<br>			\"scLoginId\": \"fitmoa1\",	[센터 로그인 아이디] "
    		+ "<br>			\"scIsdyYn\": \"Y\",		[대양회원여부]"
    		+ "<br>			\"scNm\": \"문정센터\",			[센터명]"
    		+ "<br>			\"scCn\": \"안녕하세요, 문정센터입니다.\",		[스포츠 센터 내용]"
    		+ "<br>			\"scTel\": \"023071110\",		[센터 연락처]"
    		+ "<br>			\"scOperTime\": \"09:00~23:00\",	[센터 운영시간 ]"
    		+ "<br>			\"scPost\": \"\",		[우편번호  ]"
    		+ "<br>			\"scAddr\": \"서울 특별시 송파구 송파대로 201\",		[주소  ]"
    		+ "<br>			\"scAddrDetail\": \"테라타워2 B동 1709호\",		[상세주소  ]"
    		+ "<br>			\"scAddrLa\": \"37.48760833082481\",		[위도  ]"
    		+ "<br>			\"scAddrLo\": \"127.12023056747016\",		[경도  ]"
    		+ "<br>			\"scFrnchsType\": \"00\",		[프렌차이즈 타입  ]"
    		+ "<br>			\"scArea\": \"01\",		[지역코드]"
    		+ "<br>			\"scCtgry\": \"00\",		[카테고리 ]"
    		+ "<br>			\"scRealm\": \"\",		[분야 ]"
    		+ "<br>			\"scInduty\": \"1000\",		[업종 ]"
    		+ "<br>			\"scItem\": \"00\",		[종목 ]"
    		+ "<br>			\"scThema\": \"0016\",		[테마 ]"
    		+ "<br>			\"scLogoImgUrl\": \"\",		[센터로고 이미지  ]"
    		+ "<br>			\"scMainImgUrl\": \"\",		[센터메인 이미지 ]"
    		+ "<br>	}"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> mylist(
    		@FormParam("authToken") @ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
    		@FormParam("userId") @ApiParam(value="푸쉬 발송 대상자 앱 회원 ID", required = false) Integer userId
    		)

    {
		return this.sportsCenterManager.getMyCenterList(userId);
    }
}
