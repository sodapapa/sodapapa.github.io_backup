package com.ljsnc.api.camel.batch;

import javax.annotation.PostConstruct;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class QuartzManager {
	private static final Logger logger = LoggerFactory.getLogger(QuartzManager.class);
	
	private ProducerTemplate producerTemplate;
	
	@Autowired private CamelContext camelContext;
	
	@PostConstruct
	public void postConstruct()
	{
		// 쿼츠에서 호출하는 경우 ProducerTemplate 를 직접 Autowired 하지 못해서 CamelContext를  Autowired 해서 ProducerTemplate 를 create
		this.producerTemplate = this.camelContext.createProducerTemplate();
	}

	@Transactional
	public void schedulerWeather() throws Exception{
		logger.debug("Weather Quearts Start");
	}
	
	/*
	@Transactional
	public void schedulerEmail() throws Exception{
		logger.debug("PUSH Quearts Start");
		
		
		pushManager.schedulePush();
		
		
		logger.debug("Weather Quearts End");
	}
	*/
	
}
