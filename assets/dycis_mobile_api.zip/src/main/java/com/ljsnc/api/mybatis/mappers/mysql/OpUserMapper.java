package com.ljsnc.api.mybatis.mappers.mysql;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ljsnc.api.model.OpUser;

public interface OpUserMapper {

	@Select(""
			+ "	SELECT USER_ID, USER_TYPE, LOGIN_ID, PASSWORD, USER_NAME, EMAIL, STATUS_CODE, LOGIN_COUNT, SLEEP_MAIL_SEND_DATE, LOGIN_DATE, DENY_DATE, LEAVE_DATE, UPDATED_DATE, CREATED_DATE"
			+ "	FROM OP_USER"
			+ "	WHERE USER_ID = #{userId}")
	OpUser selectUser(@Param("userId") String userId);

}
