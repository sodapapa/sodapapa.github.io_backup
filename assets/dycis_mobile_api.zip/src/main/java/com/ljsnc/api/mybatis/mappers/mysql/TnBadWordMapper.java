package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Select;

public interface TnBadWordMapper {

	@Select(""
			+ "SELECT	"
			+ "		BAD_WORD	"
			+ "FROM"
			+ "		tn_bad_word 	"
			+ "")
	List<String> badWordList();
}
