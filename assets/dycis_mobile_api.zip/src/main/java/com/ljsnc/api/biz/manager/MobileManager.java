package com.ljsnc.api.biz.manager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ljsnc.api.biz.util.ApiResponse;
import com.ljsnc.api.biz.util.KeyGenerator;
import com.ljsnc.api.biz.util.StaticFunc;
import com.ljsnc.api.exception.ManagedException;
import com.ljsnc.api.exception.ManagedExceptionCode;
import com.ljsnc.api.model.TcUserCenterInfo;
import com.ljsnc.api.model.TcUserInfo;
import com.ljsnc.api.model.TnAppConfig;
import com.ljsnc.api.model.TnBarcode;
import com.ljsnc.api.model.TnConnLog;
import com.ljsnc.api.model.TnPushSendLog;
import com.ljsnc.api.model.TnTermInfo;
import com.ljsnc.api.model.TnUser;
import com.ljsnc.api.model.TnUserMapping;
import com.ljsnc.api.model.TnUserTermAgree;
import com.ljsnc.api.model.TnUserTokenInfo;
import com.ljsnc.api.model.response.DtoLoginInfo;
import com.ljsnc.api.mybatis.mappers.mysql.TcUserCenterInfoMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TcUserInfoMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnAppConfigMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnBarcodeMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnPushSendLogMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnTermInfoMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserMappingMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserTermAgreeMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserTokenInfoMapper;
import com.ljsnc.api.reference.DeviceKind;
import com.ljsnc.api.reference.Gender;
import com.ljsnc.api.reference.TermType;
import com.ljsnc.api.reference.UserType;
import com.ljsnc.api.util.CommonConstants;

@Service
public class MobileManager {
	private static final Logger logger = LoggerFactory.getLogger(MobileManager.class);

	@Autowired TnAppConfigMapper		tnAppConfigMapper;
	@Autowired TnUserMapper 			tnUserMapper;
	@Autowired TnUserMappingMapper		tnUserMappingMapper;
	@Autowired TnUserTokenInfoMapper 	tnUserTokenInfoMapper;
	@Autowired TnBarcodeMapper 			tnBarcodeMapper;
	@Autowired TnTermInfoMapper			tnTermInfoMapper;
	@Autowired TnUserTermAgreeMapper	tnUserTermAgreeMapper;
	@Autowired TcUserCenterInfoMapper	tcUserCenterInfoMapper;
	@Autowired TcUserInfoMapper			tcUserInfoMapper;
	@Autowired TnPushSendLogMapper		tnPushSendLogMapper;

	/*
	 * 19.09.16.
	 * @appFlag = 마켓별 관리 플리그
	 * @deviceKind = 인드로이드: A, 아이폰: I
	 */
	public Map<String, Object> introCheck(String appFlag, String deviceKind, Integer appVer) {
		logger.debug("{}, {}", appFlag, deviceKind);

		if( StaticFunc.emptyStr(appFlag) || DeviceKind.get(deviceKind) == null )
			throw new ManagedException(ManagedExceptionCode.EmptyParameter, CommonConstants.DEFAULT_FG_LANG);

		//디바이스 검사
		if(DeviceKind.get(deviceKind) == null){
			throw new ManagedException(ManagedExceptionCode.InvalidDeviceKind, CommonConstants.DEFAULT_FG_LANG);
		}

		TnAppConfig tnAppConfig = tnAppConfigMapper.selectAppVersion(deviceKind);

		if(tnAppConfig == null){
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);
		}

		int updateY = tnAppConfigMapper.findUpdateY(deviceKind, appVer);

		if(updateY > 0) {
			tnAppConfig.setUpdateYn("Y");
		}else {
			tnAppConfig.setUpdateYn("N");
		}

		return ApiResponse.makeResponse(tnAppConfig);
	}



	/*
	 * 19.09.16.
	 * @userLoginId = 마켓별 관리 플러그
	 * @userPw = 비밀번호(특수문자 영문 숫자 10~16)
	 * @deviceId = 단말 id
	 * @deviceKind = 인드로이드: A, 아이폰: I
	 * @pushKey = 푸쉬키
	 */
	@Transactional
	public Map<String, Object> userLogin(String userLoginId, String userPw, String deviceId, String deviceKind, String pushKey) {
		logger.debug("{}, {}, {}, {}, {}", userLoginId, userPw, deviceId, deviceKind, pushKey);

		if( StaticFunc.emptyStr(userLoginId) || StaticFunc.emptyStr(userPw) )
			throw new ManagedException(ManagedExceptionCode.EmptyParameter, CommonConstants.DEFAULT_FG_LANG);


		TnUser tnUser = tnUserMapper.loginCheck(userLoginId, userPw);

		if(tnUser == null)
			throw new ManagedException(ManagedExceptionCode.InvalidLogin, CommonConstants.DEFAULT_FG_LANG);

		TnUserTokenInfo tokenInfo = new TnUserTokenInfo();
		tokenInfo.setUserId(tnUser.getUserId());
		tokenInfo.setAuthKind("USER");
		tnUserTokenInfoMapper.deleteToken(tokenInfo);

		String loginToken = KeyGenerator.createKey( CommonConstants.AUTH_TOKEN_LENGTH );
		tokenInfo.setAuthToken(loginToken);

		if(tnUserTokenInfoMapper.createToken(tokenInfo) <= 0) {
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}else {
			TnConnLog tnConnLog = new TnConnLog();
			tnConnLog.setUserLoginId(userLoginId);
			tnConnLog.setDeviceKind(deviceKind);

			SimpleDateFormat sf = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
			String connDt = sf.format(new Date());
			tnConnLog.setConnDt(connDt);
			tnUserMapper.createLoginSuccessLog(tnConnLog);
			tnUserMapper.updateUserConn(tnUser.getUserId(), deviceId, deviceKind, pushKey, connDt);
		}

		DtoLoginInfo dtoLoginInfo = new DtoLoginInfo();

		dtoLoginInfo.setAuthToken(loginToken);
		dtoLoginInfo.setUserGender(tnUser.getUserGender());
		dtoLoginInfo.setUserId(tnUser.getUserId());
		dtoLoginInfo.setUserNm(tnUser.getUserNm());
		dtoLoginInfo.setUserType(tnUser.getUserType());

		return ApiResponse.makeResponse(dtoLoginInfo);
	}


	/*
	 * 19.09.16.
	 * @userLoginId = 마켓별 관리 플러그
	 * @userPw = 비밀번호(특수문자 영문 숫자 10~16)
	 * @userNm = 유저 이름
	 * @phoneNo = 휴대폰 번호
	 * @userEmail = 이메일
	 * @userBirthday = 생년월일
	 * @userGender = 성별 ( 남: 01, 여: 02 )
	 * @userAddr = 주소
	 * @userAddrDetail = 상세 주소
	 * @pushKey = 푸쉬키
	 * @deviceId = 단말 id
	 * @deviceKind = 인드로이드: A, 아이폰: I
	 * @pushKey = 푸쉬키
	 */
	@Transactional
	public Map<String, Object> userRegist(String userLoginId, String userPw, String userNm, String phoneNo
			, String userEmail, String userBirthday, String userGender, String userAddr, String userAddrDetail
			, String pushKey, String deviceId, String deviceKind) {

		logger.info("{}, {}, {}, {}, {} ,{}, {}, {}", userLoginId, userPw, userNm, phoneNo, userEmail, userBirthday, deviceId, deviceKind);

		if( StaticFunc.emptyStr(userLoginId) || StaticFunc.emptyStr(userPw) || StaticFunc.emptyStr(userNm)
				|| StaticFunc.emptyStr(phoneNo) || StaticFunc.emptyStr(userEmail) || StaticFunc.emptyStr(userBirthday)
				|| StaticFunc.emptyStr(deviceId) || StaticFunc.emptyStr(deviceKind) )
			throw new ManagedException(ManagedExceptionCode.EmptyParameter, CommonConstants.DEFAULT_FG_LANG);

		// 아이디 존재 검사
		if(tnUserMapper.isLoginId(userLoginId) >= 1) {
			throw new ManagedException(ManagedExceptionCode.ExistID, CommonConstants.DEFAULT_FG_LANG);
		}

		// 아이디 유효성 검사
		Matcher loginIdMacher = Pattern.compile("^[a-zA-Z0-9]{6,20}$").matcher(userLoginId);
		if(!loginIdMacher.matches()) {
			throw new ManagedException(ManagedExceptionCode.InvalidID, CommonConstants.DEFAULT_FG_LANG);
		}

		// 비밀번호 유효성 검사
		/*Matcher pwMacher = Pattern.compile("^(?=.*?[0-9])(?=.*[a-zA-Z]).{10,20}$").matcher(userPw);
		if(!pwMacher.matches()) {
			throw new ManagedException(ManagedExceptionCode.InvalidPassword, CommonConstants.DEFAULT_FG_LANG);
		}*/

		// 전화번호 유효성 검사
		Matcher phoneNoMacher = Pattern.compile("^(01[0-9])(\\d{3,4})(\\d{4})$").matcher(phoneNo);
		if(!phoneNoMacher.matches()) {
			throw new ManagedException(ManagedExceptionCode.InvalidPhoneNo, CommonConstants.DEFAULT_FG_LANG);
		}

		// 이메일 유효성 검사
		Matcher emailMacher = Pattern.compile("^([0-9a-zA-Z_\\.-]+)@([0-9a-zA-Z_-]+)(\\.[0-9a-zA-Z_-]+){1,2}$").matcher(userEmail);
		if(!emailMacher.matches()) {
			throw new ManagedException(ManagedExceptionCode.InvalidEmail, CommonConstants.DEFAULT_FG_LANG);
		}

		if(Gender.get(userGender) == null) {
			throw new ManagedException(ManagedExceptionCode.InvalidGender, CommonConstants.DEFAULT_FG_LANG);
		}

		// 생년월일 유효성 검사
		Matcher birthdayMacher = Pattern.compile("^(19[0-9][0-9]|20\\d{2})(0[0-9]|1[0-2])(0[1-9]|[1-2][0-9]|3[0-1])$").matcher(userBirthday);
		if(!birthdayMacher.matches()) {
			throw new ManagedException(ManagedExceptionCode.InvalidBirthday, CommonConstants.DEFAULT_FG_LANG);
		}

		if(deviceId.length() > 100) {
			throw new ManagedException(ManagedExceptionCode.InvalidDeviceLength, CommonConstants.DEFAULT_FG_LANG);
		}

		//디바이스 검사
		if(DeviceKind.get(deviceKind) == null){
			throw new ManagedException(ManagedExceptionCode.InvalidDeviceKind, CommonConstants.DEFAULT_FG_LANG);
		}


		TnUser tnUser = new TnUser();
		tnUser.setUserLoginId(userLoginId);
		tnUser.setUserPw(userPw);
		tnUser.setUserNm(userNm);
		tnUser.setPhoneNo(phoneNo);
		tnUser.setUserEmail(userEmail);
		tnUser.setUserBirthday(userBirthday);
		tnUser.setUserType(UserType.AssociateMember.toStr());
		tnUser.setUserGender(userGender);
		tnUser.setUserAddr(userAddr);
		tnUser.setUserAddrDetail(userAddrDetail);
		tnUser.setPushKey(pushKey);
		tnUser.setDeviceId(deviceId);
		tnUser.setDeviceKind(deviceKind);

		if(tnUserMapper.registUser(tnUser) <= 0) {
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}

		List<TnTermInfo> tnTermInfo = tnTermInfoMapper.findTermInfoList();

		List<TnUserTermAgree> tnUserTermAgreeList = new ArrayList<TnUserTermAgree>();
		for( int i = 0; i < 2; i++ ) {
			TnUserTermAgree tmp = new TnUserTermAgree();
			tmp.setUserId(tnUser.getUserId());
			tmp.setTermId(tnTermInfo.get(i).getTermId());
			tmp.setAgreeYn("Y");
			tnUserTermAgreeList.add(tmp);
		}

		tnUserTermAgreeMapper.createUserTermAgreeYnMulti(tnUserTermAgreeList);

		return ApiResponse.makeResponse();
	}

	/*
	 * 19.09.16.
	 * @userId = 유저 식별 pk key
	 * @userNm = 유저 이름
	 * @phoneNo = 휴대폰 번호
	 * @userEmail = 이메일
	 * @userBirthday = 생년월일
	 * @userGender = 성별 ( 남: 01, 여: 02 )
	 * @userPost = 번지
	 * @userAddr = 주소
	 * @userAddrDetail = 상세 주소
	 */
	public Map<String, Object> modUser(int userId, String userNm, String phoneNo
			, String userEmail, String userBirthday, String userGender, String userPost, String userAddr
			, String userAddrDetail) {

		if(tnUserMapper.findUser(userId) <= 0) {
			throw new ManagedException(ManagedExceptionCode.InvalidUser, CommonConstants.DEFAULT_FG_LANG);
		}

		// 전화번호 유효성 검사
		Matcher phoneNoMacher = Pattern.compile("^(01[0-9])(\\d{3,4})(\\d{4})$").matcher(phoneNo);
		if(!phoneNoMacher.matches()) {
			throw new ManagedException(ManagedExceptionCode.InvalidPhoneNo, CommonConstants.DEFAULT_FG_LANG);
		}

		// 이메일 유효성 검사
		Matcher emailMacher = Pattern.compile("^([0-9a-zA-Z_\\.-]+)@([0-9a-zA-Z_-]+)(\\.[0-9a-zA-Z_-]+){1,2}$").matcher(userEmail);
		if(!emailMacher.matches()) {
			throw new ManagedException(ManagedExceptionCode.InvalidEmail, CommonConstants.DEFAULT_FG_LANG);
		}

		// 생년월일 유효성 검사
		Matcher birthdayMacher = Pattern.compile("^(19[0-9][0-9]|20\\d{2})(0[0-9]|1[0-2])(0[1-9]|[1-2][0-9]|3[0-1])$").matcher(userBirthday);
		if(!birthdayMacher.matches()) {
			throw new ManagedException(ManagedExceptionCode.InvalidBirthday, CommonConstants.DEFAULT_FG_LANG);
		}

		if(Gender.get(userGender) == null) {
			throw new ManagedException(ManagedExceptionCode.InvalidGender, CommonConstants.DEFAULT_FG_LANG);
		}

		TnUser tnUser = new TnUser();
		tnUser.setUserId(userId);
		tnUser.setUserNm(userNm);
		tnUser.setPhoneNo(phoneNo);
		tnUser.setUserEmail(userEmail);
		tnUser.setUserBirthday(userBirthday);
		tnUser.setUserGender(userGender);
		tnUser.setUserPost(userPost);
		tnUser.setUserAddr(userAddr);
		tnUser.setUserAddrDetail(userAddrDetail);

		if(tnUserMapper.modUser(tnUser) <= 0) {
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}

		return ApiResponse.makeResponse();
	}

	/*
	 * 19.09.16.
	 * @userId = 유저 식별 pk key
	 */
	public Map<String, Object> findUserInfo(int userId) {
		TnUser tnUser = tnUserMapper.findUserInfo(userId);
		if(tnUser == null) {
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);
		}

		return ApiResponse.makeResponse(tnUser);
	}


	/*
	 * 19.09.16.
	 * @userId = 유저 식별 pk key
	 */
	@Transactional
	public Map<String, Object> createBarcode(int userId) {

		TnUserMapping tnUserMapping =  tnUserMappingMapper.findUser(userId);
		if(tnUserMapping == null)
			throw new ManagedException(ManagedExceptionCode.InvalidUserType, CommonConstants.DEFAULT_FG_LANG);

		TcUserInfo tcUserInfo = tcUserInfoMapper.findUserInfo(tnUserMapping.getUserKey());

		//TcUserCenterInfo tcUserCenterInfo = tcUserCenterInfoMapper.findUserCenterInfo(tnUserMapping.getUserKey());
		//if(tcUserCenterInfo == null)
		if(tcUserInfo == null)
			throw new ManagedException(ManagedExceptionCode.InvalidCenterUser, CommonConstants.DEFAULT_FG_LANG);

		String membershipNo = tcUserInfo.getUserKey(); // 8자리 또는 12 자리

		int reandomKeyLen = 16 - membershipNo.length();

		/*int randomKeyLen = CommonConstants.BARCODE_TOKEN_LENGTH;
		if(membershipNo.length() == 12) {
			randomKeyLen = CommonConstants.BARCODE_TOKEN_LENGTH_4;
		}*/
		String barcodeToken = membershipNo + KeyGenerator.createBarcode( reandomKeyLen ); // 8자리 또는 4자리

		// 바코드 토큰 총 16 자리

		Date current = new Date();
		current.setTime(current.getTime() + (CommonConstants.BARCODE_AVAILABLE_TIME*1000));
		String expiryDt = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss").format(current);

		TnBarcode tnBarcode = new TnBarcode();
		tnBarcode.setBarcodeToken(barcodeToken);
		tnBarcode.setExpiryDt(expiryDt);
		tnBarcode.setUserId(userId);
		tnBarcode.setUmId(tnUserMapping.getUmId());
		tnBarcode.setRegId(null);

		if( tnBarcodeMapper.createBarcodeToken(tnBarcode) <= 0 ) {
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}

		tnBarcode.setUserId(0);
		tnBarcode.setUmId(0);

		return ApiResponse.makeResponse(tnBarcode);
	}


	/*
	 * 19.09.16.
	 * @userLoginId = 유저 로그인 아이디
	 */
	public Map<String, Object> isLoginId(String userLoginId) {

		if(StaticFunc.emptyStr(userLoginId))
			throw new ManagedException(ManagedExceptionCode.InvalidParameter, CommonConstants.DEFAULT_FG_LANG);

		if(tnUserMapper.isLoginId(userLoginId) > 0) {
			throw new ManagedException(ManagedExceptionCode.ExistID, CommonConstants.DEFAULT_FG_LANG);
		}

		return ApiResponse.makeResponse();
	}


	/*
	 * 19.09.16.
	 * @userId = 유저 key 값
	 * @termType = 약관 타입
	 */
	public Map<String, Object> getTermInfo(int userId, String termType) {

		if(tnUserMapper.findUser(userId) <= 0) {
			throw new ManagedException(ManagedExceptionCode.InvalidUser, CommonConstants.DEFAULT_FG_LANG);
		}

		if(TermType.get(termType) == null) {
			throw new ManagedException(ManagedExceptionCode.InvalidParameter, CommonConstants.DEFAULT_FG_LANG);
		}

		TnTermInfo tnTermInfo = tnTermInfoMapper.findTermInfo(termType);

		if(tnTermInfo == null)
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse(tnTermInfo);
	}


	/*
	 * 19.09.16.
	 * @userId = 유저 key 값
	 * @termId = 약관 타입
	 */
	public Map<String, Object> createTermAgreeYn(int userId, int termId, String agreeYn) {

		/*
		 * if(tnUserMapper.findUser(userId) <= 0) { throw new
		 * ManagedException(ManagedExceptionCode.InvalidUser,
		 * CommonConstants.DEFAULT_FG_LANG); }
		 *
		 * if(TermType.get(termType) == null) { throw new
		 * ManagedException(ManagedExceptionCode.InvalidParameter,
		 * CommonConstants.DEFAULT_FG_LANG); }
		 */

		TnUserTermAgree tnUserTermAgree = new TnUserTermAgree();
		tnUserTermAgree.setUserId(userId);
		tnUserTermAgree.setTermId(termId);
		tnUserTermAgree.setAgreeYn(agreeYn);

		if(tnUserTermAgreeMapper.createUserTermAgreeYn(tnUserTermAgree) <= 0)
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse();
	}



	public Map<String, Object> modUserPw(int userId, String nowpwd, String newpwd) {

		if(tnUserMapper.loginCheckByUserId(userId, nowpwd) <= 0)
			throw new ManagedException(ManagedExceptionCode.IncorrectOldPassword, CommonConstants.DEFAULT_FG_LANG);

		if(tnUserMapper.modUserPassword(userId, newpwd) <= 0)
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse();
	}



	public Map<String, Object> findPushList(int userId, Integer pageNo) {

		if(pageNo == null)
			throw new ManagedException(ManagedExceptionCode.EmptyParameter, CommonConstants.DEFAULT_FG_LANG);

		if (pageNo <= 0) {
			pageNo = 1;
		}


		List<TnPushSendLog> tnPushSendLogList = tnPushSendLogMapper.findPushLogList(userId, pageNo);
		/*
		 * if(tnPushSendLogList.size() <= 0) { throw new
		 * ManagedException(ManagedExceptionCode.NotExistData,
		 * CommonConstants.DEFAULT_FG_LANG); }
		 */
		int totalCnt = tnPushSendLogMapper.findPushLogListCnt(userId);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("totalCnt", totalCnt);
		resultMap.put("rows", tnPushSendLogList);

		return ApiResponse.makeResponse(resultMap);
	}


	public Map<String, Object> readPush(int userId, Integer pslId) {

		if(pslId == null)
			throw new ManagedException(ManagedExceptionCode.EmptyParameter, CommonConstants.DEFAULT_FG_LANG);

		int result = tnPushSendLogMapper.updatePushLog(pslId, userId);

		if( result <= 0 ) {
			throw new ManagedException(ManagedExceptionCode.InvalidParameter, CommonConstants.DEFAULT_FG_LANG);
		}

		TnPushSendLog tnPushSendLog = tnPushSendLogMapper.findPushLogByPslId(pslId, userId);


		return ApiResponse.makeResponse(tnPushSendLog);
	}


/*
	public Map<String, Object> getTermInfoUrl(int userId, String termType) {

		if(tnUserMapper.findUser(userId) <= 0) {
			throw new ManagedException(ManagedExceptionCode.InvalidUser, CommonConstants.DEFAULT_FG_LANG);
		}

		if(TermType.get(termType) == null) {
			throw new ManagedException(ManagedExceptionCode.InvalidParameter, CommonConstants.DEFAULT_FG_LANG);
		}

		TnTermInfo tnTermInfo = tnTermInfoMapper.findTermInfoUrl(termType);

		if(tnTermInfo == null)
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse(tnTermInfo);
	}



	public Map<String, Object> createTermAgreeUrlYn(int userId, int termId, String agreeYn) {


		 * if(tnUserMapper.findUser(userId) <= 0) { throw new
		 * ManagedException(ManagedExceptionCode.InvalidUser,
		 * CommonConstants.DEFAULT_FG_LANG); }
		 *
		 * if(TermType.get(termType) == null) { throw new
		 * ManagedException(ManagedExceptionCode.InvalidParameter,
		 * CommonConstants.DEFAULT_FG_LANG); }


		TnUserTermAgree tnUserTermAgree = new TnUserTermAgree();
		tnUserTermAgree.setUserId(userId);
		tnUserTermAgree.setTermId(termId);
		tnUserTermAgree.setAgreeYn(agreeYn);

		if(tnUserTermAgreeMapper.createUserTermAgreeUrlYn(tnUserTermAgree) <= 0)
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse();
	}*/

}
