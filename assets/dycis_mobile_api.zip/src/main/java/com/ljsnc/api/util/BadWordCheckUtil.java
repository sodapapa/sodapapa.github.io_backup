package com.ljsnc.api.util;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;

import com.ljsnc.api.mybatis.mappers.mysql.TnBadWordMapper;

/**
 * 금지어 필터링하기
 *
 */

public class BadWordCheckUtil {


    public static String filterText(String sText, String badWordList) {

        Pattern p = Pattern.compile(badWordList, Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(sText);
        StringBuffer sb = new StringBuffer();

        while (m.find()) {
//            System.out.println(m.group());
            m.appendReplacement(sb, maskWord(m.group()));
        }

        m.appendTail(sb);

        //System.out.println(sb.toString());
        return stripHTML(sb.toString());
    }

    public static String stripHTML(String htmlStr) {
    	Pattern p = Pattern.compile("<(?:.|\\s)*?>");
    	Matcher m = p.matcher(htmlStr);

    	return m.replaceAll("");
    }



    public static String maskWord(String word) {
        StringBuffer buff = new StringBuffer();
        char[] ch = word.toCharArray();
        for (int i = 0; i < ch.length; i++) {
                buff.append("*");
        }
        return buff.toString();
    }
}


