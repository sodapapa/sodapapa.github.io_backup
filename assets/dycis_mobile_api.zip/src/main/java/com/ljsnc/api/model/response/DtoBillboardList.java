package com.ljsnc.api.model.response;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class DtoBillboardList implements Serializable{
	private static final long serialVersionUID = 1L;

	     private int biId;
	     private String biTitle;
	     private String biContents;
	     private int pBiId;
	     private int rBiId;
	     private int biDepth;
	     private String noticeYn;
	     private String pwdYn;
	     private int likeCnt;
	     private int readCnt;
	     private String regDate;
	     private String writeNm;
	     private String writeImg;
	     private String readYn;
	     private String likeYn;





	public int getBiId() {
			return biId;
		}





		public void setBiId(int biId) {
			this.biId = biId;
		}





		public String getBiTitle() {
			return biTitle;
		}





		public void setBiTitle(String biTitle) {
			this.biTitle = biTitle;
		}





		public String getBiContents() {
			return biContents;
		}





		public void setBiContents(String biContents) {
			this.biContents = biContents;
		}





		public int getpBiId() {
			return pBiId;
		}





		public void setpBiId(int pBiId) {
			this.pBiId = pBiId;
		}





		public int getrBiId() {
			return rBiId;
		}





		public void setrBiId(int rBiId) {
			this.rBiId = rBiId;
		}





		public int getBiDepth() {
			return biDepth;
		}





		public void setBiDepth(int biDepth) {
			this.biDepth = biDepth;
		}





		public String getNoticeYn() {
			return noticeYn;
		}





		public void setNoticeYn(String noticeYn) {
			this.noticeYn = noticeYn;
		}





		public String getPwdYn() {
			return pwdYn;
		}





		public void setPwdYn(String pwdYn) {
			this.pwdYn = pwdYn;
		}





		public int getLikeCnt() {
			return likeCnt;
		}





		public void setLikeCnt(int likeCnt) {
			this.likeCnt = likeCnt;
		}





		public int getReadCnt() {
			return readCnt;
		}





		public void setReadCnt(int readCnt) {
			this.readCnt = readCnt;
		}





		public String getRegDate() {
			return regDate;
		}





		public void setRegDate(String regDate) {
			this.regDate = regDate;
		}





		public String getWriteNm() {
			return writeNm;
		}





		public void setWriteNm(String writeNm) {
			this.writeNm = writeNm;
		}





		public String getWriteImg() {
			return writeImg;
		}





		public void setWriteImg(String writeImg) {
			this.writeImg = writeImg;
		}





		public String getReadYn() {
			return readYn;
		}





		public void setReadYn(String readYn) {
			this.readYn = readYn;
		}





		public String getLikeYn() {
			return likeYn;
		}





		public void setLikeYn(String likeYn) {
			this.likeYn = likeYn;
		}





	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
