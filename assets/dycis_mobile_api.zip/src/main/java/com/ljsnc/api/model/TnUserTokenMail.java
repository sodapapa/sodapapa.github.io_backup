package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TnUserTokenMail implements Serializable  {
	private static final long serialVersionUID = 1L;

	private int utmId;

	private String mailToken;
	private String mailType;
	private String userMail;
	private String confirmYn;

	private String regId;
	private String regDt;



	public String getUserMail() {
		return userMail;
	}


	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}


	public int getUtmId() {
		return utmId;
	}


	public void setUtmId(int utmId) {
		this.utmId = utmId;
	}

	public String getMailToken() {
		return mailToken;
	}

	public void setMailToken(String mailToken) {
		this.mailToken = mailToken;
	}

	public String getMailType() {
		return mailType;
	}

	public void setMailType(String mailType) {
		this.mailType = mailType;
	}

	public String getConfirmYn() {
		return confirmYn;
	}

	public void setConfirmYn(String confirmYn) {
		this.confirmYn = confirmYn;
	}
	
	public String getRegId() {
		return regId;
	}

	public void setRegId(String regId) {
		this.regId = regId;
	}

	public String getRegDt() {
		return regDt;
	}

	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
