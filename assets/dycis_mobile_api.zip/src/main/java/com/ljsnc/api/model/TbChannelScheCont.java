package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.ljsnc.api.reference.ContentsType;

public class TbChannelScheCont implements Serializable{

	private static final long serialVersionUID = 1L;

	private String channel_id;
	private String sche_dt;
	private String sche_start_dt;
	private String cont_start_dt;
	private String cont_end_dt;
	private Integer duration;
	private Integer order_no;
	private ContentsType sche_type;
	private String vod_id;
	private String music_id;
	private String reg_dt;
	private String reg_id;
	private Integer seek_to;
	
	public Integer getSeek_to() {
		return seek_to;
	}
	public void setSeek_to(Integer seek_to) {
		this.seek_to = seek_to;
	}
	public String getChannel_id() {
		return channel_id;
	}
	public void setChannel_id(String channel_id) {
		this.channel_id = channel_id;
	}
	public String getSche_dt() {
		return sche_dt;
	}
	public void setSche_dt(String sche_dt) {
		this.sche_dt = sche_dt;
	}
	public String getSche_start_dt() {
		return sche_start_dt;
	}
	public void setSche_start_dt(String sche_start_dt) {
		this.sche_start_dt = sche_start_dt;
	}
	public String getCont_end_dt() {
		return cont_end_dt;
	}
	public void setCont_end_dt(String cont_end_dt) {
		this.cont_end_dt = cont_end_dt;
	}
	public String getCont_start_dt() {
		return cont_start_dt;
	}
	public void setCont_start_dt(String cont_start_dt) {
		this.cont_start_dt = cont_start_dt;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public Integer getOrder_no() {
		return order_no;
	}
	public void setOrder_no(Integer order_no) {
		this.order_no = order_no;
	}
	public ContentsType getSche_type() {
		return sche_type;
	}
	public void setSche_type(ContentsType sche_type) {
		this.sche_type = sche_type;
	}
	public String getVod_id() {
		return vod_id;
	}
	public void setVod_id(String vod_id) {
		this.vod_id = vod_id;
	}
	public String getMusic_id() {
		return music_id;
	}
	public void setMusic_id(String music_id) {
		this.music_id = music_id;
	}
	public String getReg_dt() {
		return reg_dt;
	}
	public void setReg_dt(String reg_dt) {
		this.reg_dt = reg_dt;
	}
	public String getReg_id() {
		return reg_id;
	}
	public void setReg_id(String reg_id) {
		this.reg_id = reg_id;
	}
	
	@Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this);
    }
	
}
