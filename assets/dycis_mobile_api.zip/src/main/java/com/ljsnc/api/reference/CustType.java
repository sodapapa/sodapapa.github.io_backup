package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum CustType {
	//법인사업자(01), 개인사업자(02), 개인(03)
	CorpBiz("01"),
	IndividualBiz("02"),
	Individual("03")
	;
	
	private final String stringValue;

	private CustType(final String newValue)
	{
	    stringValue = newValue;
	}
	
	@JsonValue
	public String toStr()
	{
	    return stringValue;
	}
	
	private static final Map<String, CustType> lookup = new HashMap<String, CustType>();
	
	static
	{
	    for (CustType rt : CustType.values())
	        lookup.put(rt.stringValue, rt);
	}
	
	public static CustType get(String typeStr)
	{
	    return lookup.get(typeStr);
	}
	
}
