package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum AuthKind {
	USER("USER"),
	URMG("URMG")
	;
	
	private final String stringValue;

	private AuthKind(final String newValue)
	{
	    stringValue = newValue;
	}
	
	@JsonValue
	public String toStr()
	{
	    return stringValue;
	}
	
	private static final Map<String, AuthKind> lookup = new HashMap<String, AuthKind>();
	
	static
	{
	    for (AuthKind rt : AuthKind.values())
	        lookup.put(rt.stringValue, rt);
	}
	
	public static AuthKind get(String typeStr)
	{
	    return lookup.get(typeStr);
	}
	
}
