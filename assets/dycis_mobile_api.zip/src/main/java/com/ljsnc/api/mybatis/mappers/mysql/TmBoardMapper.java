package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ljsnc.api.model.TmBoard;

public interface TmBoardMapper {
	/**
	 *공지사항 조회
	 */
	@Select(""
			+ "	SELECT BOARD_ID, SVC_TYPE, BOARD_TYPE, BOARD_TITLE, BOARD_CONTENTS, CD_JOB, READ_CNT, DEL_YN"
			+ "		, DATE_FORMAT(START_DT,'%Y-%m-%d') DT_START, DATE_FORMAT(END_DT,'%Y-%m-%d') DT_END "
			+ "		, DATE_FORMAT(REG_TMSTMP,'%Y-%m-%d') DT_INSERT, DATE_FORMAT(MOD_TMSTMP,'%Y-%m-%d') DT_UPDATE "
			+ "		, FN_USER_NAME(REG_ID) ID_INSERT, FN_USER_NAME(MOD_ID) ID_UPDATE "
			+ "	FROM tm_board "
			+ "	WHERE DATE_FORMAT(NOW(),'%Y%m%d') BETWEEN DATE_FORMAT(START_DT,'%Y%m%d') AND DATE_FORMAT(END_DT,'%Y%m%d')"
			+ "		AND YN_DEL = 'N'	"
			+ "	ORDER BY REG_TMSTMP DESC "
			+ "	LIMIT #{startIdx}, #{cnt}")
	List<TmBoard> getList(@Param("startIdx")Integer startIdx, @Param("cnt")Integer cnt);
}
