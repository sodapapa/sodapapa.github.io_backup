package com.ljsnc.api.exception;


public enum ManagedExceptionCode
{
	//3000 ~ . 공통
	ServerError(2000, "E2000"),				// 서버 에러
	AuthenticationError(2001, "E2001"),		// 인증에 실패하였습니다
	InvalidParameter(2002, "E2002"),		// 잘못된 파라미터입니다
	LinkError(2003, "E2003"),				// 연동에 실패하였습니다
	NotExistData(2004, "E2004"),			// 데이타가 존재하지않습니다
	AuthTokenExpired(2005, "E2005"),		// 인증이 만료되었습니다.
	EmptyParameter(2006, "E2006"),			// 빈값을 채워 주세요

	IncorrectPassword(3000, "E3000"),		// 잘못된 비밀번호입니다
	InvalidUser(3001, "E3001"),				// 유효하지 않은 계정입니다
	ExistID(3002, "E3002"),					// 이미 가입된 아이디 입니다
	InvalidID(3003, "E3003"),				// 유효하지 않는 아이디 입니다.
	InvalidPassword(3004, "E3004"),			// 유효하지 않는 비밀번호 입니다.
	InvalidPhoneNo(3005, "E3005"),			// 유효하지 않는 전화번호 입니다.
	InvalidEmail(3006, "E3006"),			// 유효하지 않는 이메일 입니다.
	InvalidBirthday(3007, "E3007"),			// 유효하지 않는 생년월일 입니다.
	InvalidDeviceLength(3008, "E3008"),		// 유효하지 않는 디바이스 id 길이 입니다.
	InvalidGender(3009, "E3009"),			// 유효하지 않는 성별 입니다.
	InvalidLogin(3010, "E3010"),			// 로그인에 실패하였습니다.
	InvalidUserType(3011, "E3011"),			// 정회원만 이용하실 수 있습니다.
	InvalidCenterUser(3012, "E3012"),		// 센터에 등록되지 않은 회원 입니다.
	IncorrectOldPassword(3013, "E3013"),	// 기존 비밀번호가 틀렸습니다
	IncorrectMatchNewPassword(3014, "E3014"),// 신규 비밀번호와 비밀번호 확인이 서로 다릅니다
	InvalidDeviceKind(3015, "E3015"),		// 잘못된 디바이스 타입 입니다.
	ExistMappingUser(3016, "E3016"),			// 이미 매핑된 회원입니다
	BarcodeTokenExpired(3017, "E3017"),		// 바코드가 만료되었습니다


	DupliacateUserPhoneNo(4000, "E4000"), 	// 중복되는 휴대폰 정보 여러개 존재합니다.

	FailFCMPush(5000, "E5000"),				// 푸쉬 발송에 실패하였습니다

	FailSendEmail(6000 , "E6000"),				// 이메일 발송에 실패하였습니다

	FailImgUpload(7000 , "E7000"),				// 이미지 업로드에 실패하였습니다.

	NotExistBillboard(8000, "E8000"),			// 존재하지 않는 게시판입니다.
	FailDeleteBillboardInfo(8001, "E8001"),			// 게시물을 삭제할 수 없습니다.
	NoAuthToWrite(8002, "E8002"),			// 글쓰기 권한이 없는 게시판입니다.


	;

	private int code;
	private String noMsg;

    private ManagedExceptionCode(int code, String noMsg)
    {
    	this.code = code;
    	this.noMsg = noMsg;
    }

    public int getCode()
    {
    	return this.code;
    }
    public String getNoMsg()
    {
    	return this.noMsg;
    }
}
