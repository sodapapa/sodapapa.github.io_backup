package com.ljsnc.api.model.response;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class DtoCenterLoginInfo implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private int scId;
	private String authToken;
	
	

	public int getScId() {
		return scId;
	}



	public void setScId(int scId) {
		this.scId = scId;
	}



	public String getAuthToken() {
		return authToken;
	}



	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}



	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
