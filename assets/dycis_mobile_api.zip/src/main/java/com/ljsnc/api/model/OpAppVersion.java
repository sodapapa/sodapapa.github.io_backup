package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.ljsnc.api.reference.DeviceKind;

public class OpAppVersion implements Serializable{
	private static final long serialVersionUID = 1L;
	

	private Integer appVersionId;
	private DeviceKind  deviceType;
	private String  versionNo;
	private String  requiredYn;
	private String  marketUrl;
	private String  createdDate;
	private String  createdUserId;
	

	public Integer getAppVersionId() {
		return appVersionId;
	}


	public void setAppVersionId(Integer appVersionId) {
		this.appVersionId = appVersionId;
	}


	public DeviceKind getDeviceType() {
		return deviceType;
	}


	public void setDeviceType(DeviceKind deviceType) {
		this.deviceType = deviceType;
	}
	
	public String getVersionNo() {
		return versionNo;
	}


	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}


	public String getRequiredYn() {
		return requiredYn;
	}




	public void setRequiredYn(String requiredYn) {
		this.requiredYn = requiredYn;
	}




	public String getMarketUrl() {
		return marketUrl;
	}




	public void setMarketUrl(String marketUrl) {
		this.marketUrl = marketUrl;
	}




	public String getCreatedDate() {
		return createdDate;
	}




	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}




	public String getCreatedUserId() {
		return createdUserId;
	}




	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}




	@Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this);
    }
	
}
