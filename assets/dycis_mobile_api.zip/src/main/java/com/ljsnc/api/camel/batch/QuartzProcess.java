package com.ljsnc.api.camel.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class QuartzProcess {
	private static final Logger logger = LoggerFactory.getLogger(QuartzProcess.class);
	@Autowired QuartzManager quartzManager;
	
	/**
	 * 매시간 실행할 프로세스 처리.
	 */
	public void procSchedulerWeather()
	{
		logger.debug("procSchedulerWeather_Start");
		try {
			this.quartzManager.schedulerWeather();
		}catch(Exception e) {
			logger.error("procSchedulerWeather_Error");
		}
		
		
		logger.debug("procSchedulerWeather_End");
	}
	
	
	/**
	 * 푸쉬(FCM,PUSH) ^^
	 */
//	public void procSchedulerPush()
//	{
//		logger.debug("procSchedulerPush_Start");
//		
////		try{
////			//this.quartzManager.schedulerPush();
////		}catch(Exception e){
////			logger.error("Exception schedulerPush e = ", e);
////		}
//		logger.debug("procSchedulerPush_End");
//	}
	
}
