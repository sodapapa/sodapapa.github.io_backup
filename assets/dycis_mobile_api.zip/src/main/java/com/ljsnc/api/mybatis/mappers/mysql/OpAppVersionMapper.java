package com.ljsnc.api.mybatis.mappers.mysql;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ljsnc.api.model.OpAppVersion;
import com.ljsnc.api.model.TbApp;

public interface OpAppVersionMapper {

	@Select(""
			+ "SELECT APP_VER, API_VER, APP_FLAG, UPDATE_YN, MARKET_URL, USE_YN, KEY_STRING, REG_DT "
			+ " FROM tn_app_config WHERE DEVICE_KIND = #{deviceKind} ORDER BY CREATED_DATE DESC LIMIT 1 ")
	OpAppVersion selectAppVersion(@Param("deviceKind")String deviceKind);

}
