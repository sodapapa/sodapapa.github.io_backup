package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class TbApp implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String pid;
	private String package_nm;
	private String activity_nm;
	private Double version_cd;
	private String app_nm;
	private String app_type;
	private String app_url;
	private String auto_start;
	private String stb_model;
	private String launcher_id;
	private String reg_id;
	private String reg_dt;
	private String mod_id;
	private String mod_dt;
	
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPackage_nm() {
		return package_nm;
	}
	public void setPackage_nm(String package_nm) {
		this.package_nm = package_nm;
	}
	public String getActivity_nm() {
		return activity_nm;
	}
	public void setActivity_nm(String activity_nm) {
		this.activity_nm = activity_nm;
	}
	public Double getVersion_cd() {
		return version_cd;
	}
	public void setVersion_cd(Double version_cd) {
		this.version_cd = version_cd;
	}
	public String getApp_nm() {
		return app_nm;
	}
	public void setApp_nm(String app_nm) {
		this.app_nm = app_nm;
	}
	public String getApp_type() {
		return app_type;
	}
	public void setApp_type(String app_type) {
		this.app_type = app_type;
	}
	public String getApp_url() {
		return app_url;
	}
	public void setApp_url(String app_url) {
		this.app_url = app_url;
	}
	public String getAuto_start() {
		return auto_start;
	}
	public void setAuto_start(String auto_start) {
		this.auto_start = auto_start;
	}
	public String getStb_model() {
		return stb_model;
	}
	public void setStb_model(String stb_model) {
		this.stb_model = stb_model;
	}
	public String getLauncher_id() {
		return launcher_id;
	}
	public void setLauncher_id(String launcher_id) {
		this.launcher_id = launcher_id;
	}
	public String getReg_id() {
		return reg_id;
	}
	public void setReg_id(String reg_id) {
		this.reg_id = reg_id;
	}
	public String getReg_dt() {
		return reg_dt;
	}
	public void setReg_dt(String reg_dt) {
		this.reg_dt = reg_dt;
	}
	public String getMod_id() {
		return mod_id;
	}
	public void setMod_id(String mod_id) {
		this.mod_id = mod_id;
	}
	public String getMod_dt() {
		return mod_dt;
	}
	public void setMod_dt(String mod_dt) {
		this.mod_dt = mod_dt;
	}
	
	@Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this);
    }
}
