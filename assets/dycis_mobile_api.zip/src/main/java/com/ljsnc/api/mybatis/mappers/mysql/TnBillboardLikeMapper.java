package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

import com.ljsnc.api.model.TnBillboard;
import com.ljsnc.api.model.TnBillboardComment;
import com.ljsnc.api.model.TnBillboardInfo;
import com.ljsnc.api.model.TnBillboardLike;

public interface TnBillboardLikeMapper {

	@Select(""
			+ "     "
			+ "   SELECT COUNT(1) FROM tn_billboard_like WHERE bi_id = #{biId} AND user_id = #{userId} "
			+ "     "
			+ "")
	int billboardLikeCnt(TnBillboardLike tnBillboardLike);

	@SelectKey(before = false,  keyProperty = "likeCnt", resultType = int.class, statement = ""
			+ "SELECT COUNT(*) as likeCnt3 From tn_billboard_like where BI_ID = #{biId}" )
	@Insert(""
			+ "  INSERT INTO tn_billboard_like "
			+ "              (BI_ID, "
			+ "               USER_ID, "
			+ "               REG_DT) "
			+ "  VALUES (#{biId}, "
			+ "          		#{userId}, "
			+ "          		now() ) "
			+ "   "
			+ "")
	void insertBillboardLike(TnBillboardLike tnBillboardLike);

	@SelectKey(before = false,  keyProperty = "likeCnt", resultType = int.class, statement = ""
			+ "SELECT COUNT(*) as likeCnt From tn_billboard_like where BI_ID = #{biId}" )
	@Update(""
			+ "  DELETE  "
			+ "  FROM tn_billboard_like  "
			+ "  WHERE BI_ID = #{biId}  "
			+ "      AND USER_ID = #{userId}  "
			+ "    "
			+ "")
	void deleteBillboardLike(TnBillboardLike tnBillboardLike);

}
