package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;

import com.ljsnc.api.model.TnBillboard;
import com.ljsnc.api.model.TnBillboardComment;
import com.ljsnc.api.model.TnBillboardGallery;
import com.ljsnc.api.model.TnBillboardInfo;
import com.ljsnc.api.model.TnBillboardPds;

public interface TnBillboardPdsMapper {

	@Insert(""
			+ " INSERT INTO tn_billboard_pds   "
			+ "             (   "
			+ "              BI_ID,   "
			+ "              FILE_PATH,   "
			+ "              FILE_NAME,   "
			+ "              FILE_FORMAT,   "
			+ "              DELETE_YN,   "
			+ "              REG_TYPE,   "
			+ "              REG_ID,   "
			+ "              REG_DT,   "
			+ "              MOD_TYPE,   "
			+ "              MOD_ID,   "
			+ "              MOD_DT"
			+ ") VALUES  ("
			+ "         #{biId},   "
			+ "         #{filePath},   "
			+ "         #{fileName},   "
			+ "         #{fileFormat},   "
			+ "         #{deleteYn},   "
			+ "         #{regType},   "
			+ "         #{regId},   "
			+ "         #{regDt},   "
			+ "         #{modType},   "
			+ "         #{modId},   "
			+ "         #{modDt}"
			+ "		)   "
			+ "    "
			+ "     "
			+ "     "
			+ "")
	int createBillboardPds(TnBillboardPds tnBillboardPds);







}
