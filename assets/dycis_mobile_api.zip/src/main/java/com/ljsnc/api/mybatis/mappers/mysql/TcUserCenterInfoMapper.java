package com.ljsnc.api.mybatis.mappers.mysql;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ljsnc.api.model.TcUserCenterInfo;
import com.ljsnc.api.model.TnSportsCenter;

public interface TcUserCenterInfoMapper {

	@Select(""
			+ "SELECT * "
			+ "FROM TC_USER_CENTER_INFO	"
			+ "WHERE USER_KEY = #{userKey} ")
	TcUserCenterInfo findUserCenterInfo(@Param("userKey")String userKey);

}
