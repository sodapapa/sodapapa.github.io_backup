package com.ljsnc.api.reference;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum CustGroupState {
	//등록(01), 서비스중(02), 일시정지(03), 해지(04)
	Reg("01"),
	Service("02"),
	Pause("03"),
	Withdraw("04")
	;
	
	private final String stringValue;

	private CustGroupState(final String newValue)
	{
	    stringValue = newValue;
	}
	
	@JsonValue
	public String toStr()
	{
	    return stringValue;
	}
	
	private static final Map<String, CustGroupState> lookup = new HashMap<String, CustGroupState>();
	
	static
	{
	    for (CustGroupState rt : CustGroupState.values())
	        lookup.put(rt.stringValue, rt);
	}
	
	public static CustGroupState get(String typeStr)
	{
	    return lookup.get(typeStr);
	}
}
