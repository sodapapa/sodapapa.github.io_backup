package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class TmConfigApi implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String conf_id;
	private String conf_nm;
	private String conf_val;
	private String id_insert;
	private String dt_insert;
	private String id_update;
	private String dt_update;
	
	public String getConf_id() {
		return conf_id;
	}
	public void setConf_id(String conf_id) {
		this.conf_id = conf_id;
	}
	public String getConf_nm() {
		return conf_nm;
	}
	public void setConf_nm(String conf_nm) {
		this.conf_nm = conf_nm;
	}
	public String getConf_val() {
		return conf_val;
	}
	public void setConf_val(String conf_val) {
		this.conf_val = conf_val;
	}
	public String getId_insert() {
		return id_insert;
	}
	public void setId_insert(String id_insert) {
		this.id_insert = id_insert;
	}
	public String getDt_insert() {
		return dt_insert;
	}
	public void setDt_insert(String dt_insert) {
		this.dt_insert = dt_insert;
	}
	public String getId_update() {
		return id_update;
	}
	public void setId_update(String id_update) {
		this.id_update = id_update;
	}
	public String getDt_update() {
		return dt_update;
	}
	public void setDt_update(String dt_update) {
		this.dt_update = dt_update;
	}
	
	@Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this);
    }
}
