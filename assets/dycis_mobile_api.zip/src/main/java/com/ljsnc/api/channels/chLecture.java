package com.ljsnc.api.channels;

import java.util.Map;

import javax.ws.rs.FormParam;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ljsnc.api.biz.manager.LectureManager;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;

@Path("lt")
@Produces({ MediaType.APPLICATION_JSON })
@Service
@Api(position = 600, value = "Lecture", description = "Lecture API")
public class chLecture {
	@Autowired LectureManager lectureManager;

	@Path("/list")
    @POST
    @ApiOperation(position = 601, value = "601. 수강정보얻기", notes = "601. 수강정보얻기"
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",			[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>			{\"uaId\": \"1\",				[사용자 SEQ 번호]"
    		+ "<br>			\"userId\": \"55\",			[사용자 Id]"
    		+ "<br>			\"transId\": \"1\",			[강습 Id]"
    		+ "<br>			\"atnclNm\": \"수영\",			[사용자 수강명]"
    		+ "<br>			\"atnclPrice;\": \"80000\",	[수강가격]"
    		+ "<br>			\"startDate;  \": \"20191001\",		[수강시작일]"
    		+ "<br>			\"endDate;    \": \"20191130\",		[수강 마지막일]"
    		+ "<br>			\"startTime;  \"1400\",			[수강 시작시간]"
    		+ "<br>			\"endTime;    \": \"1500\",		[수강 마감시간]"
    		+ "<br>		} ,  "
    		+ "<br>			{\"uaId\": \"1\",				[사용자 SEQ 번호]"
    		+ "<br>			\"userId\": \"55\",			[사용자 Id]"
    		+ "<br>			\"transId\": \"1\",			[강습 Id]"
    		+ "<br>			\"atnclNm\": \"수영\",			[사용자 수강명]"
    		+ "<br>			\"atnclPrice;\": \"80000\",	[수강가격]"
    		+ "<br>			\"startDate;  \": \"20191001\",		[수강시작일]"
    		+ "<br>			\"endDate;    \": \"20191130\",		[수강 마지막일]"
    		+ "<br>			\"startTime;  \"1400\",			[수강 시작시간]"
    		+ "<br>			\"endTime;    \": \"1500\",		[수강 마감시간]"
    		+ "<br>		} , {}, {} ...."
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> List(
    		@FormParam("authToken") @ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
    		@FormParam("userId") @ApiParam(value="푸쉬 발송 대상자 앱 회원 ID", required = false) Integer userId
    		)

    {
		return this.lectureManager.getLectureList(userId);
    }

}
