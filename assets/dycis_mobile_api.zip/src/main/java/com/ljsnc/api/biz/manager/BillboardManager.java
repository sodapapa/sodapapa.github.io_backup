package com.ljsnc.api.biz.manager;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.imageio.ImageIO;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.ljsnc.api.biz.util.ApiResponse;
import com.ljsnc.api.exception.ManagedException;
import com.ljsnc.api.exception.ManagedExceptionCode;
import com.ljsnc.api.model.TnBillboard;
import com.ljsnc.api.model.TnBillboardComment;
import com.ljsnc.api.model.TnBillboardGallery;
import com.ljsnc.api.model.TnBillboardInfo;
import com.ljsnc.api.model.TnBillboardLike;
import com.ljsnc.api.model.TnBillboardPds;
import com.ljsnc.api.model.TnSportsCenter;
import com.ljsnc.api.model.TnUser;
import com.ljsnc.api.model.TnUserAtnlc;
import com.ljsnc.api.model.TnUserTokenInfo;
import com.ljsnc.api.model.response.DtoQnaView;
import com.ljsnc.api.mybatis.mappers.mysql.TnBillboardGalleryMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnBillboardInfoMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnBillboardLikeMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnBillboardMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnBillboardPdsMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnBillboardReadMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnSportsCenterMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserAtnlcMapper;
import com.ljsnc.api.mybatis.mappers.mysql.TnUserTokenInfoMapper;
import com.ljsnc.api.reference.AuthKind;
import com.ljsnc.api.util.CommonConstants;
import com.ljsnc.api.util.FileUploadUtil;import scala.tools.nsc.typechecker.PatternMatching.CommonSubconditionElimination;
import scala.tools.scalap.scalax.util.StringUtil;

@Service
public class BillboardManager {
	private static final Logger logger = LoggerFactory.getLogger(BillboardManager.class);

	@Autowired
	@Value("${upload.root.url}")
	String uploadRootUrl;

	@Autowired
	@Value("${upload.base.url}")
	String uploadBaseUrl;

	@Autowired
	@Value("${dycis.api.host.dev}")
	String dycisApiHostDev;

	@Autowired TnBillboardInfoMapper tnBillboardInfoMapper;
	@Autowired TnBillboardGalleryMapper tnBillboardGalleryMapper;
	@Autowired TnBillboardPdsMapper tnBillboardPdsMapper;
	@Autowired TnBillboardMapper tnBillboardMapper;
	@Autowired TnBillboardReadMapper tnBillboardReadMapper;
	@Autowired TnBillboardLikeMapper tnBillboardLikeMapper;
	@Autowired TnUserTokenInfoMapper tnUserTokenInfoMapper;

	/*
	 * 19.10.21. 게시판 정보
	 * @	billboardId	게시판 고유 아이디
	*/
	public Map<String, Object> getBillboardInfo(Integer billboardId, Integer userId) {

		TnBillboard tnBillboard = new TnBillboard();
		logger.debug(" billboardId :  {}, userId : {} " , billboardId , userId);

		tnBillboard = tnBillboardMapper.getBillboardInfo(billboardId , userId);

		if(tnBillboard == null)
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse(tnBillboard);
	}

	/*
	 * 19.10.21. 게시물 목록
	 * @	userId		사용자ID
	 * @	billboardId	게시판ID
	 * @	pageNo		페이지번호
	 * @	pageSize	호출할게시물수
	 * @	lastId		마지막게시물번호
	 */
	public Map<String, Object> getBillboardList(Integer billboardId, Integer pageNo, Integer pageSize, Integer lastId, Integer userId) {
		logger.debug("Check Param ::: billboardId : {} , pageNo : {} , pageSize : {}, lastId : {},  userId : {}  " ,  billboardId,  pageNo,  pageSize,  lastId,  userId);
		List<TnBillboardInfo> billboardList =new ArrayList<TnBillboardInfo>();

		if(billboardId == 12 ) { // 1대1 문의

			billboardList = tnBillboardInfoMapper.get11InquiryList(billboardId, pageNo, pageSize, lastId, userId);
		}else {

			billboardList = tnBillboardInfoMapper.getBillboardList(billboardId, pageNo, pageSize, lastId, userId);

			for (TnBillboardInfo tnBillboardInfo : billboardList) {

				if(tnBillboardInfo.getGalleryImg() != null )
					tnBillboardInfo.setGalleryImg(dycisApiHostDev +tnBillboardInfo.getGalleryImg());
			}
		}

		if(billboardList  == null)
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse(billboardList);
	}


	/*
	 * 19.10.21. 게시물 상세보기
	 *
	 * @	userId	사용자 아이디
	 * @	biId		게시물 아이디
	 * @	pwdValue	게시물 비밀번호
	 *
	 */
	public Map<String, Object> getBillboardView(Integer userId, Integer biId, String pwdValue) {
		logger.debug("Check Param ::: userId : {} , biId : {} , pwdValue : {}" ,  userId,  biId,  pwdValue);

		TnBillboardInfo billboardView= tnBillboardInfoMapper.getBillboardView(userId, biId, pwdValue);

		if(billboardView == null )
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		if(billboardView.getGalleryImg() != null )
			billboardView.setGalleryImg(dycisApiHostDev +billboardView.getGalleryImg());

		if(billboardView.getPdsUrl() != null )
			billboardView.setPdsUrl(dycisApiHostDev +billboardView.getPdsUrl());

		HashMap<String, Object> param = new HashMap<String,Object>();
		param.put("userId", userId);
		param.put("biId", biId);

		 tnBillboardReadMapper.insertUserRead(param);

		logger.debug("readCnt :{} ", param.toString() );
		logger.debug("billboardView.getpBiId()  :{} ", billboardView.getpBiId() );

		tnBillboardInfoMapper.setReadCnt(param);

		if(billboardView.getrBiId() > 0) {

			DtoQnaView dtoQnaView= tnBillboardInfoMapper.qnaView(userId, biId, billboardView.getpBiId() , pwdValue);

			return ApiResponse.makeResponse(dtoQnaView);
		}else {

			return ApiResponse.makeResponse(billboardView);
		}

	}




	public Map<String, Object> billboardLike(Integer userId, Integer biId) {
		logger.debug("Check Param ::: userId : {} , biId : {} " ,  userId,  biId);

		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, Object> paramMap = new HashMap<String, Object>();
		TnBillboardLike tnBillboardLike = new TnBillboardLike();

		tnBillboardLike.setBiId(biId);
		tnBillboardLike.setUserId(userId);

		int likeCnt =  tnBillboardLikeMapper.billboardLikeCnt(tnBillboardLike);

		if(likeCnt <= 0 ) { // 좋아요 처리
			tnBillboardLikeMapper.insertBillboardLike(tnBillboardLike);
			resultMap.put("likeYn", "Y");

		}else { // 좋아요 해제 처리

			tnBillboardLikeMapper.deleteBillboardLike(tnBillboardLike);
			resultMap.put("likeYn", "N");
		}

		int lastLikeCnt = tnBillboardLike.getLikeCnt();
		logger.debug("lastLikeCnt : {} " , lastLikeCnt);

		paramMap.put("likeCnt", lastLikeCnt);
		paramMap.put("biId", biId);
		tnBillboardInfoMapper.setLikeCnt(paramMap);

		return ApiResponse.makeResponse(resultMap);
	}

	public Map<String, Object> bestList(Integer userId, Integer pageNo, int pageSize) {

		List<TnBillboardInfo> bestList = new ArrayList<TnBillboardInfo>();

		int billboardId = CommonConstants.FREE_BILLBOARD_ID;

		bestList  = tnBillboardInfoMapper.getBestList(userId,pageNo,pageSize, billboardId);

		if (bestList == null)
			throw new ManagedException(ManagedExceptionCode.NotExistData, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse(bestList);
	}


	@Transactional
	public Map<String, Object> setBilboardWrite(String userId, int billboardId, int biId, String biTitle, String biContents,
																			int pBiId, int rBiId, String pwdValue, String biDepth, int scId,
																			String galleryYn, Attachment galleryData, String galleryNm) {

		TnBillboardInfo tnBillboardInfo =new TnBillboardInfo();

			tnBillboardInfo.setBiId(biId);
			tnBillboardInfo.setBillboardId(billboardId);
			tnBillboardInfo.setScId(scId);
			tnBillboardInfo.setBiTitle(biTitle);
			tnBillboardInfo.setBiContents(biContents);
			tnBillboardInfo.setpBiId(pBiId);
			tnBillboardInfo.setrBiId(rBiId);
			tnBillboardInfo.setPwdValue(pwdValue);
			tnBillboardInfo.setModId(userId);
			tnBillboardInfo.setRegId(userId);
			tnBillboardInfo.setRegType("U");
			tnBillboardInfo.setModType("U");
			tnBillboardInfo.setBiDepth(biDepth);
			tnBillboardInfo.setDeleteYn("N");
			tnBillboardInfo.setNoticeYn("N");

			if(biId <= 0) {  // 신규 글 작성

				tnBillboardInfoMapper.createBillboardInfo(tnBillboardInfo);

				biId = tnBillboardInfo.getBiId();
				pBiId = pBiId == 0 ? biId : pBiId;

				if(rBiId <= 0 )
					rBiId = biId== pBiId ? 0 : pBiId;

				biDepth = rBiId == 0 ? "0" : "1";

				int biOrder = biId== pBiId ? 1 : tnBillboardInfoMapper.getMaxBiOrder(pBiId);

 				tnBillboardInfoMapper.updatePBiId(biId ,pBiId, rBiId, biOrder, biDepth); // 작성한 글 pBiId, biOrder 업데이트

			}else { // 글 업데이트

				tnBillboardInfoMapper.updateBillboardInfo(tnBillboardInfo);
				biId = tnBillboardInfo.getBiId();
			}

			logger.debug("biId ::: " + biId);
			try {
				// 이미지 업로드 확인
				if( galleryYn.equals("Y") && galleryData != null) {
					int bgId = this.imageUpload(galleryData, biId,userId);

					if(bgId <= 0)
						throw new ManagedException(ManagedExceptionCode.FailImgUpload, CommonConstants.DEFAULT_FG_LANG);

				}

			HashMap<String, Object> resultMap = new HashMap<String, Object>();
			resultMap.put("biId", biId);

			return ApiResponse.makeResponse(resultMap);

		} catch (ManagedException e1) {
			e1.printStackTrace();
			throw new ManagedException(e1.getExceptionCode(), CommonConstants.DEFAULT_FG_LANG);

		}catch (Exception e2) {
			e2.printStackTrace();
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}
	}


	public Map<String, Object> billboardDelete(Integer userId, Integer biId) {

		int result = tnBillboardInfoMapper.billboardDelete(biId, userId);

		if(result <= 0)
			throw new ManagedException(ManagedExceptionCode.FailDeleteBillboardInfo, CommonConstants.DEFAULT_FG_LANG);

		return ApiResponse.makeResponse();
	}


	private int imageUpload(Attachment attGalleryData, int biId, String userId) {
		TnBillboardGallery tnBillboardGallery = new TnBillboardGallery();
		try {

			Calendar cal = Calendar.getInstance();
			SimpleDateFormat fdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String strCal = fdf.format(cal.getTime());

			BufferedImage bufImg0 = null;
			InputStream is = attGalleryData.getDataHandler().getInputStream();

			bufImg0 = ImageIO.read(is);

			String savePath = CommonConstants.IMG_UPLOAD_PATH + "/" + biId   + "/" ;
			String savePathDbParam = CommonConstants.IMG_UPLOAD_PATH_DB_PARAM + "/" + biId   + "/"  ;
			String fileName = biId + "_" + strCal + ".jpg" ; // +extsion;
			String fullSavePath = savePath + "/"+fileName;

			File file = new File(fullSavePath);
			if(!file.exists()){
	            file.mkdirs();
	        }

			ImageIO.write(bufImg0, "jpg", file);

			tnBillboardGallery.setBiId(biId);
			tnBillboardGallery.setDeleteYn("N");
			tnBillboardGallery.setFileFormat("jpg");
			tnBillboardGallery.setFileName(fileName);
			tnBillboardGallery.setFilePath(savePathDbParam + fileName);
			tnBillboardGallery.setRegId(userId);
			tnBillboardGallery.setModId(userId);
			tnBillboardGallery.setRegType("U");
			tnBillboardGallery.setModType("U");

		} catch (Exception e) {
			e.printStackTrace();
			throw new ManagedException(ManagedExceptionCode.ServerError, CommonConstants.DEFAULT_FG_LANG);
		}

		// 현재는 1대1 구조로 앞서서 있던 겔러리를 모두 삭제
		tnBillboardGalleryMapper.deleteBillboardGallery(tnBillboardGallery);

		tnBillboardGalleryMapper.createBillboardGallery(tnBillboardGallery);

		logger.debug( "gallery Id : {}  " , Integer.toString(tnBillboardGallery.getBgId()) );

		return tnBillboardGallery.getBgId();
	}
}
