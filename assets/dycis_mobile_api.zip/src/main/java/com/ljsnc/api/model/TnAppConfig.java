package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TnAppConfig implements Serializable {
	private static final long serialVersionUID = 1L;
	private String deviceKind;
	private int appVer;
	private int apiVer;
	private String appFlag;
	private String updateYn;
	private String useYn;
	private String marketUrl;
	private String keyString;
	private String regDt;
	public String getDeviceKind() {
		return deviceKind;
	}
	public void setDeviceKind(String deviceKind) {
		this.deviceKind = deviceKind;
	}
	public int getAppVer() {
		return appVer;
	}
	public void setAppVer(int appVer) {
		this.appVer = appVer;
	}
	public int getApiVer() {
		return apiVer;
	}
	public void setApiVer(int apiVer) {
		this.apiVer = apiVer;
	}
	public String getAppFlag() {
		return appFlag;
	}
	public void setAppFlag(String appFlag) {
		this.appFlag = appFlag;
	}
	public String getUpdateYn() {
		return updateYn;
	}
	public void setUpdateYn(String updateYn) {
		this.updateYn = updateYn;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getMarketUrl() {
		return marketUrl;
	}
	public void setMarketUrl(String marketUrl) {
		this.marketUrl = marketUrl;
	}
	public String getKeyString() {
		return keyString;
	}
	public void setKeyString(String keyString) {
		this.keyString = keyString;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
