package com.ljsnc.api.channels;

import java.util.Map;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ljsnc.api.biz.manager.SystemManager;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;

@Path("ct")
@Produces({ MediaType.APPLICATION_JSON })
@Service
@Api(position = 300, value = "CENTER", description = "CENTER API")
public class chSystem {
	@Autowired SystemManager systemManager;

	@Path("/login")
    @POST
    @ApiOperation(position = 301, value = "301. 센터 로그인 처리", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000, 					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\", 				[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>		\"scId\": 1990000001, 			[로그인한 center 회원 고유 key 값]"
    		+ "<br>		\"authToken\": \"F0QMIeF6DTHy\" 		[로그인한 center 계정 인증 토큰(고정값)(유효기간 1년)]"
    		+ "<br>	},"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> login(
			@FormParam("scLoginId")  @ApiParam(value="아이디", required = true)  String scLoginId,
			@FormParam("scPw")  @ApiParam(value="비밀번호", required = true)  String scPw)
    {
		return this.systemManager.centerLogin(scLoginId, scPw);
    }


	@Path("/user")
    @POST
    @ApiOperation(position = 302, value = "302. 회원정보 목록 조회", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>	\"data\": ["
    		+ "<br>		{"
    		+ "<br>			\"userId\": 1,			[fitmoa App 회원 고유 key 값]"
    		+ "<br>			\"userLoginId\": \"fitmoa\",	[fitmoa App 회원 로그인 아이디]"
    		+ "<br>			\"phoneNo\": \"01067784882\",	[fitmoa App 회원 연락처]"
    		+ "<br>			\"userNm\": \"김영철\",		[fitmoa App 회원 이름]"
    		+ "<br>			\"userBirthday\": \"19880526\",	[fitmoa App 회원 생년월일]"
    		+ "<br>			\"userType\": \"01\",		[fitmoa App 회원 타입 (01: 정회원(매핑된 회원), 02: 준회원(매핑 안된 회원)]"
    		+ "<br>			\"mappingYn\": \"Y\",		[fitmoa App 회원과 센터 회원 사이에 매핑이 되었는지 여부]"
    		+ "<br>		},"
    		+ "<br>		{"
    		+ "<br>			\"userId\": 2,			"
    		+ "<br>			\"userLoginId\": \"fitmoatest\",	"
    		+ "<br>			\"phoneNo\": \"01067879882\",	"
    		+ "<br>			\"userNm\": \"김영순\",		"
    		+ "<br>			\"userBirthday\": \"19860526\",	"
    		+ "<br>			\"userType\": \"02\",	"
    		+ "<br>			\"mappingYn\": \"N\","
    		+ "<br>		},"
    		+ "<br>		{"
    		+ "<br>			\"userId\": 3,			"
    		+ "<br>				."
    		+ "<br>				."
    		+ "<br>		},"
    		+ "<br>				."
    		+ "<br>				."
    		+ "<br>				."
    		+ "<br>	],"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> userList(
    		@FormParam("authToken") @ApiParam(value="인증 여부를 확인하는 랜덤 토큰 값", required = true) String authToken,
    		@FormParam("scId") @ApiParam(value="센터회원 로그인 회원 key", required = true) int scId,
    		@FormParam("userLoginId") @ApiParam(value="회원 아이디", required = false) String userLoginId,
    		@FormParam("userNm") @ApiParam(value="회원 이름", required = false) String userNm,
    		@FormParam("phoneNo") @ApiParam(value="회원 연락처. ex) 01012345678", required = false) String phoneNo,
    		@FormParam("userBirthDay") @ApiParam(value="회원 생년월일.  20100101", required = false) String userBirthday )
    {
		return this.systemManager.findUserList(userLoginId, userNm, phoneNo, userBirthday);
    }

	@Path("/user/info")
    @POST
    @ApiOperation(position = 303, value = "303. 회원정보 상세조회", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>	\"data\": {"
    		+ "<br>		\"userId\": 1,				[fitmoa App 회원 고유 key 값]"
    		+ "<br>		\"userLoginId\": \"fitmoa\",		[fitmoa App 회원 로그인 아이디]"
    		+ "<br>		\"phoneNo\": \"01067784882\",		[fitmoa App 회원 연락처]"
    		+ "<br>		\"userNm\": \"김영철\",			[fitmoa App 회원 이름]"
    		+ "<br>		\"userEmail\": \"fitmoa@dycis.co.kr\",	[fitmoa App 회원 이메일]"
    		+ "<br>		\"userBirthday\": \"19880526\",		[fitmoa App 회원 생년월일]"
    		+ "<br>		\"userGender\": \"01\",			[fitmoa App 회원 성별 (01: 남자, 02: 여자)]"
    		+ "<br>		\"userAddr\": \"서울특별시 강남구 ....\",	[fitmoa App 회원 주소]"
    		+ "<br>		\"userAddrDetail\": \"송담길 20 1506호\",	[fitmoa App 회원 주소 상세]"
    		+ "<br>		\"userType\": \"01\",			[fitmoa App 회원 타입 (01: 정회원(매핑된 회원), 02: 준회원(매핑 안된 회원)]"
    		+ "<br>	}"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> userInfo(
    		@FormParam("authToken") @ApiParam(value="인증 여부를 확인하는 랜덤 토큰 값", required = true) String authToken,
    		@FormParam("scId") @ApiParam(value="센터회원 로그인 회원 key", required = true) int scId,
    		@FormParam("userId") @ApiParam(value="회원 key (조회할 회원 키값)", required = true) int userId )
    {
		return this.systemManager.findUserInfo(userId);
    }

	@Path("/user/mapping")
    @POST
    @ApiOperation(position = 304, value = "304. 회원정보 매핑처리", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> userMapping(
    		@FormParam("authToken") @ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
    		@FormParam("scId") @ApiParam(value="센터회원 로그인 회원 key", required = true) int scId,
    		@FormParam("userId") @ApiParam(value="회원 key", required = true) int userId,
    		@FormParam("userKey") @ApiParam(value="TC_USER_INFO 회원키.", required = true) String userKey )
    {
		return this.systemManager.userMapping(userId, userKey);
    }

	@Path("/barcode/expiry")
    @POST
    @ApiOperation(position = 305, value = "305. 바코드 유효성 체크", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> barcodeExpiry(
    		@FormParam("authToken") @ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
    		@FormParam("scId") @ApiParam(value="센터회원 로그인 회원 key", required = true) int scId,
    		@FormParam("barcord") @ApiParam(value="바코드", required = true) String barcord )
    {
		return this.systemManager.expiryBarcode(barcord);
    }

	@Path("/push/send")
    @POST
    @ApiOperation(position = 306, value = "306. 푸쉬발송", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> pushSend(
    		@FormParam("authToken") @ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
    		@FormParam("scId") @ApiParam(value="센터회원 로그인 회원 key", required = true) int scId,
    		@FormParam("userId") @ApiParam(value="푸쉬 발송 대상자 앱 회원 ID", required = false) Integer userId,
    		@FormParam("phoneNo") @ApiParam(value="푸쉬 발송 대상자 앱 회원 연락처", required = false) String phoneNo,
    		@FormParam("title") @ApiParam(value="푸쉬 발송시 제목", required = true) String title,
    		@FormParam("contents") @ApiParam(value="푸쉬  발송시 내용", required = true) String contents )
    {
		return this.systemManager.pushSend(userId, phoneNo, title, contents);
    }

	@Path("/push/send2")
    @POST
    @ApiOperation(position = 307, value = "307. 푸쉬발송2", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> pushSend2(
    		@FormParam("authToken") @ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
    		@FormParam("scId") @ApiParam(value="센터회원 로그인 회원 key", required = true) int scId,
    		@FormParam("userId") @ApiParam(value="푸쉬 발송 대상자 앱 회원 ID", required = false) Integer userId,
    		@FormParam("phoneNo") @ApiParam(value="푸쉬 발송 대상자 앱 회원 연락처", required = false) String phoneNo,
    		@FormParam("title") @ApiParam(value="푸쉬 발송시 제목", required = true) String title,
    		@FormParam("contents") @ApiParam(value="푸쉬  발송시 내용", required = true) String contents )
    {
		return this.systemManager.pushSend2(userId, phoneNo, title, contents);
    }


	@Path("/user/member")
    @POST
    @ApiOperation(position = 308, value = "308. 회원정보맵핑", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000, 					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\", 					[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> userMember(
    		@FormParam("authToken")	@ApiParam(value="인증여부 랜덤토큰 값", required = true) String authToken,
    		@FormParam("scId") 			@ApiParam(value="센터회원 Id",		 required = true) int scId,
    		@FormParam("userId") 		@ApiParam(value="회원고db Id",		 required = false) Integer userId,
    		@FormParam("memberNo") @ApiParam(value="고유회원번호", 	 required = false) String memberNo )
    {
		return this.systemManager.userMember( scId, userId, memberNo);
    }

	@Path("/user/atnlc")
    @POST
    @ApiOperation(position = 309, value = "309. 수강정보맵핑", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>}"
    		+ "</pre>")
    public Map<String, Object> userAtnlc(
    		@FormParam("authToken") 	@ApiParam(value="인증여부 랜덤토큰 값", 		required = true) String authToken,
    		@FormParam("scId") 			@ApiParam(value="센터회원 Id", 					required = true) Integer scId,
    		@FormParam("userId") 		@ApiParam(value="회원 고유 Id", 				required = true) Integer userId,
    		@FormParam("atnlcNm") 		@ApiParam(value="수강명", 						required = true) String atnlcNm,
    		@FormParam("atnlcPrice")	@ApiParam(value="수강가격", 						required = true) String atnlcPrice,
    		@FormParam("startDate")	@ApiParam(value="수강시작일자 YYYYMMDD", 	required = true) String startDate,
    		@FormParam("endDate")		@ApiParam(value="수강종료일자 YYYYMMDD", 	required = true) String endDate,
    		@FormParam("startTime")	@ApiParam(value="수강시작시간 hhmm", 		required = true) String startTime,
    		@FormParam("endTime") 		@ApiParam(value="수강종료시간 hhmm", 		required = true) String endTime)
    {
		return this.systemManager.userAtnlc( scId, userId, atnlcNm, atnlcPrice, startDate, endDate, startTime, endTime);
    }



	@Path("/user/locker")
    @POST
    @ApiOperation(position = 310, value = "310. 락커정보맵핑", notes = ""
    		+ "<br><br><b>Response Sample</b>"
    		+ "<pre>"
    		+ "<br>{"
    		+ "<br>	\"code\": 1000,					[코드]"
    		+ "<br>	\"msg\": \"SUCCESS\",				[성공, 실패 메시지]"
    		+ "<br>} "
    		+ "</pre>")
    public Map<String, Object> userLocker(
    		@FormParam("authToken") 	@ApiParam(value="인증여부 랜덤토큰 값", 		required = true) String authToken,
    		@FormParam("scId") 			@ApiParam(value="센터 Id", 					required = true) Integer scId,
    		@FormParam("lockerNo") 	@ApiParam(value="락커 번호", 					required = true) String lockerNo,
    		@FormParam("userId") 		@ApiParam(value="회원 고유 Id", 				required = true) Integer userId,
    		@FormParam("startDate")	@ApiParam(value="수강시작일자 YYYYMMDD", 	required = true) String startDate,
    		@FormParam("endDate")		@ApiParam(value="수강종료일자 YYYYMMDD", 	required = true) String endDate,
    		@FormParam("startTime")	@ApiParam(value="수강시작시간 hhmm", 		required = true) String startTime,
    		@FormParam("endTime") 		@ApiParam(value="수강종료시간 hhmm", 		required = true) String endTime)
    {
		return this.systemManager.userLocker(scId, userId, lockerNo,  startDate, endDate, startTime, endTime);
    }
}
