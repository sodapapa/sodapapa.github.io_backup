package com.ljsnc.api.channels;

import java.util.Map;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ljsnc.api.biz.manager.UserManager;

@Path("usr")
@Produces({ MediaType.APPLICATION_JSON })
@Service
public class chUser {
	@Autowired UserManager userManager;
	
	
	@Path("/findId")
    @POST
    public Map<String, Object> findId(
			@FormParam("token") String token) throws Exception
    {
		return userManager.findIdByMailToken(token);
    }
	
	@Path("/resetPw")
    @POST
    public Map<String, Object> resetPw(
			@FormParam("token") String token,
			@FormParam("userLoginId") String userLoginId,
			@FormParam("userNm") String userNm,
			@FormParam("birth") String birth,
			@FormParam("phoneNum") String phoneNum,
			@FormParam("gender") String gender,
			@FormParam("newPw") String newPw) throws Exception
    {
		return userManager.resetPwByMailToken(token, userLoginId, userNm, newPw);
    }
}
