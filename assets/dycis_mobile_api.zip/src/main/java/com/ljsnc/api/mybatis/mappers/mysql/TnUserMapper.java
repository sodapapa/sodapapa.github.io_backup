package com.ljsnc.api.mybatis.mappers.mysql;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

import com.ljsnc.api.model.TnConnLog;
import com.ljsnc.api.model.TnUser;

public interface TnUserMapper {
	@Select(""
			+ "SELECT  USER_ID, USER_NM, USER_GENDER, USER_TYPE "
			+ " FROM tn_user WHERE USER_LOGIN_ID = #{userLoginId} AND USER_PW = #{userPw} ")
	TnUser loginCheck(@Param("userLoginId")String userLoginId, @Param("userPw")String userPw);

	@Select(""
			+ "SELECT  COUNT(*) "
			+ " FROM tn_user WHERE USER_ID = #{userId} AND USER_PW = #{oldPw} ")
	int loginCheckByUserId(@Param("userId")int userId, @Param("oldPw")String oldPw);

	@Update(""
			+ "UPDATE tn_user "
			+ "SET "
			+ "		DEVICE_ID = #{deviceId}	"
			+ "		, DEVICE_KIND = #{deviceKind} "
			+ "		, PUSH_KEY = #{pushKey}	"
			+ "		, LAST_CONN_DT = #{lastConnDt}	"
			+ "WHERE USER_ID = #{userId} ")
	int updateUserConn(@Param("userId") int userId, @Param("deviceId") String deviceId, @Param("deviceKind") String deviceKind, @Param("pushKey")String pushKey, @Param("lastConnDt")String lastConnDt );

	@Insert(""
			+ "INSERT INTO tn_conn_log(USER_LOGIN_ID, DEVICE_KIND, CONN_DT)	"
			+ "VALUES(#{userLoginId}, #{deviceKind}, now() ) ")
	int createLoginSuccessLog(TnConnLog tnConnLog);



	@Select(""
			+ "SELECT  COUNT(*) "
			+ " FROM tn_user WHERE USER_LOGIN_ID = #{userLoginId}")
	int isLoginId(@Param("userLoginId")String userLoginId);

	@Select(""
			+ "SELECT  COUNT(*) "
			+ " FROM tn_user WHERE USER_ID = #{userId}")
	int findUser(@Param("userId")int userId);

	@Select("<script>"
			+ "SELECT A.USER_ID, A.USER_LOGIN_ID, A.USER_NM, A.USER_TYPE, A.PHONE_NO, A.USER_BIRTHDAY "
			+ "			,IF(ISNULL(B.USER_KEY), 'N', 'Y') AS MAPPING_YN "
			+ "FROM tn_user A LEFT OUTER JOIN tn_user_mapping B "
			+ "ON A.USER_ID = B.USER_ID	"
			+ "<where>"
			+ "		<if test=\"userLoginId != null and userLoginId != ''\">"
			+ "			A.USER_LOGIN_ID LIKE CONCAT('%',#{userLoginId},'%')	"
			+ "		</if>"
			+ "		<if test=\"userNm != null and userNm != ''\">"
			+ "			AND A.USER_NM LIKE CONCAT('%',#{userNm},'%') "
			+ "		</if>"
			+ "		<if test=\"phoneNo != null and phoneNo != ''\">"
			+ "			AND A.PHONE_NO LIKE CONCAT('%',#{phoneNo},'%') "
			+ "		</if>"
			+ "		<if test=\"userBirthday != null and userBirthday != ''\">"
			+ "			AND A.USER_BIRTHDAY LIKE CONCAT('%',#{userBirthday},'%') "
			+ "		</if>"
			+ "</where>"
			+ "</script>")
	List<TnUser> findUserList(TnUser tnUser);

	@Select("<script>"
			+ "SELECT "
			+ "			*"
			+ "FROM "
			+ "			tn_user "
			+ "WHERE	"
			+ "			USER_LOGIN_ID LIKE CONCAT('%',#{userLoginId},'%')	"
			+ "			AND USER_NM LIKE CONCAT('%',#{userNm},'%') "
			+ "</script>")
	TnUser findUserForRsPw(TnUser tnUser);


	@Select(""
			+ "SELECT USER_ID, USER_LOGIN_ID, USER_BIRTHDAY, USER_NM"
			+ "		, USER_EMAIL, PHONE_NO, USER_GENDER, USER_POST, USER_ADDR"
			+ "		, USER_ADDR_DETAIL, USER_TYPE	"
			+ "FROM "
			+ "		tn_user	"
			+ "WHERE "
			+ "		USER_ID = #{userId}")
	TnUser findUserInfo(@Param("userId")int userId);

	@Select(""
			+ "SELECT USER_ID, PUSH_KEY, DEVICE_KIND 	"
			+ "FROM "
			+ "		tn_user	"
			+ "WHERE "
			+ "		USER_ID = #{userId}"
			+ "		OR PHONE_NO = #{phoneNo} ")
	List<TnUser> findUserPushKey(@Param("userId")Integer userId, @Param("phoneNo")String phoneNo);

	@SelectKey(before = false, keyProperty="userId", resultType = int.class, statement=""
			+ "SELECT LAST_INSERT_ID() ")
	@Insert(""
			+ "INSERT INTO tn_user(USER_LOGIN_ID, USER_PW, PHONE_NO, USER_NM, USER_EMAIL"
			+ "					, USER_BIRTHDAY, USER_GENDER, USER_ADDR, USER_ADDR_DETAIL"
			+ "					, USER_TYPE, DEVICE_ID, DEVICE_KIND, PUSH_KEY, REG_DT) "
			+ "VALUES (#{userLoginId}, #{userPw}, #{phoneNo}, #{userNm}, #{userEmail}"
			+ "			, #{userBirthday}, #{userGender}, #{userAddr}, #{userAddrDetail}, #{userType}"
			+ "			, #{deviceId}, #{deviceKind}, #{pushKey}, now())")
	int registUser(TnUser tnUser);

	@Update(""
			+ "UPDATE "
			+ "		tn_user "
			+ "SET "
			+ "		PHONE_NO = #{phoneNo}, USER_NM = #{userNm}, USER_EMAIL = #{userEmail}"
			+ "		, USER_BIRTHDAY = #{userBirthday}, USER_GENDER = #{userGender}"
			+ "		, USER_POST = #{userPost}, USER_ADDR = #{userAddr}"
			+ "		, USER_ADDR_DETAIL = #{userAddrDetail}, MOD_DT = now() "
			+ "WHERE USER_ID = #{userId}")
	int modUser(TnUser tnUser);

	@Update(""
			+ "UPDATE "
			+ "		tn_user "
			+ "SET "
			+ "		USER_PW = #{newPw}, MOD_DT = now() "
			+ "WHERE USER_ID = #{userId}")
	int modUserPassword(@Param("userId")int userId, @Param("newPw")String newPw);

	@Update(""
			+ "UPDATE "
			+ "		tn_user "
			+ "SET "
			+ "		USER_TYPE = #{userType}, MOD_DT = now() "
			+ "WHERE USER_ID = #{userId}")
	int updateUserType(@Param("userId")int userId, @Param("userType")String userType);


	@Select(""
			+ "SELECT	"
			+ "		USER_LOGIN_ID	"
			+ "FROM"
			+ "		tn_user	"
			+ "WHERE	"
			+ "		USER_EMAIL = #{userMail}"
			+ "")
	List<String> findUserLoginIdListByMail(@Param("userMail")String userMail);

	@Update(""
			+ "  UPDATE    "
			+ "    tn_user    "
			+ "  SET   "
			+ "    USER_LOGIN_ID = #{ userLoginId},   "
			+ "    USER_PW = #{userPw},   "
			+ "    WITHDRAW_YN = #{withdrawYn},   "
			+ "    WITHDRAW_DT = now()    "
			+ "  "
			+ "   WHERE user_id = #{userId}   "
			+ "     "
			+ "     "
			+ "     "
			+ "")
	int withdrawUser(TnUser tnUserWithdraw);
}
