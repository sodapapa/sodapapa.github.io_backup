package com.ljsnc.api.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.ljsnc.api.model.TmMsg;
import com.ljsnc.api.mybatis.mappers.mysql.TmMsgMapper;
import com.ljsnc.api.reference.FgLang;
import com.ljsnc.api.util.CacheName;
import com.ljsnc.api.util.CommonConstants;


/**
 * Message 관련 공통
 */
@Service
public class MessageManager
{
	private static final Logger logger = LoggerFactory.getLogger(MessageManager.class);

	@Autowired TmMsgMapper messageMapper;

	/**
	 * 17.03.03 Create. 에러 메시지 조회
	 */
	@Cacheable(value = CacheName.MESSAGE, unless = "#result == null")
	public String getErrMsg(String noMsg, FgLang fgLang){
		logger.debug("{}, {}", noMsg, fgLang);

		if (fgLang == null)
			fgLang = CommonConstants.DEFAULT_FG_LANG;

		TmMsg msg = messageMapper.selectMsg("API", "MSG", noMsg, fgLang);

		logger.debug("{}, {}, {}", noMsg, fgLang, msg.getMsgNm());

		if (msg == null)
			return "";
		else
			return msg.getMsgNm();
	}
}