package com.ljsnc.api.mybatis.mappers.mysql;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ljsnc.api.model.TnAppConfig;

public interface TnAppConfigMapper {
	@Select(""
			+ "SELECT APP_VER, API_VER, UPDATE_YN, MARKET_URL, KEY_STRING "
			+ " FROM tn_app_config WHERE DEVICE_KIND = #{deviceKind} AND USE_YN = 'Y' ORDER BY REG_DT, APP_VER DESC LIMIT 1 ")
	TnAppConfig selectAppVersion(@Param("deviceKind")String deviceKind);
	
	@Select("<script>"
			+ "SELECT "
			+ "		COUNT(*)	"
			+ "FROM "
			+ "		tn_app_config "
			+ "WHERE "
			+ "		DEVICE_KIND = #{deviceKind}  "
			+ "<if test=\"appVer != null and appVer != '' \">"
			+ "		AND APP_VER > #{appVer}"
			+ "</if>"
			+ "		AND UPDATE_YN = 'Y' "
			+ "		AND USE_YN = 'Y' "
			+ "</script>")
	int findUpdateY(@Param("deviceKind")String deviceKind, @Param("appVer")Integer appVer);
}
