package com.ljsnc.api.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class TnUser implements Serializable{
	private static final long serialVersionUID = 1L;

	private Integer userId;
	private String userLoginId;
	private String userPw;
	private String phoneNo;
	private String userNm;
	private String userEmail;
	private String userBirthday;
	private String userGender;
	private String userPost;
	private String userAddr;
	private String userAddrDetail;
	private String userType;
	private String deviceId;
	private String deviceKind;
	private String pushKey;
	private String lastConnDt;
	private String regId;
	private String regDt;
	private String modId;
	private String modDt;
	private String mappingYn;

	private String withdrawYn;





	public String getWithdrawYn() {
		return withdrawYn;
	}





	public void setWithdrawYn(String withdrawYn) {
		this.withdrawYn = withdrawYn;
	}





	public int getUserId() {
		return userId;
	}





	public void setUserId(int userId) {
		this.userId = userId;
	}





	public String getUserLoginId() {
		return userLoginId;
	}





	public void setUserLoginId(String userLoginId) {
		this.userLoginId = userLoginId;
	}





	public String getUserPw() {
		return userPw;
	}





	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}




	public String getPhoneNo() {
		return phoneNo;
	}





	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}





	public String getUserNm() {
		return userNm;
	}





	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}





	public String getUserEmail() {
		return userEmail;
	}





	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}





	public String getUserBirthday() {
		return userBirthday;
	}





	public void setUserBirthday(String userBirthday) {
		this.userBirthday = userBirthday;
	}





	public String getUserGender() {
		return userGender;
	}





	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}





	public String getUserPost() {
		return userPost;
	}





	public void setUserPost(String userPost) {
		this.userPost = userPost;
	}





	public String getUserAddr() {
		return userAddr;
	}





	public void setUserAddr(String userAddr) {
		this.userAddr = userAddr;
	}





	public String getUserAddrDetail() {
		return userAddrDetail;
	}





	public void setUserAddrDetail(String userAddrDetail) {
		this.userAddrDetail = userAddrDetail;
	}





	public String getUserType() {
		return userType;
	}





	public void setUserType(String userType) {
		this.userType = userType;
	}





	public String getDeviceId() {
		return deviceId;
	}





	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}





	public String getDeviceKind() {
		return deviceKind;
	}





	public void setDeviceKind(String deviceKind) {
		this.deviceKind = deviceKind;
	}





	public String getPushKey() {
		return pushKey;
	}





	public void setPushKey(String pushKey) {
		this.pushKey = pushKey;
	}





	public String getLastConnDt() {
		return lastConnDt;
	}





	public void setLastConnDt(String lastConnDt) {
		this.lastConnDt = lastConnDt;
	}





	public String getRegId() {
		return regId;
	}





	public void setRegId(String regId) {
		this.regId = regId;
	}





	public String getRegDt() {
		return regDt;
	}





	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}





	public String getModId() {
		return modId;
	}





	public void setModId(String modId) {
		this.modId = modId;
	}





	public String getModDt() {
		return modDt;
	}





	public void setModDt(String modDt) {
		this.modDt = modDt;
	}





	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}





	public String getMappingYn() {
		return mappingYn;
	}





	public void setMappingYn(String mappingYn) {
		this.mappingYn = mappingYn;
	}
}
