package com.ljsnc.api.util;

import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class MailUtil {

	private static final Logger logger = LoggerFactory.getLogger(MailUtil.class);

	public static String sendEmail(String toMail,String subject, String content)
			throws Exception {

			final String send_mail = "ljsnc.hdh";
			final String send_pw = "soda0848@@";

			String result = "";
			try{
				Properties props = new Properties();
		        props.setProperty("mail.transport.protocol", "smtp");
		        props.setProperty("mail.host", "smtp.gmail.com");
		        props.put("mail.smtp.auth", "true");
		        props.put("mail.smtp.port", "465");
		        props.put("mail.smtp.ssl.enable","true");
		        props.put("mail.smtp.debug", "true");
		        props.put("mail.smtp.auth", "true");
		        props.put("mail.smtp.socketFactory.port", "465");
		        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		        props.put("mail.smtp.socketFactory.fallback", "false");

		        Authenticator auth = new Authenticator(){
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(send_mail, send_pw);
		            }
		        };

		        Session session = Session.getDefaultInstance(props,auth);

		        MimeMessage message = new MimeMessage(session);
		        message.setSender(new InternetAddress(send_mail));

		        message.setRecipient(Message.RecipientType.TO, new InternetAddress(toMail));
		        message.setSubject(subject,"UTF-8");
		        message.setText(content,"UTF-8");
		        message.setHeader("X-Mailer", "PSERANG");
		        message.setHeader("Content-type", "text/html; charset=UTF-8");
		        message.setSentDate(new Date());

		        Transport.send(message);
		        result = "S";
			}catch(Exception e){
				logger.debug(e.getMessage());
				result = "F";
			}

			logger.debug(result);
			logger.debug(result);
			logger.debug(result);
			logger.debug(result);
			return result;
		}

/*		public static InternetAddress[] makerecipients(String addrs) throws AddressException{
			 StringTokenizer toker;
			 String delim = "";   //구분자
			 InternetAddress[] addr = null;

			 if(addrs != null){   //참조 주소가 있을때
				 if(addrs.indexOf(",") != - 1){   // 참조메일을 , 로 구분했으면...
					 delim = ",";
				 }else if(addrs.indexOf(";") != -1){  // 참조메일을 ; 로 구분했으면...
					 delim = ";";
				 }

				 toker = new StringTokenizer(addrs ,delim);    // ,나 ;로  이메일주소 구분하여 토크나이져로 분리
				 int count  = toker.countTokens();      // 참조 이메일 카운트
				 addr = new InternetAddress[count];
				 int i = 0;

				 while(toker.hasMoreTokens()){
				 	addr[i++] = new InternetAddress(toker.nextToken().trim());
				 } //while
			 }
			 return addr;
		}*/
}
