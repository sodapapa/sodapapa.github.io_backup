import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Test;

/**
 * 금지어 필터링하기
 *
 */

public class filterTest {

    public static String filterText(String sText) {
        Pattern p = Pattern.compile("fuck|shit|개새끼|새끼", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(sText);
        StringBuffer sb = new StringBuffer();

        while (m.find()) {
            System.out.println(m.group());
            m.appendReplacement(sb, maskWord(m.group()));
        }

        m.appendTail(sb);

        //System.out.println(sb.toString());
        return stripHTML(sb.toString());
    }

    public static String stripHTML(String htmlStr) {
    	Pattern p = Pattern.compile("<(?:.|\\s)*?>");
    	Matcher m = p.matcher(htmlStr);

    	return m.replaceAll("");
    }



    public static String maskWord(String word) {
        StringBuffer buff = new StringBuffer();
        char[] ch = word.toCharArray();
        for (int i = 0; i < ch.length; i++) {
                buff.append("*");
        }
        return buff.toString();
    }
}


